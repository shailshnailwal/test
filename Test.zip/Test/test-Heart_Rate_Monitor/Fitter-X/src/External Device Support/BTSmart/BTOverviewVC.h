///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2013 Wahoo Fitness. All Rights Reserved.
//
// The information contained herein is property of Wahoo Fitness LLC.
// Terms and conditions of usage are described in detail in the
// WAHOO FITNESS API LICENSE AGREEMENT.
//
// Licensees are granted free, non-transferable use of the information.
// NO WARRANTY of ANY KIND is provided.
// This heading must NOT be removed from the file.
///////////////////////////////////////////////////////////////////////////////
//
//  BTOverviewVC.h
//  WahooDemo
//
//  Created by Michael Moore on 2/14/12.
//  Copyright (c) 2012 Wahoo Fitness. All rights reserved.
//

#import <UIKit/UIKit.h>


@class WFHardwareConnector;



@interface BTOverviewVC : UIViewController
{
	WFHardwareConnector* hardwareConnector;
    
    UILabel* btConnectedLabel;
    
	UILabel* proxConnectedLabel;
	UILabel* proxDeviceIdLabel;
	UILabel* proxSignalLabel;
    
	UILabel* tempConnectedLabel;
	UILabel* tempDeviceIdLabel;
	UILabel* tempSignalLabel;
    
	UILabel* bpConnectedLabel;
	UILabel* bpDeviceIdLabel;
	UILabel* bpSignalLabel;
    
	UILabel* glucConnectedLabel;
	UILabel* glucDeviceIdLabel;
	UILabel* glucSignalLabel;
}


@property (retain, nonatomic) IBOutlet UILabel* btConnectedLabel;

@property (retain, nonatomic) IBOutlet UILabel* proxConnectedLabel;
@property (retain, nonatomic) IBOutlet UILabel* proxDeviceIdLabel;
@property (retain, nonatomic) IBOutlet UILabel* proxSignalLabel;
- (IBAction)proximityClicked:(id)sender;


@end
