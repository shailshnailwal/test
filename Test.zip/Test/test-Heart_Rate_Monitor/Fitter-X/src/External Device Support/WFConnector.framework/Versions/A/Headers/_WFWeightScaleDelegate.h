//
//  _WFWeightScaleDelegate.h
//  WFConnector
//
//  Created by Michael Moore on 10/5/12.
//  Copyright (c) 2012 Wahoo Fitness. All rights reserved.
//



#import <Foundation/Foundation.h>


@class WFWeightScaleConnection;


/**
 * Internal-use base class for the WFWeightScaleDelegate.
 */
@protocol _WFWeightScaleDelegate <NSObject>

@optional

@end