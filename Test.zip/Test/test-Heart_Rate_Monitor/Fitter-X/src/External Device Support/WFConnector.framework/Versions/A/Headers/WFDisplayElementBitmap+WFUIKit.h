//
//  WFDisplayElementBitmap+WFUIKit.h
//  WFConnector
//
//  Created by Murray Hughes on 14/01/13.
//  Copyright (c) 2013 Wahoo Fitness. All rights reserved.
//

#import "WFDisplayElementBitmap.h"
#import <UIKit/UIKit.h>

@interface WFDisplayElementBitmap (WFUIKit)

- (UIImage*) image;


@end
