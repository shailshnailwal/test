//
//  _WFWeightScaleConnection.h
//  WFConnector
//
//  Created by Michael Moore on 10/5/12.
//  Copyright (c) 2012 Wahoo Fitness. All rights reserved.
//

#import <WFConnector/WFSensorConnection.h>


/**
 * Internal-use base class for the WFWeightScaleConnection.
 */
@interface _WFWeightScaleConnection : WFSensorConnection

@end
