//
//  RegistrationVC.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserOperation.h"
#import "KeyboardHandlingVC.h"

enum ContentView{
    
    ContentViewGender,
    ContentViewAge,
    ContentViewHeight,
    ContentViewWeight
};

@interface RegistrationVC : KeyboardHandlingVC<UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate, UserOperationDelegate>{
    
    //IBOutlet UIScrollView *_resizableView;
//    AppNavigator *_navigator;
    
    __weak IBOutlet UIView   *_containerView;
    __weak IBOutlet UIButton *_saveButton;
    __weak IBOutlet UILabel  *_infoLabel;
    
    IBOutlet UIView *_contentUsernameView;
    IBOutlet UIView *_contentNameView;
    IBOutlet UIView *_contentGenderView;
    IBOutlet UIView *_contentAgeView;
    IBOutlet UIView *_contentHeightView;
    IBOutlet UIView *_contentWeightView;
    
    __weak IBOutlet UIPickerView *_genderPicker;
    __weak IBOutlet UIPickerView *_dayPicker;
    __weak IBOutlet UIPickerView *_monthPicker;
    __weak IBOutlet UIPickerView *_yearPicker;
    __weak IBOutlet UIPickerView *_feetPicker;
    __weak IBOutlet UIPickerView *_inchePicker;
    __weak IBOutlet UIPickerView *_weightPicker;
    
    __weak IBOutlet UITextField *_usernameTF;
    __weak IBOutlet UITextField *_passwordTF;
    __weak IBOutlet UITextField *_firstNameTF;
    __weak IBOutlet UITextField *_lastNameTF;
    
    NSArray   *_contentViewList;
    NSInteger _contentViewIndex;
    NSInteger _pickerSuperViewIndex;
    UIView    *_contentToAdd;
    
    NSArray *_genderList;
    NSArray *_monthList;
    NSArray *_infoLabelList;
    NSArray *_pickerArray;
    
//    NSMutableDictionary *_userInfo;
    UserOperation *_userOperator;
    User *_user;
}

- (IBAction)saveInformation:(UIButton *)sender;
- (IBAction)backToPreviousView:(id)sender;
@end
