//
//  MetrixCell.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "MetrixCell.h"

@implementation MetrixCell

@synthesize scoreBoard = _scoreBoard;
@synthesize indexPath  = _indexPath;

-(void)setScoreBoard:(FitterScoreBoard *)scoreBoard{
    
    _START;
    _scoreBoard = scoreBoard;
    if (_scoreBoard) {
        
        if (_indexPath.row == MetricsCellFitterX) {
            
            //if(LOGS_ON) NSLog(@"setting fitter x score board");
            [self setFitterXMetricsLabel];
        }
        else if (_indexPath.row == MetricsCellHeartRate) {
            
            [self setHeartMetricsLabel];
        }
        else if (_indexPath.row == MetricsCellDistance) {
            
            [self setDistanceMetricsLabel];
        }
//        else if (_indexPath.row == MetricsCellCaloriesThreshold) {
//            
//            [self setCaloriesThrasholdMetricsLabel];
//        }
    }
    _END;
}

#pragma mark- Set text on different metrix

//// on fitter X metrix ////
-(void) setFitterXMetricsLabel{
    
    _START;
    //if(LOGS_ON) NSLog(@"fitter x score = %f", _scoreBoard.fxmScore);
    _fxmScoreLabel.text = [NSString stringWithFormat:@"%.1f",_scoreBoard.fxmScore];
    _fxmRateLabel.text  = [NSString stringWithFormat:@"%.2f",_scoreBoard.fxmRate];
    _fxmMinLabel.text   = [NSString stringWithFormat:@"%.2f",_scoreBoard.fxmMin];
    _fxmMaxLabel.text   = [NSString stringWithFormat:@"%.2f",_scoreBoard.fxmMax];
    
    //if(LOGS_ON) NSLog(@"check for max min = %f %f", _scoreBoard.fxmMax, _scoreBoard.fxmMin);
    
    _END;
}

//// on heart rate metrix ////
-(void) setHeartMetricsLabel{
    
    _hrmValueLabel.text         = [NSString stringWithFormat:@"%.0f",_scoreBoard.hrmValue];
    _hrmAvgLabel.text           = [NSString stringWithFormat:@"%.1f",_scoreBoard.hrmAvgExerciseHR];
    _hrmMaxLabel.text           = [NSString stringWithFormat:@"%.1f",_scoreBoard.hrmMax];
    _hrmRestingRateLabel.text   = [NSString stringWithFormat:@"%.1f",_scoreBoard.hrmRestingRate];
    _hrmChangeRateLabel.text    = [NSString stringWithFormat:@"%.2f",_scoreBoard.hrmChangeRate];
    _hrmRecoveryRateLabel.text  = [NSString stringWithFormat:@"%.2f",_scoreBoard.hrmRecoveryRate];
}

//// on distance metrix ////
-(void) setDistanceMetricsLabel{
    
    //if(LOGS_ON) NSLog(@"distence to show on cell = %f", _scoreBoard.dmDistance);
    if (_scoreBoard.dmCurrentSpeed > 0) {
        
        _dmSpeedLabel.text    = [NSString stringWithFormat:@"%.1f",_scoreBoard.dmCurrentSpeed * METER_PER_SECOND_TO_MILE_PER_HOUR];
    }
    _dmAvgSpeedLabel.text = [NSString stringWithFormat:@"%.1f",_scoreBoard.dmAvgSpeed * METER_PER_SECOND_TO_MILE_PER_HOUR / 60];
    _dmMaxSpeedLabel.text = [NSString stringWithFormat:@"%.1f",_scoreBoard.dmMaxSpeed * METER_PER_SECOND_TO_MILE_PER_HOUR];
    _dmDistanceLabel.text = [NSString stringWithFormat:@"%.1f",_scoreBoard.dmDistance * METER_TO_MILE];
}

//// on calories/thrashold metrix // this metrix in not used so far, because client did not provide the formula for this//
-(void) setCaloriesThrasholdMetricsLabel{
    
//    _ctmCalBurnedLabel.text = [NSString stringWithFormat:@"%.0f",_scoreBoard.ctmCalBurned];
//    _ctmBurnRateLabel.text  = [NSString stringWithFormat:@"%.0f",_scoreBoard.ctmBurnRate];
//    _ctmAnaerobicLabel.text = [NSString stringWithFormat:@"%.0f",_scoreBoard.ctmAnaerobic];
//    _ctmAeraobicLabel.text  = [NSString stringWithFormat:@"%.0f",_scoreBoard.ctmAeraobic];
}

@end
