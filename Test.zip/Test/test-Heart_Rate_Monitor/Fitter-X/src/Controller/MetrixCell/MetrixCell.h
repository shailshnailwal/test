//
//  MetrixCell.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FitterScoreBoard.h"

typedef NS_ENUM(NSInteger, MetricsCell) {
    
    MetricsCellFitterX,
    MetricsCellHeartRate,
    MetricsCellDistance,
    MetricsCellCaloriesThreshold
};

@interface MetrixCell : UITableViewCell{
    
    //// for fitter x metrics ////
    IBOutlet UILabel *_fxmScoreLabel;
    IBOutlet UILabel *_fxmRateLabel;
    IBOutlet UILabel *_fxmMinLabel;
    IBOutlet UILabel *_fxmMaxLabel;
    
    //// for heart rate metrix ////
    IBOutlet UILabel *_hrmValueLabel;
    IBOutlet UILabel *_hrmAvgLabel;
    IBOutlet UILabel *_hrmMaxLabel;
    IBOutlet UILabel *_hrmRestingRateLabel;
    IBOutlet UILabel *_hrmChangeRateLabel;
    IBOutlet UILabel *_hrmRecoveryRateLabel;
    
    //// for distance metrics ////
    IBOutlet UILabel *_dmSpeedLabel;
    IBOutlet UILabel *_dmAvgSpeedLabel;
    IBOutlet UILabel *_dmMaxSpeedLabel;
    IBOutlet UILabel *_dmDistanceLabel;
    
    //// for calorise / threshold metrics ////
    IBOutlet UILabel *_ctmCalBurnedLabel;
    IBOutlet UILabel *_ctmBurnRateLabel;
    IBOutlet UILabel *_ctmAnaerobicLabel;
    IBOutlet UILabel *_ctmAeraobicLabel;
    
    //// to set values ////
    FitterScoreBoard *_scoreBoard;
    
    NSIndexPath *_indexPath;
}

@property(nonatomic, strong) FitterScoreBoard *scoreBoard;
@property(nonatomic, strong) NSIndexPath *indexPath;

@end
