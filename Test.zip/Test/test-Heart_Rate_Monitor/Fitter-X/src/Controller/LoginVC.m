//
//  LoginVC.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 02/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "LoginVC.h"
#import "RegistrationVC.h"
#import "UserVC.h"
#import "MBProgressHUD.h"

////******* check ************////
#import "AlgorithmExecutor.h"

@implementation LoginVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
}

- (void)viewDidLoad
{
    _START;
    [super viewDidLoad];
    
    //// setting input accessory view ////
    _usernameTF.inputAccessoryView = _accessoryToolbar;
    _passwordTF.inputAccessoryView = _accessoryToolbar;
    
    //// making array of textfields so that we can move to next textfield ////
    _textFieldList = [[NSArray alloc] initWithObjects:_usernameTF, _passwordTF, nil];
    _END;
}

-(void)viewDidAppear:(BOOL)animated{
    
    ((AppNavigator *)self.navigationController).user = nil;
    
    //// setting delegate ////
    ((AppNavigator *)self.navigationController).kbDelegate = self;
    _resizableView.contentSize = _resizableView.frame.size;
}

/**
 * this function will start login process
 */
- (IBAction)login:(id)sender {
    
    _START; 
    //***************************** checking ******************************
//    [_executer deactivateExecuter];
    //*********************************************************************
    
    if (!_userOperator) {
        
        _userOperator = [[UserOperation alloc] init];
    }
    _userOperator.delegate = self;
    
    if (_usernameTF && _usernameTF.text && ![_usernameTF.text isEqualToString:@""] &&
        _passwordTF && _passwordTF.text && ![_passwordTF.text isEqualToString:@""]) {
        
        [MBProgressHUD showHUDAddedTo:APP_DELEGATE.window animated:YES];
        [_userOperator loginUserWithUsername:_usernameTF.text andPassword:_passwordTF.text];
        
        //*************************************************//
//        User *user       = [[User alloc] init];
//        user.gender      = @"M";
//        user.dateOfBirth = @"1988-07-03";
//        user.weight      = 60;
//        user.heightFeet  = 5;
//        user.heightInche = 11;
//        user.userID      = 2;
//        user.username    = @"shailsh";
//        user.password    = @"shailsh";
//        user.firstName   = @"Shailsh";
//        user.lastName    = @"Nailwal";
//        [self userInfoAfterLoginCompletionSuccessfully:user];
        //****************************************************//
    }
    else{
        
        [UniversalTaskExecuter showAlertWithTitle:@"Field Check"
                                       andMessage:@"Username and Password must be filled"
                                  withButtonTitle:@"OK"];
    }
    _END;
}

//- (IBAction)login:(id)sender {
//    
//    //// setting corrosponding variables for single or double click ////
//    if (!_isSingleClick && !_isDoubleClick) {
//        
//        //// both variables false means that it is a fresh single click ////
//        _isSingleClick = true;
//        
//    }
//    else if (_isSingleClick && !_isDoubleClick){
//        
//        //// single click is true and double click is false means that this is a fresh double click, and single click don't valid now ////
//        _isSingleClick = false;
//        _isDoubleClick = true;
//    }
//    
//    if (!_clickResolved) {
//        
//        //// this will tell wether click event (for single or double) has been processed or not ///
//        //// true means, it's been processed ////
//        _clickResolved = true;
//        
//        //// this function is for delaying the time out ////
//        [self performSelector:@selector(clickCount) withObject:nil afterDelay:.3];
//    }
//}
//
///**
// * this funciton will perform the task on both click (single or double)
// */
//-(void) clickCount{
//    
//    if (_isSingleClick) {
//        
//        //if(LOGS_ON) NSLog(@"Single click");
//    }
//    else{
//        
//        //if(LOGS_ON) NSLog(@"Double click");
//    }
//    
//    //// flushing all controlling booleans, so that click event can be generated all over again ////
//    _isSingleClick = false;
//    _isDoubleClick = false;
//    _clickResolved = false;
//}


#pragma mark- USER OPERATION METHODS 
#pragma mark-
#pragma mark- user login
-(void) userInfoAfterLoginCompletionSuccessfully:(User *)user{
    
    _START;
    [MBProgressHUD hideAllHUDsForView:APP_DELEGATE.window animated:YES];
    UserVC *userWall = nil;
    if (user) {
        
        ((AppNavigator *)self.navigationController).user = user;
        //if(LOGS_ON) NSLog(@"==user = %@", ((AppNavigator *)self.navigationController).user.userInfo);
        userWall      = [[UserVC alloc] init];
        userWall.user = user;
        
        [self.navigationController pushViewController:userWall animated:YES];
    }
    else{
        
        if(SERVER_LOGS_ON) NSLog(@"could not login");
        [UniversalTaskExecuter showAlertWithTitle:@"Authentication Fail"
                                       andMessage:@"Wronge username or password"
                                  withButtonTitle:@"OK"];
    }
}

-(void)userLoginFail{
    
    _START;
    [MBProgressHUD hideAllHUDsForView:APP_DELEGATE.window animated:YES];
    if(SERVER_LOGS_ON) NSLog(@"user login fail");
    [UniversalTaskExecuter showAlertWithTitle:@"Login error"
                                   andMessage:@"User can not login due to some server problem"
                              withButtonTitle:@"OK"];
    _END;
}

-(void)passwordRecoverySuccessfullForUserEmail:(NSString *)email{
    _recoveryAlert = [[UIAlertView alloc] initWithTitle:EMPTY_STRING
                                                message:[NSString stringWithFormat:@"Password will be sent to '%@' if found as registered email", email]
                                               delegate:self
                                      cancelButtonTitle:@"OK"
                                      otherButtonTitles: nil];
    [_recoveryAlert show];
}

-(void)passwordRecoveryFailedForUserEmail:(NSString *)email{
    
    _recoveryAlert = [[UIAlertView alloc] initWithTitle:EMPTY_STRING
                                                message:[NSString stringWithFormat:@"Password can not be sent due to network problem"]
                                               delegate:self
                                      cancelButtonTitle:@"OK"
                                      otherButtonTitles: nil];
    [_recoveryAlert show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex == 0) {
        
        [self cancelRecovery:_cancelRecoveryBtn];
    }
}

#pragma mark- Registration
- (IBAction)registerUser:(id)sender {
    
    _START;
    RegistrationVC *registration = [[RegistrationVC alloc] init];
    [self.navigationController pushViewController:registration animated:YES];
    _END;
}

/**
 * this function will show recovery view to send password to user registered email
 */
- (IBAction)recoverAccount:(id)sender {
    
    _START;
    [self.view addSubview:_shadowView];
    _recoveryView.frame = [UniversalTaskExecuter changeXOrigenTo:0 yOrigenTo:-_recoveryView.frame.size.height toFrame:_recoveryView.frame];
    [self.view addSubview:_recoveryView];
    [UIView animateWithDuration:.3 animations:^{
        
        CGRect frame = _recoveryView.frame;
        frame.origin.y = 0;
        _recoveryView.frame = frame;
    } completion:^(BOOL finished) {
        
    }];
    _END;
}

/**
 * this function will send password to mentioned email
 */
- (IBAction)sendPassword:(id)sender {
    
    if (!_userOperator) {
        
        _userOperator = [[UserOperation alloc] init];
        _userOperator.delegate = self;
    }
    
    if ([_recoveryEmailTF.text isEqualToString:EMPTY_STRING]) {
        
        [UniversalTaskExecuter showAlertWithTitle:EMPTY_STRING
                                       andMessage:@"Please enter your Email address"
                                  withButtonTitle:@"OK"];
    }
    else if (![UniversalTaskExecuter isValidEmail:_recoveryEmailTF.text Strict:YES]){
        
        [UniversalTaskExecuter showAlertWithTitle:EMPTY_STRING
                                       andMessage:@"Please enter a valid Email address"
                                  withButtonTitle:@"OK"];
    }
    else {
    
        [_userOperator sendPasswordToUserEmail:_recoveryEmailTF.text];
    }
}

/**
 * this function will remove password recovery view
 */
- (IBAction)cancelRecovery:(id)sender {
    
    CGRect frame = _recoveryView.frame;
    frame.origin.y = -frame.size.height;
    [UIView animateWithDuration:.3 animations:^{
        
        _recoveryView.frame = frame;
    } completion:^(BOOL finished) {
        
        [_recoveryView removeFromSuperview];
        [_shadowView removeFromSuperview];
    }];
}

#pragma mark- Toolbar button methods
- (IBAction)doneEditing:(id)sender {
    
    [_usernameTF resignFirstResponder];
    [_passwordTF resignFirstResponder];
}

- (IBAction)moveToNext:(id)sender {
    
    UITextField *textField = nil;
    NSInteger replacingIndex = 0;
    if (_activeTF && _textFieldList) {
        
        replacingIndex = ([_textFieldList indexOfObject:_activeTF] + 1) % _textFieldList.count;
        textField = [_textFieldList objectAtIndex:replacingIndex];
        [textField becomeFirstResponder];
    }
}

#pragma mark- Textfield methods
-(void) textFieldDidBeginEditing:(UITextField *)textField{
    
    _START;
    _activeTF = textField;
    _END;
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
    _START;
    _activeTF = nil;
    _END;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
