//
//  DeviceData.m
//  TestBlueHR
//
//  Created by Shailsh Naiwal on 11/03/14.
//
//

#import "HeartRateData.h"

@interface HeartRateData (_PRIVATE_)

- (void)checkState;
- (NSString*)deviceIdString;
- (void)fisicaConnected;
- (void)fisicaDisconnected;
- (NSString*)signalString;
- (void)updateDeviceInfo;

@end

@implementation HeartRateData

@synthesize sensorConnection = _sensorConnection;
@synthesize computedHR       = _computedHR;
@synthesize delegate         = _delegate;

- (id)init
{
    self = [super init];
    if (self) {
        
        hardwareConnector   = [WFHardwareConnector sharedConnector];
        _sensorConnection   = nil;
        sensorType          = WF_SENSORTYPE_HEARTRATE;
        applicableNetworks  = WF_NETWORKTYPE_ANTPLUS | WF_NETWORKTYPE_BTLE;
    }
    return self;
}

//--------------------------------------------------------------------------------
- (void)setDefaults
{
    // initialize the display based on HW connector and sensor state.
    if ( hardwareConnector.isCommunicationHWReady )
    {
        // check for an existing connection to this sensor type.
        NSArray* connections = [hardwareConnector getSensorConnections:sensorType];
        WFSensorConnection* sensor = ([connections count]>0) ? (WFSensorConnection*)[connections objectAtIndex:0] : nil;
        
        // if a connection exists, cache it and set the delegate to this
        // instance (this will allow receiving connection state changes).
        self.sensorConnection = sensor;
        if (sensor)
        {
            self.sensorConnection.delegate = self;
        }
        
        // update the display.
        [self checkState];
        [self updateData];
    }
    else
    {
        [self resetDisplay];
    }
    
    // register for HW connector notifications.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fisicaConnected)    name:WF_NOTIFICATION_HW_CONNECTED object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fisicaDisconnected) name:WF_NOTIFICATION_HW_DISCONNECTED object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateData)         name:WF_NOTIFICATION_SENSOR_HAS_DATA object:nil];
}

//--------------------------------------------------------------------------------
- (void)removeObservers
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


#pragma mark -
#pragma mark WFSensorConnectionDelegate Implementation

//--------------------------------------------------------------------------------
- (void)connectionDidTimeout:(WFSensorConnection*)connectionInfo
{
    // update the button state.
    [self checkState];
    
    // alert the user that the search timed out.
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Search Timeout"
                                                    message:@"A connection was not established before the maximum search time expired."
                                                   delegate:nil cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    alert = nil;
}

//--------------------------------------------------------------------------------
- (void)connection:(WFSensorConnection*)connectionInfo stateChanged:(WFSensorConnectionStatus_t)connState
{
    NSLog(@"SENSOR CONNECTION STATE CHANGED:  connState = %d (IDLE=%d)",connState,WF_SENSOR_CONNECTION_STATUS_IDLE);
    
    // check for a valid connection.
    if ( connectionInfo.isValid && connectionInfo.isConnected )
    {
        // process post-connection setup.
        [self onSensorConnected:connectionInfo];
        
        // update the display.
        [self updateData];
    }
    
    // check for disconnected sensor.
    else if ( connState == WF_SENSOR_CONNECTION_STATUS_IDLE )
    {
        // reset the display.
        [self resetDisplay];
        
        // check for a connection error.
        if ( connectionInfo.hasError )
        {
            NSString* msg = nil;
            switch ( connectionInfo.error )
            {
                case WF_SENSOR_CONN_ERROR_PAIRED_DEVICE_NOT_AVAILABLE:
                    msg = @"Paired device error.\n\nA device specified in the connection parameters was not found in the Bluetooth Cache.  Please use the paring manager to remove the device, and then re-pair.";
                    break;
                    
                case WF_SENSOR_CONN_ERROR_PROXIMITY_SEARCH_WHILE_CONNECTED:
                    msg = @"Proximity search is not allowed while a device of the specified type is connected to the iPhone.";
                    break;
            }
            
            if ( msg )
            {
                // display the error message.
                UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Connection Error" message:msg delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
                alert = nil;
            }
        }
    }
	
	[self checkState];
}


#pragma mark -
#pragma mark DeviceDiscoveryDelegate Implementation

//--------------------------------------------------------------------------------
- (void)requestConnectionToDevice:(WFDeviceParams*)devParams
{
    // configure the connection params.
    WFConnectionParams* params = [[WFConnectionParams alloc] init];
    params.sensorType = sensorType;
    params.device1 = devParams;
    
    // request the sensor connection.
    self.sensorConnection = [hardwareConnector requestSensorConnection:params];
    
    // set delegate to receive connection status changes.
    self.sensorConnection.delegate = self;
    
    // update the button state.
    [self checkState];
}


#pragma mark -
#pragma mark WFSensorCommonViewController Implementation

#pragma mark Private Methdods


//--------------------------------------------------------------------------------
- (void)checkState
{
    _START;
	// get the current connection status.
	WFSensorConnectionStatus_t connState = WF_SENSOR_CONNECTION_STATUS_IDLE;
	if ( _sensorConnection != nil )
	{
		connState = _sensorConnection.connectionStatus;
	}
	
	// set the button state based on the connection state.
	switch (connState)
	{
		case WF_SENSOR_CONNECTION_STATUS_IDLE:
            _connectionState = @"Idle";
            if ([_delegate respondsToSelector:@selector(deviceConnectionClosed)]) {
                
                [_delegate deviceConnectionClosed];
            }
			break;
		case WF_SENSOR_CONNECTION_STATUS_CONNECTING:
            _connectionState = @"Connecting";
            if ([_delegate respondsToSelector:@selector(deviceConnectionInitiated)]) {
                
                [_delegate deviceConnectionInitiated];
            }
			break;
		case WF_SENSOR_CONNECTION_STATUS_CONNECTED:
            _connectionState = @"connected";
            NSLog(@"Delegate for heart rate daya = %@", _delegate);
            if ([_delegate respondsToSelector:@selector(deviceConnectionEstablished)]) {
                
                NSLog(@"Delegate is respondes");
                [_delegate deviceConnectionEstablished];
            }
			break;
		case WF_SENSOR_CONNECTION_STATUS_DISCONNECTING:
            _connectionState = @"disconnecting";
            if ([_delegate respondsToSelector:@selector(deviceConnectionClosing)]) {
                
                [_delegate deviceConnectionClosing];
            }
			break;
        case WF_SENSOR_CONNECTION_STATUS_INTERRUPTED:
            if ([_delegate respondsToSelector:@selector(deviceConnectionInterrupted)]) {
                
                [_delegate deviceConnectionInterrupted];
            }
            break;
	}
//    NSLog(@"Status is  %@", _connectionState);
    _END;
}

//--------------------------------------------------------------------------------
- (NSString*)deviceIdString
{
    NSString* retVal = @"---";
    
    if ( _sensorConnection )
    {
        // format BTLE UUID string.
        if ( _sensorConnection.isBTLEConnection )
        {
            retVal = [HeartRateData formatUUIDString:_sensorConnection.deviceUUIDString];
        }
        // format ANT+ device ID string.
        else if ( _sensorConnection.isANTConnection )
        {
            retVal = [NSString stringWithFormat:@"%u", _sensorConnection.deviceNumber];
        }
    }
    
    return retVal;
}

//--------------------------------------------------------------------------------
- (void)fisicaConnected
{
    
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Test Alert" message:@"In fisicaConnected" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//    [alert show];
}

//--------------------------------------------------------------------------------
- (void)fisicaDisconnected
{
    
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Test Alert" message:@"In fisicaDisconnected" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//    [alert show];
	[self resetDisplay];
}

//--------------------------------------------------------------------------------
- (NSString*)signalString
{
    return [HeartRateData signalStrengthFromConnection:self.sensorConnection];
}

//--------------------------------------------------------------------------------
- (void)updateDeviceInfo
{

    WFSensorData* data = [_sensorConnection getData];
    if ( data )
    {
        // check the radio type of the sensor connection.
        if ( _sensorConnection.isBTLEConnection )
        {
            // check that the BTLE common data is present.
            if ( ![data respondsToSelector:@selector(btleCommonData)] )
            {
                // check for BTLE common data in raw data instance.
                data = [_sensorConnection getRawData];
            }
            
            // check that the BTLE common data is present.
            if ( [data respondsToSelector:@selector(btleCommonData)] )
            {
                // get the BTLE common data and display the detail view.
                // btDeviceInfo.commonData = (WFBTLECommonData*)[data performSelector:@selector(btleCommonData)];
                //[btDeviceInfo updateDisplay];
            }
        }
        else if ( _sensorConnection.isANTConnection )
        {
            // check that the ANT+ common data is present.
            if ( ![data respondsToSelector:@selector(commonData)] )
            {
                // check for ANT+ common data in raw data instance.
                data = [_sensorConnection getRawData];
            }
            
            // check that the ANT+ common data is present.
            if ( [data respondsToSelector:@selector(commonData)] )
            {
                // get the ANT+ common data and display the detail view.
                // antDeviceInfo.commonData = (WFCommonData*)[data performSelector:@selector(commonData)];
                //[antDeviceInfo updateDisplay];
            }
        }
    }
}


#pragma mark Public Methods

//--------------------------------------------------------------------------------
- (void)onSensorConnected:(WFSensorConnection*)connectionInfo
{
    _START;
    // update the stored connection settings.
    [hardwareConnector.settings saveConnectionInfo:connectionInfo];
    _END;
}

//--------------------------------------------------------------------------------
- (void)resetDisplay
{
    _computedHR = @"---";
}

//--------------------------------------------------------------------------------
- (void)updateData
{
    _START;
    // update the device info.
//    [self updateDeviceInfo];
    
    
	WFHeartrateData* hrData = [self.heartrateConnection getHeartrateData];
    //if(LOGS_ON) NSLog(@"heart rate data = %@", hrData);
	if ( hrData != nil )
	{
        
        //[[UIApplication sharedApplication] setApplicationIconBadgeNumber:hrData.computedHeartrate];
        
        // unformatted value.
		// computedHeartrateLabel.text = [NSString stringWithFormat:@"%d", hrData.computedHeartrate];
        
        // update basic data.
        //if(LOGS_ON) NSLog(@"heart rate data in not null");
        _computedHR = [hrData formattedHeartrate:TRUE];
        
        if ([_delegate respondsToSelector:@selector(deviceStringFroHeartRate:)]) {
            
            [_delegate deviceStringFroHeartRate:_computedHR];
        }
        
        //if(LOGS_ON) NSLog(@"heart rate string = %@", _computedHR);
	}
	else
	{
		[self resetDisplay];
	}
    _END;
}


#pragma mark Properties

//--------------------------------------------------------------------------------
- (void)setSensorConnection:(WFSensorConnection *)conn
{
    _sensorConnection.delegate = nil;
    
    _sensorConnection = conn;
    _sensorConnection.delegate = self;
}

//--------------------------------------------------------------------------------
- (WFHeartrateConnection*)heartrateConnection
{
	WFHeartrateConnection* retVal = nil;
	if ( [self.sensorConnection isKindOfClass:[WFHeartrateConnection class]] )
	{
		retVal = (WFHeartrateConnection*)self.sensorConnection;
	}
	return retVal;
}


#pragma mark Event Handlers

//--------------------------------------------------------------------------------
- (void)startConnection{
    
    _START;
	// get the current connection status.
	WFSensorConnectionStatus_t connState = WF_SENSOR_CONNECTION_STATUS_IDLE;
	if ( _sensorConnection != nil )
	{
        
		connState = _sensorConnection.connectionStatus;
	}
	
	// set the button state based on the connection state.
	switch (connState)
	{
		case WF_SENSOR_CONNECTION_STATUS_IDLE:
		{
            
			// create the connection params.
			WFConnectionParams* params = nil;
            params = [hardwareConnector.settings connectionParamsForSensorType:sensorType];
//            NSLog(@"params to send is = %@", params);
			
			if ( params != nil)
			{
                // set the search timeout.
//                NSLog(@"params in not nill");
                params.searchTimeout = hardwareConnector.settings.searchTimeout;
                self.sensorConnection = [hardwareConnector requestSensorConnection:params];
                
                // set delegate to receive connection status changes.
                self.sensorConnection.delegate = self;
			}
			break;
		}
			
		case WF_SENSOR_CONNECTION_STATUS_CONNECTING:
		case WF_SENSOR_CONNECTION_STATUS_CONNECTED:
			// disconnect the sensor.
            NSLog(@"to be disconnect");
			[self.sensorConnection disconnect];
			break;
			
		case WF_SENSOR_CONNECTION_STATUS_DISCONNECTING:
        case WF_SENSOR_CONNECTION_STATUS_INTERRUPTED:
			// do nothing.
            NSLog(@"disconnecting of interupted");
			break;
	}
	
	[self checkState];
}

#pragma mark -
#pragma mark WFSensorCommonViewController Class Method Implementation

//--------------------------------------------------------------------------------
+ (NSString*)formatUUIDString:(NSString*)uuid
{
    // strip the leading zeros from the UUID.
    NSString* retVal = [uuid stringByReplacingOccurrencesOfString:@"0000000000000000" withString:@""];
    retVal = [retVal stringByReplacingOccurrencesOfString:@"00000000-0000-0000-" withString:@""];
    
    return retVal;
}

//--------------------------------------------------------------------------------
+ (NSString*)signalStrengthFromConnection:(WFSensorConnection*)conn
{
    NSString* retVal = @"---";
    
    if ( conn )
    {
        // format the signal efficiency value.
		float signal = [conn signalEfficiency];
        //
        // signal efficency is % for ANT connections, dBm for BTLE.
        if ( conn.isANTConnection && signal != -1 )
        {
            retVal = [NSString stringWithFormat:@"%1.0f%%", (signal*100)];
        }
        else if ( conn.isBTLEConnection )
        {
            retVal = [NSString stringWithFormat:@"%1.0f dBm", signal];
        }
    }
    
    return retVal;
}

//--------------------------------------------------------------------------------
+ (NSString*)stringFromSensorType:(WFSensorType_t)sensorType
{
    NSString* retVal;
    
	switch (sensorType)
	{
		case WF_SENSORTYPE_HEARTRATE:
            retVal = @"Heart Rate Monitor";
            break;
    }
    
    return retVal;
}

@end
