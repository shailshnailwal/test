//
//  ConnectionIndicatorView.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 27/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CountDownView.h"

@interface ConnectionIndicatorView : HeartRateMonitorHandlingView<IndicatorDelegate, UIAlertViewDelegate>{
    
    @private
    IBOutlet CountDownView *_countDownView;
    UIAlertView *_connectionAlert;
}

@property(nonatomic, strong) CountDownView *countDownView;
@end
