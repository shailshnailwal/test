//
//  CountDownView.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 24/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "CountDownView.h"

@implementation CountDownView

@synthesize keepCoutDownOn    = _keepCoutDownOn;
@synthesize showNumber        = _showNumber;
@synthesize indicatorDelegate = _indicatorDelegate;
@synthesize maximumCount      = _maximumCount;

-(void)setKeepCoutDownOn:(BOOL)keepCoutDownOn{
    
    _START;
    _keepCoutDownOn = keepCoutDownOn;
    _dotIndex       = -1;
    _count          = 0;
    
    //// to clear indicator ////
    [self clearIndicator];

    //if(LOGS_ON) NSLog(@"to keep count down = %d", keepCoutDownOn);
    
    if (keepCoutDownOn) {
        
        [self animateIndicator];
    }
    else{
        
        [self stopIndicator];
    }
    _END;
}

/**
 * this function will start showing count down number as well
 */
-(void) setShowNumber:(BOOL)showNumber{
    
    _showNumber = showNumber;
    _countLabel.hidden = !_showNumber;
}

- (id)init
{
    
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"CountDownView" owner:nil options:nil];
    CountDownView *countDownView = nil;
    
    for (int i = 0; nibs != nil && i < nibs.count; i ++) {
        
        UIView *view = [nibs objectAtIndex:i];
        if ([view isKindOfClass:[CountDownView class]]) {
            
            countDownView = (CountDownView *)view;
        }
    }
    return countDownView;
}



/**
 * this function will clear all the dots in indicator
 */
-(void) clearIndicator{
    
    _START;
    for (UIButton * btn in _indicatorDotList) {
        
        btn.selected = NO;
        btn.backgroundColor = [UIColor clearColor];
    }
    _END;
}

/**
 * this function will change the color of indicator dots
 */
-(void) changeColor{
    
    _START;
    UIButton *btn = nil;
    
    if (_indicatorDotList) {
        
        if (_dotIndex >= 0) {
            
            btn = [_indicatorDotList objectAtIndex:_dotIndex];
            btn.selected = !btn.selected;
            
            if (_showNumber) {
            
                _countLabel.text = [NSString stringWithFormat:@"%d",_count];
            }
            
            //if(LOGS_ON) NSLog(@"count = %d and max = %d", _count, _maximumCount);
            
            if (btn.selected) {
                
                btn.backgroundColor = [UIColor whiteColor];
            }
            else{
                
                btn.backgroundColor = [UIColor clearColor];
            }
        }
        
        _dotIndex = (_dotIndex + 1) % _indicatorDotList.count;
        _count ++;
        
        if (_count > _maximumCount) {
            
            [self stopIndicator];
            
            if ([_indicatorDelegate respondsToSelector:@selector(countDownReachedToMaximum)]) {
                
                [_indicatorDelegate countDownReachedToMaximum];
            }
        }
    }
    _END;
}

/**
 * this function will start all animation process
 */
-(void) animateIndicator{
    
    _keepCoutDownOn = YES;
    
    dispatch_queue_t q_background = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0);
    dispatch_time_t popTime = 1;//dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, q_background, ^(void){
        
        while (_keepCoutDownOn) {
            
            //if(LOGS_ON) NSLog(@"started thread to animate");
            [NSThread sleepForTimeInterval:1];
            [self changeUI];
        }
    });
}

/**
 * this function will change colors of dots in main thread
 */
-(void) changeUI{
    
    [self performSelectorOnMainThread:@selector(changeColor) withObject:nil waitUntilDone:YES];
}


-(void) stopIndicator{
    
    _START;
    _keepCoutDownOn = NO;
//    _keepCoutDownOn = NO;
    if (self) {
        
//        [self removeFromSuperview];
//        [self clearIndicator];
    }
    _END;
}


//************************** not in use ************************//
- (IBAction)checkForState:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    if (sender.selected) {
        
        //if(LOGS_ON) NSLog(@"color is white");
        sender.backgroundColor = [UIColor whiteColor];
    }
    else{
        
        sender.backgroundColor = [UIColor clearColor];
    }
}
//************************************************************//
@end
