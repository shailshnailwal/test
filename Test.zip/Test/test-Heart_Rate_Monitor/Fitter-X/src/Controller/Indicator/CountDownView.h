//
//  CountDownView.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 24/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IndicatorDelegate <NSObject>
    @optional
        -(void) countDownReachedToMaximum;
@end

@interface CountDownView : UIView{
    
    IBOutletCollection(UIButton) NSArray *_indicatorDotList;
    BOOL _keepCoutDownOn;
    BOOL _showNumber;
    NSInteger _dotIndex;
    NSInteger _maximumCount;
    NSTimer *_timer;
    NSInteger _count;
    NSArray *_indicatorDots;
    
    id<IndicatorDelegate> _indicatorDelegate;
    
    __weak IBOutlet CustomBoldLabel *_countLabel;
    __weak IBOutlet UIView *_indicatorStripView;
}

@property(nonatomic, assign) BOOL keepCoutDownOn;
@property(nonatomic, assign) BOOL showNumber;
@property(nonatomic, assign) NSInteger maximumCount;
@property(nonatomic, strong) id<IndicatorDelegate> indicatorDelegate;

//// not in use now ////
- (IBAction)checkForState:(id)sender;
@end
