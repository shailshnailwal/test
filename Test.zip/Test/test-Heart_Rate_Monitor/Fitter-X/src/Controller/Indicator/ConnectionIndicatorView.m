//
//  ConnectionIndicatorView.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 27/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "ConnectionIndicatorView.h"

@implementation ConnectionIndicatorView

@synthesize countDownView = _countDownView;

- (id)init
{
    
    _START;
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"ConnectionIndicatorView" owner:nil options:nil];
    ConnectionIndicatorView *countDownView = nil;
    
    for (int i = 0; nibs != nil && i < nibs.count; i ++) {
        
        UIView *view = [nibs objectAtIndex:i];
        if ([view isKindOfClass:[ConnectionIndicatorView class]]) {
            
            countDownView = (ConnectionIndicatorView *)view;
        }
    }
    _END;
    return countDownView;
}

/**
 * then countdown of indicator reached to the maximum limite, show the user alert for user choice
 */
-(void)countDownReachedToMaximum{
    
    _START;
    if (!_connectionAlert) {
        
        _connectionAlert = [[UIAlertView alloc] initWithTitle:@"Connection Alert"
                                                      message:nil
                                                     delegate:self
                                            cancelButtonTitle:@"NO"
                                            otherButtonTitles:@"Connect", nil];
    }
    _connectionAlert.message = @"Connection time out.\nDo you want to try again?";
    [_connectionAlert show];
    _END;
}

#pragma mark- Alert View Methods
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    _START;
    if (buttonIndex == 1) {
        
        _countDownView.keepCoutDownOn = YES;
    }
    else{
        
        [self removeFromSuperview];
    }
    _END;
}

/**
 * This function will be called when device is connected
 * it will calculate resting heart rate after 1 minute
 */
//- (IBAction)connectionCompleted:(id)sender {
//    
//    _START;
//    _countDownView.keepCoutDownOn = NO;
//    self.hidden = YES;
//    _END;
//}
@end
