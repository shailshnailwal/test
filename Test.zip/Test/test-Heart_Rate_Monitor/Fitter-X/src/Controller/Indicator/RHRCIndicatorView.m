//
//  RHRCIndicatorView.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 27/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "RHRCIndicatorView.h"

@implementation RHRCIndicatorView

@synthesize countDownView = _countDownView;

- (id)init
{
    
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"RHRCIndicatorView" owner:nil options:nil];
    RHRCIndicatorView *countDownView = nil;
    
    for (int i = 0; nibs != nil && i < nibs.count; i ++) {
        
        UIView *view = [nibs objectAtIndex:i];
        if ([view isKindOfClass:[RHRCIndicatorView class]]) {
            
            countDownView = (RHRCIndicatorView *)view;
        }
    }
    return countDownView;
}

#pragma mark- Indicator Method
-(void)countDownReachedToMaximum{
    
    _START;
    [self deviceDataFetched:nil];
    _END;
}

@end
