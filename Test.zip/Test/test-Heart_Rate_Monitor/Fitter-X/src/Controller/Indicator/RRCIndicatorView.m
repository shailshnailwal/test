//
//  RRCIndicatorView.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 27/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "RRCIndicatorView.h"

@implementation RRCIndicatorView

@synthesize countDownView = _countDownView;

- (id)init
{
    
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"RRCIndicatorView" owner:nil options:nil];
    RRCIndicatorView *countDownView = nil;
    
    for (int i = 0; nibs != nil && i < nibs.count; i ++) {
        
        UIView *view = [nibs objectAtIndex:i];
        if ([view isKindOfClass:[RRCIndicatorView class]]) {
            
            countDownView = (RRCIndicatorView *)view;
        }
    }
    return countDownView;
}

#pragma mark- Indicator Method
-(void)countDownReachedToMaximum{
    
    _START;
    [self deviceDataFetched:nil];
    _END;
}

@end
