//
//  UserVC.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 06/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"
#import "UserInfoView.h"
//#import "AlgorithmExecutor.h"
#import "ConnectionIndicatorView.h"
#import "RHRCIndicatorView.h"
#import "RRCIndicatorView.h"
#import "MetrixCell.h"
#import "DeviceOperation.h"
//#import "WFSensorCommonViewController.h"

//@class WFHeartrateConnection;

@interface UserVC : UIViewController<UITableViewDataSource, UITableViewDelegate, AlgorithmExecutorDelegate, HeartRateMonitorDelegate>{
    
    User              *_user;
    UserInfoView      *_userInfoView;
    DeviceOperation   *_deviceOperation;
    
    NSArray *_cellList;
    
    IBOutlet UITableViewCell *_heartMetricsCell;
    IBOutlet UITableViewCell *_fitterXMetricsCell;
    IBOutlet UITableViewCell *_distanceMetricsCell;
    IBOutlet UITableViewCell *_caloriesMetricsCell;
    
    __weak IBOutlet UIButton *_workoutButton;
    __weak IBOutlet UIButton *_shareButton;
    __weak IBOutlet UIButton *_accountButton;
    __weak IBOutlet UIButton *_stopWorkoutButton;
    
    //******************* not in use now ***************//
    __weak IBOutlet UILabel *_accountLabel;
    __weak IBOutlet UILabel *_shareLabel;
    __weak IBOutlet UILabel *_workoutLabel;
    //*************************************************************//
    
    __weak IBOutlet UITableView *_metricsTable;
    
    ConnectionIndicatorView *_connectionIndicator;
    RRCIndicatorView        *_rrIndicator;
    RHRCIndicatorView       *_rhrIndicator;
    FitterScoreBoard        *_currentScoreBoard;
    
    //// this will tell wether resting heart rate is fetched or not ////
    BOOL _rhrCalculated;
    
    UIView *_currentIndicator;
    
    //************************************************************
    __weak IBOutlet UILabel *_tempHR;
    __weak IBOutlet UILabel *_tempEHR;
    __weak IBOutlet UILabel *_tempRHR;
    __weak IBOutlet UILabel *_tempRHRScore;
    __weak IBOutlet UILabel *_tempRecoveryHeartRate;
    __weak IBOutlet UILabel *_tempRR;
    __weak IBOutlet UILabel *_tempRRScore;
    __weak IBOutlet UILabel *_tempBMI;
    __weak IBOutlet UILabel *_tempBFPC;
    __weak IBOutlet UILabel *_tempBFScore;
    __weak IBOutlet UILabel *_tempAvgExerciseHR;
    __weak IBOutlet UILabel *_tempSTC;
    __weak IBOutlet UILabel *_tempSTS;
    __weak IBOutlet UILabel *_tempMPMScore;
    __weak IBOutlet UILabel *_tempSpeed;
    __weak IBOutlet UILabel *_tempDistance;
    __weak IBOutlet UILabel *_tempFXRate;
    __weak IBOutlet UILabel *_tempFXScore;
    __weak IBOutlet UITextView *_tempFormulaList;
    __weak IBOutlet UIView *_tempView;
    __weak IBOutlet UIScrollView *_tempScroller;
    
}

@property(nonatomic, strong) User *user;
- (IBAction)shareInfo:(UIButton *)sender;
- (IBAction)workout:(UIButton *)sender;
- (IBAction)stopWorkout:(UIButton *)sender;
- (IBAction)showAccount:(UIButton *)sender;
@end
