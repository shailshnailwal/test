//
//  ResultVC.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultVC : UIViewController

@end
