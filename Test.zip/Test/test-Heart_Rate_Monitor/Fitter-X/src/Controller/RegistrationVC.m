//
//  RegistrationVC.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "RegistrationVC.h"
#import "UserOperation.h"
#import "UserVC.h"

/**
 * if any view is to be added as sub view, make sure that _infoLabelList and _contentViewList arrays s
 * Should be updated accordingly
 */

@implementation RegistrationVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self) {
        
        _user          = [[User alloc] init];
//        _userInfo      = [[NSMutableDictionary alloc] init];
        _monthList     = [[NSArray alloc] initWithObjects:@"January", @"February", @"March", @"April", @"May", @"June", @"July", @"August", @"September", @"October", @"November", @"December", nil];
        _genderList    = [[NSArray alloc] initWithObjects:@"Male", @"Female", nil];
        _infoLabelList = [[NSArray alloc] initWithObjects: @"Username and Password", @"Name", @"Gender", @"Age", @"Current Height", @"Current Weight", nil];
    }
    return self;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _saveButton.enabled = NO;
    
    //// make view sequenc ////
    _contentViewList = [[NSArray alloc] initWithObjects:_contentUsernameView, _contentNameView, _contentGenderView, _contentAgeView, _contentHeightView, _contentWeightView, nil];
    _contentToAdd         = _contentGenderView;
    _contentViewIndex     = 0;
    _pickerSuperViewIndex = -1;    
}

-(void) viewDidAppear:(BOOL)animated{
    
    _START;
    _END;
}

//#pragma mark- Kayboard Methods
//-(void)keyboardIsVisible{
//    
//    _START;
//    _END;
//}
//
//-(void)keyboardBecomeInvisible{
//    
//    _START;
//    _END;
//}
//
//-(BOOL) shouldAdjustViewOnKeyboardUpAndDown{
//    
//    _START;
//    _END;
//    return YES;
//}
//
//-(UIView *)viewToAdjustHeight{
//    
//    _START;
//    _END;
//    return _resizableView;
//}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)saveInformation:(UIButton *)sender {
    
//    _START;
    UIView *view = nil;
    BOOL   isUsernameView = false;
    CGRect frame = CGRectZero;
    //// show next content view ////
    _saveButton.enabled = NO;
    if (_contentViewIndex < _contentViewList.count - 1) {
        
        frame.origin = _containerView.frame.origin;
        _contentViewIndex ++;
        _pickerSuperViewIndex ++;
        view = [_contentViewList objectAtIndex:_contentViewIndex-1];
        isUsernameView = view == _contentUsernameView;
        [self subviewInView:view shouldBeActivate:NO];
        [view removeFromSuperview];
        view = [_contentViewList objectAtIndex:_contentViewIndex];
        
        frame.size = _containerView.frame.size;
        frame.origin = CGPointMake(0, 0);
        view.frame = frame;
        
        [self subviewInView:view shouldBeActivate:YES];
        [_containerView addSubview:view];
        
        //// setting title ////
        _infoLabel.text = [_infoLabelList objectAtIndex:_contentViewIndex];
    }
    else{
        
//        //if(LOGS_ON) NSLog(@"to register = %@",_userInfo);
        if (!_userOperator) {
            
            _userOperator = [[UserOperation alloc] init];
            _userOperator.delegate = self;
        }
//        sender.userInteractionEnabled = NO;
//        User *user = [[User alloc] init];
//        user.userInfo = _userInfo;
//        //if(LOGS_ON) NSLog(@"user information created to save = %@", _user.userInfo);
//        [UniversalTaskExecuter showAlertWithTitle:@"USER INFO" andMessage:[NSString stringWithFormat:@"%@", _user.userInfo] withButtonTitle:@"OK"];
        [_userOperator registerUserWithUserInfo:_user.userInfo];
    }
    
    NSLog(@"save content view index %2d and picker view index = %2d ", _contentViewIndex, _pickerSuperViewIndex);
//    _END;
}

- (IBAction)backToPreviousView:(id)sender {
    
//    _START;
    UIView *view = nil;
    BOOL   isUsernameView = false;
    //// show next content view ////
    if (_contentViewIndex > 0) {
        
        _contentViewIndex --;
        _pickerSuperViewIndex --;
        view = [_contentViewList objectAtIndex:_contentViewIndex+1];
        isUsernameView = view == _contentUsernameView;
        [self subviewInView:view shouldBeActivate:NO];
        [view removeFromSuperview];
        view = [_contentViewList objectAtIndex:_contentViewIndex];
        [self subviewInView:view shouldBeActivate:YES];
        [_containerView addSubview:view];
        
        //// setting title ////
        _infoLabel.text = [_infoLabelList objectAtIndex:_contentViewIndex];
    }
    else{
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    NSLog(@"back content view index %2d and picker view index = %2d ", _contentViewIndex, _pickerSuperViewIndex);
//    _END;
}

#pragma mark- USER OPERATION METHODS
-(void)userInfoAfterRegistrationCompletionSuccessfully:(User *)user withRegistrationResponse:(NSString *)responseString{
    
    _START;
    UserVC *userProfile = nil;
    //if(LOGS_ON) NSLog(@"User after registration = %@", user.userInfo);
    if (user) {
        
        ((AppNavigator *)self.navigationController).user = user;
        userProfile = [[UserVC alloc] init];
        [self.navigationController pushViewController:userProfile animated:YES];
    }
    else{
        
        [UniversalTaskExecuter showAlertWithTitle:@"Registration Error"
                                       andMessage:responseString
                                  withButtonTitle:@"OK"];
    }
    _END;
}

-(void)userRegistrationFail{
    
    _START;
    [UniversalTaskExecuter showAlertWithTitle:@"Server Error"
                                   andMessage:@"Server not reachable!"
                              withButtonTitle:@"OK"];
    _END;
}

#pragma mark-
//*************************** functions are not used *************************//
-(void) registerUser{
    
    _START;
    NSURL *serverUrl = [NSURL URLWithString:APPLICATION_URL];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:serverUrl];
    request.delegate = self;
    [request setDidFinishSelector:@selector(registrationProcessFinished:)];
    [request setDidFailSelector:@selector(registrationProcessFail:)];
    [request setPostValue:REGISTRATION     forKey:REQUEST_KEY];
    [request setPostValue:_usernameTF.text forKey:USERNAME_KEY];
    [request setPostValue:_passwordTF.text forKey:PASSWORD_KEY];
    [request startAsynchronous];
    _END;
}

-(void) registrationProcessFinished:(ASIHTTPRequest *)request{
    
    _START;
    NSDictionary *responseInfo = nil;
    if (request && request.responseData) {
        
        responseInfo = [NSJSONSerialization JSONObjectWithData:request.responseData
                                                       options:NSJSONReadingMutableContainers
                                                         error:nil];
    }
    //if(LOGS_ON) NSLog(@"response info = %@",responseInfo);
    _END;
}

-(void) registrationProcessFail:(ASIHTTPRequest *)request{
    
    _START;
    _END;
}
//****************************************************************************************

-(void) subviewInView : (UIView *)view shouldBeActivate:(BOOL)activate{
    
    NSArray *subviews = view.subviews;
    if (subviews) {
        
        for (UIView *view in subviews) {
            
            if (activate) {
                
                
                if ([view isKindOfClass:[UIPickerView class]]) {
                    
                    ((UIPickerView *)view).delegate   = self;
                    ((UIPickerView *)view).dataSource = self;
                    [((UIPickerView *)view) reloadAllComponents];
                    [((UIPickerView *)view) selectRow:0 inComponent:0 animated:NO];
                }
                else if ([view isKindOfClass:[UITextField class]]){
                    
                    ((UITextField *)view).delegate   = self;
                }
            }
            else{
                
                if ([view isKindOfClass:[UIPickerView class]]) {
                    
                    ((UIPickerView *)view).delegate   = nil;
                    ((UIPickerView *)view).dataSource = nil;
                }
                else if ([view isKindOfClass:[UITextField class]]){
                    
                    ((UITextField *)view).delegate   = nil;
                }
            }
        }
    }
}

#pragma mark- Picker view methods
-(NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    
    _START;
    _END;
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    //if(LOGS_ON) NSLog(@"components = %d", pickerView.numberOfComponents);
    
    int numberOfRows = 0;
    if (pickerView == _genderPicker) {
        
        
        //if(LOGS_ON) NSLog(@"gender picker");
        _pickerArray = _genderList;
        numberOfRows = _genderList.count;
    }
    else if (pickerView == _monthPicker){
        
        _pickerArray = _monthList;
        numberOfRows = _monthList.count;
    }
    else if (pickerView == _dayPicker){
        
        _pickerArray = nil;
        numberOfRows = 31;
    }
    else if (pickerView == _yearPicker){
        
        _pickerArray = nil;
        numberOfRows = 100;
    }
    else if (pickerView == _feetPicker){
        
        _pickerArray = nil;
        numberOfRows = 8;
    }
    else if (pickerView == _inchePicker){
        
        _pickerArray = nil;
        numberOfRows = 11;
    }
    else if (pickerView == _weightPicker){
        
        _pickerArray = nil;
        numberOfRows = 251;
    }
    
    //if(LOGS_ON) NSLog(@"Picker = %d", pickerView.tag);
    
    return numberOfRows;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    _START;
    NSString *title = nil;
    
    //if(LOGS_ON) NSLog(@"picker number = %d --- with array = %@",pickerView.tag,_pickerArray);
    
    if (pickerView == _genderPicker) {
        
        title = [_genderList objectAtIndex:row];
        //if(LOGS_ON) NSLog(@"title for array = %@",title);
    }
    else if (pickerView == _monthPicker){
        
        title = [_monthList objectAtIndex:row];
    }
    else if (pickerView == _yearPicker){
        
        title = [NSString stringWithFormat:@"%d", START_YEAR + row + 1];
    }
    else if (pickerView == _weightPicker){
        
        title = [NSString stringWithFormat:@"%d",row+50];
        //if(LOGS_ON) NSLog(@"title for number = %@",title);
    }
    else {
        
        title = [NSString stringWithFormat:@"%d",row+1];
        //if(LOGS_ON) NSLog(@"title for number = %@",title);
    }
    _END;
    return title;
}

-(void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    _START;
    if (pickerView == _genderPicker) {
        
//        [_userInfo setValue:[NSNumber numberWithInteger:(row == 0 ? GenderMale : GenderFemale)]
//                     forKey:USER_GENDER];
        if (row == 0) {
            
            _user.gender = GENDER_MALE_CHAR;
        }
        else if (row == 1){
            
            _user.gender = GENDER_FEMALE_CHAR;
        }
    }
    else if (pickerView == _dayPicker){
        
//        [_userInfo setValue:[NSNumber numberWithInteger:row+1] forKey:USER_DAY];
        _user.day = row + 1;
//        [_user getAge];
        
        //if(LOGS_ON) NSLog(@"age is = %d", _user.age);
    }
    else if (pickerView == _monthPicker){
        
//        [_userInfo setValue:[NSNumber numberWithInteger:row+1] forKey:USER_MONTH];
        _user.month = row + 1;
//        [_user getAge];
        
        //if(LOGS_ON) NSLog(@"age is = %d", _user.age);
    }
    else if (pickerView == _yearPicker){
        
//        [_userInfo setValue:[NSNumber numberWithInteger:row+1] forKey:USER_YEAR];
        _user.year = START_YEAR + row + 1;
//        [_user getAge];
        
        //if(LOGS_ON) NSLog(@"age is = %d", _user.age);
    }
    else if (pickerView == _feetPicker){
        
//        [_userInfo setValue:[NSNumber numberWithInteger:row+1] forKey:USER_HEIGHT_FEET];
        _user.heightFeet = row + 1;
    }
    else if (pickerView == _inchePicker){
        
//        [_userInfo setValue:[NSNumber numberWithInteger:row+1] forKey:USER_HEIGHT_INCHE];
        _user.heightInche = row + 1;
    }
    else if (pickerView == _weightPicker){
        
//        [_userInfo setValue:[NSNumber numberWithFloat:row+1] forKey:USER_WEIGHT];
        _user.weight = row + 50;
    }
    _saveButton.enabled = YES;
    _END;
}

#pragma mark- TextField Methods
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
    
    if (textField == _usernameTF) {
        
//        [_userInfo setValue:textField.text forKey:USER_USERNAME];
        _user.username = textField.text;
        
        BOOL validEmail = [UniversalTaskExecuter isValidEmail:_user.username Strict:YES];
        if (!validEmail) {
            
            _user.username = nil;
            _usernameTF.text = EMPTY_STRING;
            
            [UniversalTaskExecuter showAlertWithTitle:@"Invalid Field" andMessage:@"Username must be a valid email address!" withButtonTitle:@"OK"];
        }
    }
    else if (textField == _passwordTF){
        
//        [_userInfo setValue:textField.text forKey:USER_PASSWORD];
        _user.password = textField.text;
    }
    else if (textField == _firstNameTF){
        
        _user.firstName = textField.text;
    }
    else if (textField == _lastNameTF){
        
        _user.lastName = textField.text;
    }
    
    if (_usernameTF.text && ![_usernameTF.text isEqualToString:@""] &&
        _passwordTF.text && ![_passwordTF.text isEqualToString:@""]) {
        
        //if(LOGS_ON) NSLog(@"text fields filled");
        _saveButton.enabled = YES;
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [_usernameTF resignFirstResponder];
    [_passwordTF resignFirstResponder];
    [_firstNameTF resignFirstResponder];
    [_lastNameTF resignFirstResponder];
    return YES;
}
@end
