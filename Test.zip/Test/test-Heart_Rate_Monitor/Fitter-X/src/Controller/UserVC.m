//
//  UserVC.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 06/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "UserVC.h"

@implementation UserVC

@synthesize user = _user;

- (id)init
{
    self = [super init];
    if (self) {
        
        _deviceOperation = [[DeviceOperation alloc] init];
        _deviceOperation.delegate = self;
    }
    return self;
}

/**
 * to stop editing and resign keyboard
 */
//-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//    
//    _START;
//    [self.view endEditing:YES];
//    _END;
//}

- (void)viewDidLoad
{
    _START;
    [super viewDidLoad];
    
    //// prepare cell list ////
    _cellList = [[NSArray alloc] initWithObjects:_fitterXMetricsCell, _heartMetricsCell, _distanceMetricsCell, nil];
    
    //if(LOGS_ON) NSLog(@"user in user area = %@", ((AppNavigator *)self.navigationController).user.userInfo);
    
}

-(void) viewDidAppear:(BOOL)animated{
    
    _START;
    MBProgressHUD *progressHud = [MBProgressHUD showHUDAddedTo:APP_DELEGATE.window animated:YES];
    progressHud.labelText = @"Getting values for formula";
    
    //if(LOGS_ON) NSLog(@"started = ");
    [_deviceOperation getInputValuesFromServerForUserInfo:_user.userInfo];
    //if(LOGS_ON) NSLog(@"finished = ");
    
    _deviceOperation.user = ((AppNavigator *)self.navigationController).user;
    
    /*********************************************/
    _tempScroller.contentSize = _tempView.frame.size;
    _END;
}

#pragma mark- Bottom Bar Buttons
/**
 * Start workout
 */
- (IBAction)workout:(UIButton *)sender {
    
    _START;
    _workoutButton.selected = YES;
    _shareButton.selected   = NO;
    _accountButton.selected = NO;
    
    ////remove user information view if presented ////
    [_userInfoView removeFromSuperview];
    
    //// this function will get all indicators ////
    [self getIndicators];
    
    //// start connection indicators ////
//    [self showConnectionIndicator];
    _connectionIndicator.countDownView.keepCoutDownOn = YES;
    [self.view addSubview:_connectionIndicator];
    
    //// start initiation for algorithm ////
    //if(LOGS_ON) NSLog(@"startInitialDataFetch by workout button clicked");
    [_deviceOperation startInitialDataFetch];
    _END;
}

/**
 * Stop workout activity
 */
- (IBAction)stopWorkout:(UIButton *)sender {
    
    _START;
    sender.userInteractionEnabled = NO;
    
    //// set ending heart rate on stop work out clicked ////
    [_deviceOperation setEndingHeartRate];
    
    //// show indicator for recovery heart rate ////
    [self showRecoveryHeartRateIndicator];
    _stopWorkoutButton.hidden = YES;
    
    //// stop workout and get ending heart rate ////
    [_deviceOperation stopFrequentDeviceDataFetch];
    
    [self performSelector:@selector(enableButton:) withObject:sender afterDelay:3];
    _END;
}

-(void) enableButton:(UIButton *)btn{
    
    btn.userInteractionEnabled = YES;
}

/**
 * add account view if present
 */
- (IBAction)showAccount:(UIButton *)sender {
    
    _START;
    _workoutButton.selected = NO;
    _shareButton.selected   = NO;
    _accountButton.selected = YES;
    
    if (!_userInfoView) {
        
        _userInfoView = [[UserInfoView alloc] init];
        _userInfoView.navigator = self.navigationController;
        [_userInfoView setDefaults];
    }
    _userInfoView.frame = _metricsTable.frame;
    [_metricsTable.superview addSubview:_userInfoView];
    _END;
}

/**
 * show share view to share information with facebook
 */
- (IBAction)shareInfo:(UIButton *)sender {
    
    _START;
    
    _workoutButton.selected = NO;
    _shareButton.selected   = YES;
    _accountButton.selected = NO;
    
    //// remove user information view if presented ////
    [_userInfoView removeFromSuperview];
    
    NSString *shareString = @"I am using Fitter-X applicatoin";
    
    if (_currentScoreBoard) {
        
        shareString = [NSString stringWithFormat:@"%@\nMy last score is %f", shareString, _currentScoreBoard.fxmScore];
    }
    
    //// configure share view ////
    NSArray *objectsToShare = [[NSArray alloc] initWithObjects:shareString, nil];
    UIActivityViewController *activityController = [[UIActivityViewController alloc]initWithActivityItems:objectsToShare
                                                                                    applicationActivities:nil];
    
//    NSArray *excludedActivities = @[UIActivityTypePostToTwitter, UIActivityTypePostToFacebook,
//                                    UIActivityTypePostToWeibo,
//                                    UIActivityTypeMessage, UIActivityTypeMail,
//                                    UIActivityTypePrint, UIActivityTypeCopyToPasteboard,
//                                    UIActivityTypeAssignToContact, UIActivityTypeSaveToCameraRoll,
//                                    UIActivityTypeAddToReadingList, UIActivityTypePostToFlickr,
//                                    UIActivityTypePostToVimeo, UIActivityTypePostToTencentWeibo];
//     activityController.excludedActivityTypes = excludedActivities;
    
    [self presentViewController:activityController animated:YES completion:nil];
    
    //// set completion block for share activity ////
    [activityController setCompletionHandler:^(NSString *activityType, BOOL completed)
     {
         
         if (completed){
             
             [UniversalTaskExecuter showAlertWithTitle:@""
                                            andMessage:@"Post completed"
                                       withButtonTitle:@"OK"];
             sender.selected = NO;
         }
         else{
             
             [UniversalTaskExecuter showAlertWithTitle:@""
                                            andMessage:@"Post aborted"
                                       withButtonTitle:@"OK"];
             sender.selected = NO;

         }
     }
    ];
}

#pragma mark- Make, Show and Remove Indicators
/**
 * make indicators
 */
-(void) getIndicators{
    
    _START;
    if (!_connectionIndicator) {
        
        _connectionIndicator = [[ConnectionIndicatorView alloc] init];
        _connectionIndicator.frame = self.view.frame;
        _connectionIndicator.countDownView.showNumber        = NO;
        _connectionIndicator.countDownView.maximumCount      = TIME_OUT_CONNECTION;
        _connectionIndicator.countDownView.indicatorDelegate = _connectionIndicator;
        _connectionIndicator.delegate                        = self;
    }
    
    if (!_rhrIndicator) {
        
        _rhrIndicator = [[RHRCIndicatorView alloc] init];
        
        _rhrIndicator.countDownView.maximumCount      = TIME_OUT_RESTING_HEART_RATE;
        _rhrIndicator.countDownView.indicatorDelegate = _rhrIndicator;
        _rhrIndicator.countDownView.showNumber        = YES;
        _rhrIndicator.frame                           = self.view.frame;
        _rhrIndicator.delegate                        = self;
    }
    
    if (!_rrIndicator) {
        
        _rrIndicator = [[RRCIndicatorView alloc] init];
        
        _rrIndicator.countDownView.maximumCount      = TIME_OUT_RECOVERY_HEART_RATE;
        _rrIndicator.countDownView.indicatorDelegate = _rhrIndicator;
        _rrIndicator.countDownView.showNumber        = YES;
        _rrIndicator.frame                           = self.view.frame;
        _rrIndicator.delegate                        = self;
    }
    _END;
}

/**
 * ramove connection indicator
 */
-(void)removeConnectionIndicator{
    
    _START;
    _connectionIndicator.countDownView.keepCoutDownOn = NO;
    [_connectionIndicator removeFromSuperview];
//    _connectionIndicator = nil;
//    _currentIndicator = nil;
    _END;
}

/**
 * show connection indicator
 */
-(void)showConnectionIndicator{
    
    _START;
    //// remove other indicators ////
//    [self removeRecoveryHeartRateIndicator];
//    [self removeRestingHeartRateIndicator];
    
    _connectionIndicator = nil;
    [self getIndicators];
    
    _currentIndicator = _connectionIndicator;
    _connectionIndicator.countDownView.keepCoutDownOn = YES;
    [self.view addSubview:_connectionIndicator];
    [_deviceOperation connectToHardware];
    _END;
}

/**
 * ramove resting heart rate indicator
 */
-(void)removeRestingHeartRateIndicator{
    
    _START;
    _rhrIndicator.countDownView.keepCoutDownOn = NO;
    [_rhrIndicator removeFromSuperview];
//    _rhrIndicator = nil;
//    _currentIndicator = nil;
    _END;
}

/**
 * show resting heart rate indicator
 */
-(void)showRestingHeartRateIndicator{
    
    _START;
    //// remove other indicators ////
//    [self removeConnectionIndicator];
//    [self removeRecoveryHeartRateIndicator];
    
    _rhrIndicator = nil;
    [self getIndicators];
    
    _currentIndicator = _rhrIndicator;
    _rhrIndicator.countDownView.keepCoutDownOn = YES;
    [self.view addSubview:_rhrIndicator];
    _END;
}

/**
 * ramove recovery heart rate indicator
 */
-(void)removeRecoveryHeartRateIndicator{
    
    _START;
    _rrIndicator.countDownView.keepCoutDownOn = NO;
    [_rrIndicator removeFromSuperview];
//    _currentIndicator = nil;
//    _rrIndicator = nil;
   // [_deviceOperation setRecoveryHeartRate];
    _END;
}

/**
 * show recovery heart rate indicator
 */
-(void)showRecoveryHeartRateIndicator{
    
    _START;
    //// remove other indicators ////
//    [self removeConnectionIndicator];
//    [self removeRestingHeartRateIndicator];
    
    //if(LOGS_ON) NSLog(@"to show rr indicator = %@", _rrIndicator);
    
    _rrIndicator = nil;
    [self getIndicators];
    
    _currentIndicator = _rrIndicator;
    
    _rrIndicator.countDownView.keepCoutDownOn = YES;
    [self.view addSubview:_rrIndicator];
    _END;
}

/**
 * this function will remove all the indicators from view
 */
-(void) removeAllIndicators{
    
    _END;
    [self removeConnectionIndicator];
    [self removeRestingHeartRateIndicator];
    [self removeRecoveryHeartRateIndicator];
    _END;
}


#pragma mark- Heart Rate Device Custom Methods
-(void) algorithmExecutionConnectionFail{
    
    _START;
    [self removeConnectionIndicator];
    _END;
}

-(void) algorithmExecutionConnectionEstablished{
    
    _START;
    NSLog(@"in user vc after connection established");
//    [UniversalTaskExecuter showAlertWithTitle:@"Connection Alert" andMessage:@"Device is deviceConnectionEstablished" withButtonTitle:@"OK"];
    [self removeConnectionIndicator];
    [self showRestingHeartRateIndicator];
    _END;
}

-(void)heartRateMonitorDeviceConnected{
    
    _START;
    [self removeConnectionIndicator];
    [self showRestingHeartRateIndicator];
    _END;
}

/**
 * this function will do the following
 * -- request for resting heart rate
 * -- request for recovery heart rate
 * -- start continuous heart rate and distance datafetch for continuous algorith execuation
 */
-(void)heartRateMonitorCurrentHeartRateFetch{
    
    _START;
    
    if (!_rhrCalculated) {
        
        _rhrCalculated = YES;
        [_deviceOperation setRestingHeartRate];
    }
    else{
        
        _rhrCalculated = NO;
        [_deviceOperation setRecoveryHeartRate];
    }
    
    //if(LOGS_ON) NSLog(@"last current indicator = %@",_currentIndicator);
    
    //// show stop workout button after resting heart rate fetched ////
    if (_stopWorkoutButton.hidden && _currentIndicator == _rhrIndicator) {
        
        _stopWorkoutButton.hidden = NO;
        
        //// start workout activity ////
        [_deviceOperation startFrequentDeviceDataFetch];
        [self removeRestingHeartRateIndicator];
    }
    else if (_currentIndicator == _rrIndicator){
        
        [self removeRecoveryHeartRateIndicator];
    }
    
    [self removeConnectionIndicator];
    _END;
}

#pragma mark- Algorithm Executer Methods
-(void) algorithmExecutionIntermediateResultFound:(FitterScoreBoard *)resultInfo{
    
    _START;
//    [UniversalTaskExecuter showAlertWithTitle:@"Algorithm" andMessage:@"Intermidiate result" withButtonTitle:@"OK"];
    //if(LOGS_ON) NSLog(@"result object = %@", resultInfo);
    _currentScoreBoard = resultInfo;
    [_metricsTable reloadData];
    _tempHR.text                = [NSString stringWithFormat:@"%f", resultInfo.hrmValue];
    _tempEHR.text               = [NSString stringWithFormat:@"%f", resultInfo.hrmEHR];
    _tempRHR.text               = [NSString stringWithFormat:@"%f", resultInfo.hrmRestingRate];
    _tempRHRScore.text          = [NSString stringWithFormat:@"%f", resultInfo.hrmRestingRateScore];
    _tempRecoveryHeartRate.text = [NSString stringWithFormat:@"%f", resultInfo.hrmRecoveryHR];
    _tempRR.text                = [NSString stringWithFormat:@"%f", resultInfo.hrmRecoveryRate];
    _tempRRScore.text           = [NSString stringWithFormat:@"%f", resultInfo.hrmRecoveryRateScore];
    _tempBMI.text               = [NSString stringWithFormat:@"%f", resultInfo.bmi];
    _tempBFPC.text              = [NSString stringWithFormat:@"%f", resultInfo.bfp];
    _tempBFScore.text           = [NSString stringWithFormat:@"%f", resultInfo.bfs];
    _tempAvgExerciseHR.text     = [NSString stringWithFormat:@"%f", resultInfo.hrmAvgExerciseHR];
    _tempSTS.text               = [NSString stringWithFormat:@"%f", resultInfo.stScore];
    _tempMPMScore.text          = [NSString stringWithFormat:@"%f", resultInfo.dmMPMScore];
    _tempSpeed.text             = [NSString stringWithFormat:@"%f", resultInfo.dmCurrentSpeed];
    _tempDistance.text          = [NSString stringWithFormat:@"%f", resultInfo.dmDistance];
    _tempFXRate.text            = [NSString stringWithFormat:@"%f", resultInfo.fxmRate];
    _tempFXScore.text           = [NSString stringWithFormat:@"%f", resultInfo.fxmScore];
//    _tempFormulaList.text       = resultInfo.formulaString; //stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@" \n"]];
//    resultInfo.formulaString    = @"";

    _END;
}

-(void) algorithmExecutionEndedWithResultFound:(FitterScoreBoard *)resultInfo{
    
    _START;
//    [UniversalTaskExecuter showAlertWithTitle:@"Algorithm" andMessage:@"Final result" withButtonTitle:@"OK"];
    _currentScoreBoard = resultInfo;
    _END;
}

-(void) algorithmExecutionFoundInputInfo:(NSDictionary *)inputInfo{
    
    _START;
    [MBProgressHUD hideAllHUDsForView:APP_DELEGATE.window animated:YES];
//    [UniversalTaskExecuter showAlertWithTitle:@"Alert" andMessage:@"Pass" withButtonTitle:@"OK"];
    _END;
}

-(void) algorithmExecutionFailToFindInputInfo{
    
    _START;
    [MBProgressHUD hideAllHUDsForView:APP_DELEGATE.window animated:YES];
//    [UniversalTaskExecuter showAlertWithTitle:@"Alert" andMessage:@"Fail" withButtonTitle:@"OK"];
    _END;
}

#pragma mark- Table Methods
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    _START;
    int numberOfRows = 0;
    if (_cellList && _cellList.count > 0) {
        
        numberOfRows = (int)_cellList.count;
    }
    //if(LOGS_ON) NSLog(@"number of rows = %d", numberOfRows);
    _END;
    return numberOfRows;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    _START;
    CGFloat rowHeight = 0;
    UIView *view = nil;
    if (_cellList && _cellList.count > indexPath.row) {
        
        view = [_cellList objectAtIndex:indexPath.row];
        rowHeight = view.frame.size.height;
    }
    return rowHeight;
    _END;
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MetrixCell *cell = nil;
    if (_cellList && _cellList.count > indexPath.row) {
        
        cell = [_cellList objectAtIndex:indexPath.row];
        cell.indexPath = indexPath;
    }
    cell.scoreBoard = _currentScoreBoard;
    return cell;
}

//******************************************************************
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    //if(LOGS_ON) NSLog(@"low memory");
}
@end
