//
//  UserInfoView.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 22/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserOperation.h"

enum TagType {
    
        TagTypeHeader,
        TagTypeInfo,
        TagTypeEditInfo
    };

@protocol UserViewProtocol <NSObject>
    @optional
        -(void) userLogoutRequested;
@end

@interface ServerResponse : NSObject{
    
    ASIHTTPRequest *_response;
    BOOL           _isRequestFinished;
}

@property(nonatomic, strong) ASIHTTPRequest *response;
@property(nonatomic, assign) BOOL           isRequestFinished;
@end

@interface UserInfoView : UIView<UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate, KbDelegate>{
    
    //// for input views ////
    IBOutlet UIView *_contentGenderView;
    IBOutlet UIView *_contentAgeView;
    IBOutlet UIView *_contentHeightView;
    IBOutlet UIView *_contentWeightView;
    
    //// pickers in input views ////
    __weak IBOutlet UIPickerView *_genderPicker;
    __weak IBOutlet UIPickerView *_dayPicker;
    __weak IBOutlet UIPickerView *_monthPicker;
    __weak IBOutlet UIPickerView *_yearPicker;
    __weak IBOutlet UIPickerView *_feetPicker;
    __weak IBOutlet UIPickerView *_inchePicker;
    __weak IBOutlet UIPickerView *_weightPicker;
    
    //// containers ////
    __weak IBOutlet UIScrollView *_bgScroller;
    __weak IBOutlet UIView *_mainView;
    
    //// user info edit textFields ////
    __weak IBOutlet UITextField *_genderTF;
    __weak IBOutlet UITextField *_feetTF;
    __weak IBOutlet UITextField *_incheTF;
    __weak IBOutlet UITextField *_weightTF;
    __weak IBOutlet UITextField *_monthTF;
    __weak IBOutlet UITextField *_dayTF;
    __weak IBOutlet UITextField *_yearTF;
    
    //// user info show labels ////
    __weak IBOutlet UILabel *_genderLabel;
    __weak IBOutlet UILabel *_feetLabel;
    __weak IBOutlet UILabel *_incheLabel;
    __weak IBOutlet UILabel *_weightLabel;
    __weak IBOutlet UILabel *_monthLabel;
    __weak IBOutlet UILabel *_dayLabel;
    __weak IBOutlet UILabel *_yearLabel;
    
    
    __weak IBOutlet UIButton *_genderSaveBtn;
    __weak IBOutlet UIButton *_heightSaveBtn;
    __weak IBOutlet UIButton *_weightSaveBtn;
    __weak IBOutlet UIButton *_dobSaveBtn;
    
    __weak IBOutlet UIButton *_genderCancelBtn;
    __weak IBOutlet UIButton *_heightCancelBtn;
    __weak IBOutlet UIButton *_weightCancelBtn;
    __weak IBOutlet UIButton *_dobCancelBtn;
    IBOutlet UIToolbar *_accessoryToolbar;
    
    IBOutlet UIButton *_logoutBtn;
    
    __weak IBOutlet UIImageView *_bottomTextImage;
    //// picker arrays ////
    NSArray *_genderList;
    NSArray *_monthList;
    NSArray *_pickerArray;
    UINavigationController *_navigator;
    
    //// to hold active textfield ////
    UITextField *_activeTF;
    
    //// for user operations ////
    UserOperation *_userOperator;
    User *_user;
    
    //// Response Array ////
    NSMutableArray *_responseArray;
}

@property(nonatomic, strong) UINavigationController *navigator;


// Set default values for the view //
- (IBAction)tapOnView:(id)sender;
-(void) setDefaults;
- (IBAction)saveInfo:(id)sender;
- (IBAction)showAndHideEditView:(id)sender;
- (IBAction)doneEditing:(id)sender;
- (IBAction)userLogout:(UIButton *)sender;

@end
