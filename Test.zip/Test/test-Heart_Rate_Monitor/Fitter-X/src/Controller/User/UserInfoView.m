//
//  UserInfoView.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 22/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "UserInfoView.h"

@implementation UserInfoView

@synthesize navigator = _navigator;

- (id)init
{
    
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"UserInfoView" owner:nil options:nil];
    UserInfoView *userInfoView = nil;
    
    for (int i = 0; nibs != nil && i < nibs.count; i ++) {
        
        UIView *view = [nibs objectAtIndex:i];
        if ([view isKindOfClass:[UserInfoView class]]) {
            
            userInfoView = (UserInfoView *)view;
        }
    }
    return userInfoView;
}

/**
 * this function will set navigation cantroll and it's property
 */
-(void)setNavigator:(UINavigationController *)navigator{
    
    _START;
    _navigator = navigator;
    ((AppNavigator *)_navigator).kbDelegate = self;
    _END;
}

/**
 * tab on view response
 */
- (IBAction)tapOnView:(id)sender {
    
}

/**
 * Set default values for the view
 */
-(void) setDefaults{
    
    _START;
    //// setting input view frames ////
    CGRect inputViewFrame = CGRectMake(0, 0, 320, 164);
    
    _contentAgeView.frame    = inputViewFrame;
    _contentGenderView.frame = inputViewFrame;
    _contentHeightView.frame = inputViewFrame;
    _contentWeightView.frame = inputViewFrame;
    
    //// registered user ////
    User *user = ((AppNavigator *)_navigator).user;
    
    _bgScroller.contentSize = _mainView.frame.size;
    
    _monthList     = [[NSArray alloc] initWithObjects:@"January", @"February", @"March", @"April", @"May", @"June", @"July", @"August", @"September", @"October", @"November", @"December", nil];
    _genderList    = [[NSArray alloc] initWithObjects:@"Male", @"Female", nil];
    
    //// input views for textfields ////
    _genderTF.inputView = _contentGenderView;
    _feetTF.inputView   = _contentHeightView;
    _incheTF.inputView  = _contentHeightView;
    _weightTF.inputView = _contentWeightView;
    _dayTF.inputView    = _contentAgeView;
    _monthTF.inputView  = _contentAgeView;
    _yearTF.inputView   = _contentAgeView;
    
    //// input accessory views for textfields ////
    _genderTF.inputAccessoryView = _accessoryToolbar;
    _feetTF.inputAccessoryView   = _accessoryToolbar;
    _incheTF.inputAccessoryView  = _accessoryToolbar;
    _weightTF.inputAccessoryView = _accessoryToolbar;
    _dayTF.inputAccessoryView    = _accessoryToolbar;
    _monthTF.inputAccessoryView  = _accessoryToolbar;
    _yearTF.inputAccessoryView   = _accessoryToolbar;
    
    _user = [[User alloc] init];
    _user.userInfo = user.userInfo;
    //if(LOGS_ON) NSLog(@"user of navigation controller = %@ with copy = %@", user.userInfo, _user.userInfo);
    
    [self setLabelFromUser:_user];
    _END;
}

- (IBAction)saveInfo:(id)sender {
    
    //if(LOGS_ON) NSLog(@"saving logic to save = %@", _user.userInfo);
    NSMutableDictionary *param = [NSMutableDictionary dictionaryWithDictionary:_user.userInfo];
    [param setValue:@"UPDATE_PHYSICAL_PROPERTIES" forKey:@"OPERATION"];
    
    AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:APPLICATION_LOCATION]];
    
    
    NSMutableURLRequest *afRequest = [httpClient multipartFormRequestWithMethod:@"POST"
                                                                           path:APPLICATION_INDEX
                                                                     parameters:param
                                                      constructingBodyWithBlock:^(id <AFMultipartFormData>formData)
                                                        {
                                          
                                                        }
                                      ];
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:afRequest];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        // convert to JSON
//        SBJSON *parser = [[SBJSON alloc] init];
        NSString *decodedString = nil;
        //if(LOGS_ON) NSLog(@"response  = %@", decodedString);
        User *user = ((AppNavigator *)_navigator).user;
        BOOL updationSuccessfull = NO;
        if (responseObject) {
            
            decodedString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        }
        
        if (decodedString) {
            
            updationSuccessfull = decodedString.boolValue;
        }
        
        if (updationSuccessfull) {
            
            user.userInfo = _user.userInfo;
            [self setLabelFromUser:_user];
            [UniversalTaskExecuter showAlertWithTitle:@"Account Updation"
                                           andMessage:@"User account updated"
                                      withButtonTitle:@"OK"];
        }
        else{
            
            _user.userInfo = user.userInfo;
            [UniversalTaskExecuter showAlertWithTitle:@"Account Updation"
                                           andMessage:@"User account updated"
                                      withButtonTitle:@"OK"];
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [UniversalTaskExecuter showAlertWithTitle:@"Account Updation"
                                       andMessage:@"User account did not update due to some network problem"
                                  withButtonTitle:@"OK"];
        
    }];
    [operation start];
    
    [self changeViewsForButton:sender];
}

/**
 * Show and hide edit view
 */
- (IBAction)showAndHideEditView:(id)sender {
    
    _START;
    User *user = ((AppNavigator *)_navigator).user;
    [self changeViewsForButton:sender];
    if (sender == _genderCancelBtn) {
    
        _user.gender = user.gender;
    }
    else if(sender == _heightCancelBtn){
        
        _user.heightFeet = user.heightFeet;
        _user.heightInche = user.heightInche;
    }
    else if (sender == _weightCancelBtn){
        
        _user.weight = user.weight;
    }
    else if (sender == _dobCancelBtn){
        
        _user.day = user.day;
        _user.month = user.month;
        _user.year = user.year;
    }
    
    //if(LOGS_ON) NSLog(@"after chaing user info = %@", _user.userInfo);
    _END;
}

/**
 * to finish editing for textfield
 */
- (IBAction)doneEditing:(id)sender {
    
    _START;
    [_activeTF resignFirstResponder];
    _END;
}

/**
 * user logout
 */
- (IBAction)userLogout:(UIButton *)sender{
    
    [_navigator popToRootViewControllerAnimated:YES];
}

/**
 * this function will change the view for partidular button
 */
-(void) changeViewsForButton:(UIButton *)changingButton{
    UIView *mainView = changingButton;
    NSArray *subviews = nil;
    UIView *view = nil;
    
    //// creating user if not persent ////
    if (!_user) {
        
        _user   = [[User alloc] init];
    }
    
    if (mainView) {
        
        mainView = mainView.superview;
    }
    else{
        
        mainView = nil;
    }
    
    if (mainView) {
        
        mainView = mainView.superview;
    }
    else{
        
        mainView = nil;
    }
    
    if (mainView) {
        
        subviews = mainView.subviews;
    }
    
    //// hiding and showing edit view ////
    if (subviews) {
        
        for (int i = 0; i < subviews.count; i++) {
            
            view = [subviews objectAtIndex:i];
            if ([view isKindOfClass:[UIView class]] && view.tag != TagTypeHeader) {
                
                view.hidden = !view.hidden;
            }
        }
    }
}

#pragma mark- Kayboard Methods
-(void)keyboardIsVisible{
    
    _START;
    _END;
}

-(void)keyboardBecomeInvisible{
    
    _START;
    _END;
}

-(BOOL) shouldAdjustViewOnKeyboardUpAndDown{
    
    _START;
    _END;
    return YES;
}

-(UIView *)viewToAdjustHeight{
    
    _START;
    _END;
    return _bgScroller;
}

#pragma mark- Picker view methods
-(NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    
    _START;
    _END;
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    //if(LOGS_ON) NSLog(@"components = %d", pickerView.numberOfComponents);
    
    int numberOfRows = 0;
    if (pickerView == _genderPicker) {
        
        //if(LOGS_ON) NSLog(@"gender picker");
        _pickerArray = _genderList;
        numberOfRows = _genderList.count;
    }
    else if (pickerView == _monthPicker){
        
        _pickerArray = _monthList;
        numberOfRows = _monthList.count;
    }
    else if (pickerView == _dayPicker){
        
        _pickerArray = nil;
        numberOfRows = 31;
    }
    else if (pickerView == _yearPicker){
        
        _pickerArray = nil;
        numberOfRows = 100;
    }
    else if (pickerView == _feetPicker){
        
        _pickerArray = nil;
        numberOfRows = 8;
    }
    else if (pickerView == _inchePicker){
        
        _pickerArray = nil;
        numberOfRows = 11;
    }
    else if (pickerView == _weightPicker){
        
        _pickerArray = nil;
        numberOfRows = 251;
    }
    
    //if(LOGS_ON) NSLog(@"Picker = %d", pickerView.tag);
    
    return numberOfRows;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    _START;
    NSString *title = nil;
    
    //if(LOGS_ON) NSLog(@"picker number = %d --- with array = %@",pickerView.tag,_pickerArray);
    
    if (pickerView == _genderPicker) {
        
        title = [_genderList objectAtIndex:row];
        //if(LOGS_ON) NSLog(@"title for array = %@",title);
    }
    else if (pickerView == _monthPicker){
        
        title = [_monthList objectAtIndex:row];
    }
    else if (pickerView == _yearPicker){
        
        title = [NSString stringWithFormat:@"%d", START_YEAR + row + 1];
    }
    else if (pickerView == _weightPicker){
        
        title = [NSString stringWithFormat:@"%d", row + 50];
    }
    else{
        
        title = [NSString stringWithFormat:@"%d",row+1];
        //if(LOGS_ON) NSLog(@"title for number = %@",title);
    }
    _END;
    return title;
}

-(void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    _START;
    if (pickerView == _genderPicker) {
        
        if (row == 0) {
            
            _user.gender = GENDER_MALE_CHAR;
        }
        else if (row == 1){
            
            _user.gender = GENDER_FEMALE_CHAR;
        }
        _genderTF.text = [_genderList objectAtIndex:row];
    }
    else if (pickerView == _dayPicker){
        
        _user.day = row + 1;
        [_user getAge];
        _dayTF.text = [NSString stringWithFormat:@"%d", _user.day];
        //if(LOGS_ON) NSLog(@"age is = %d", _user.age);
    }
    else if (pickerView == _monthPicker){
        
        _user.month = row + 1;
        [_user getAge];
        _monthTF.text = [NSString stringWithFormat:@"%d", _user.month];
        //if(LOGS_ON) NSLog(@"age is = %d", _user.age);
    }
    else if (pickerView == _yearPicker){
        
        _user.year = row + 1 + START_YEAR;
        [_user getAge];
        _yearTF.text = [NSString stringWithFormat:@"%d", _user.year];
        //if(LOGS_ON) NSLog(@"age is = %d", _user.age);
    }
    else if (pickerView == _feetPicker){
        
        _user.heightFeet = row + 1;
        _feetTF.text     = [NSString stringWithFormat:@"%d", _user.heightFeet];
    }
    else if (pickerView == _inchePicker){
        
        _user.heightInche = row + 1;
        _incheTF.text     = [NSString stringWithFormat:@"%d", _user.heightInche];
    }
    else if (pickerView == _weightPicker){
        
        _user.weight   = row + 50;
        _weightTF.text = [NSString stringWithFormat:@"%.1f", _user.weight];
    }
    
    //if(LOGS_ON) NSLog(@"after selecting, user info = %@", _user.userInfo);
    _END;
}

#pragma mark- TextField Methods
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
    _START;
    _activeTF = textField;
    _END;
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
    _START;
    _activeTF = nil;
    _END;
}

//// *********** fill textfields ************** ////
-(void) setTextFieldFromUser:(User *) user{
    
    _genderTF.text  = user.gender;
    _feetTF.text    = [NSString stringWithFormat:@"%d", user.heightFeet];
    _incheTF.text   = [NSString stringWithFormat:@"%d", user.heightInche];
    _weightTF.text  = [NSString stringWithFormat:@"%.1f", user.weight];
    _dayTF.text     = [NSString stringWithFormat:@"%d", user.day];
    _monthTF.text   = [NSString stringWithFormat:@"%d", user.month];
    _yearTF.text    = [NSString stringWithFormat:@"%d", user.year];
    
}

//// *********** set textField's placeholders ************** ////
-(void) setTextFieldPlaceholdersFromUser:(User *) user{
    
    _genderTF.placeholder  = user.gender;
    _feetTF.placeholder    = [NSString stringWithFormat:@"%d", user.heightFeet];
    _incheTF.placeholder   = [NSString stringWithFormat:@"%d", user.heightInche];
    _weightTF.placeholder  = [NSString stringWithFormat:@"%.1f", user.weight];
    _dayTF.placeholder     = [NSString stringWithFormat:@"%d", user.day];
    _monthTF.placeholder   = [NSString stringWithFormat:@"%d", user.month];
    _yearTF.placeholder    = [NSString stringWithFormat:@"%d", user.year];
}

//// *********** fill labels ************** ////
-(void) setLabelFromUser:(User *) user{
    
    _genderLabel.text = [user.gender isEqualToString:GENDER_MALE_CHAR] ? @"Male" : @"Female";
    _feetLabel.text    = [NSString stringWithFormat:@"%d", user.heightFeet];
    _incheLabel.text   = [NSString stringWithFormat:@"%d", user.heightInche];
    _weightLabel.text  = [NSString stringWithFormat:@"%.1f", user.weight];
    _dayLabel.text     = [NSString stringWithFormat:@"%d", user.day];
    _monthLabel.text   = [NSString stringWithFormat:@"%d", user.month];
    _yearLabel.text    = [NSString stringWithFormat:@"%d", user.year];
}

//************************************************************************************
- (IBAction)clicked:(id)sender {
    
    _START;
    _END;
}
@end
