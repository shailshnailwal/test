//
//  AppNavigator.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"

@protocol KbDelegate <NSObject>
    -(void) keyboardIsVisible;
    -(void) keyboardBecomeInvisible;
    -(BOOL) shouldAdjustViewOnKeyboardUpAndDown;
    -(UIView *) viewToAdjustHeight;
@end

@interface AppNavigator : UINavigationController{
    
    User *_user;
    NSDictionary *_inputInfo;
    
    id<KbDelegate>    _kbDelegate;
    CGFloat _height;
    NSInteger _tag;
}

@property(nonatomic, strong) User *user;
@property(nonatomic, strong) id<KbDelegate> kbDelegate;
@property(nonatomic, strong) NSDictionary *inputInfo;

@end
