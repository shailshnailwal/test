//
//  KeyboardHandlingVC.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 24/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * this class will be useful only for keyboard event
 * if you want your scroll view do not get behind the keyboard
 * this class can help by becoming super class of any class
 * just remember: scroll view should be used by adding as sub view of same size in another view
 * this doesn't make any sence, but still in some cases you need it
 */
@interface KeyboardHandlingVC : UIViewController<KbDelegate>{
    
    @protected
    IBOutlet UIScrollView *_resizableView;
}

@end
