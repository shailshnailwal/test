//
//  AppNavigator.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "AppNavigator.h"
#import "LoginVC.h"

@implementation AppNavigator

@synthesize user = _user;
@synthesize kbDelegate = _kbDelegate;
@synthesize inputInfo = _inputInfo;

-(void)setKbDelegate:(id<KbDelegate>)kbDelegate{
    
    _kbDelegate = kbDelegate;
    //if(LOGS_ON) NSLog(@"delegate came to be set = %@", kbDelegate);
}

-(void)setUser:(User *)user{
    
    //if(LOGS_ON) NSLog(@"in navigatin user is found as = %@", user);
    if (user) {
        
        _user = [[User alloc] init];
        _user.userInfo = user.userInfo;
        //if(LOGS_ON) NSLog(@"in navigatin user is found as = %@", user.userInfo);
    }
}

- (void)viewDidLoad
{
    _START;
    [super viewDidLoad];
    self.navigationBar.hidden = YES;
    LoginVC *login = [[LoginVC alloc] init];
    [self pushViewController:login animated:NO];
    
    //// for keyboard notification ////
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardUp:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDown:)
                                                 name:UIKeyboardDidHideNotification
                                               object:nil];
    _END;
}

-(void) viewWillAppear:(BOOL)animated{
    
    _START;
    _END;
}

-(void) viewDidAppear:(BOOL)animated{
    
    _START;
    _END;
}

-(void) keyboardUp: (NSNotification *) notification{
    
    _START;
    BOOL shouldChangeFrame = NO;
    UIView *view = nil;
    CGFloat keyboardHeight = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size.height;
    
    //if(LOGS_ON) NSLog(@"delegate is set as %@", _kbDelegate);
    
    if ([_kbDelegate respondsToSelector:@selector(keyboardIsVisible)]) {
        
        //if(LOGS_ON) NSLog(@"responds keyboardIsVisible");
        [_kbDelegate keyboardIsVisible];
    }
    
    if ([_kbDelegate respondsToSelector:@selector(shouldAdjustViewOnKeyboardUpAndDown)]) {
        
        //if(LOGS_ON) NSLog(@"responds shouldAdjustScrollViewWhenKeyboardUpAndDown");
        shouldChangeFrame = [_kbDelegate shouldAdjustViewOnKeyboardUpAndDown];
    }
    
    if (shouldChangeFrame) {
        
        
        //if(LOGS_ON) NSLog(@"shouldChangeFrame");
        if ([_kbDelegate respondsToSelector:@selector(viewToAdjustHeight)]) {
            
            //if(LOGS_ON) NSLog(@"responds scrollViewToAdjustHeight");
            view = [_kbDelegate viewToAdjustHeight];
        }
        
        if (view != nil) {
            
            //if(LOGS_ON) NSLog(@"scrolll view = %@", view);
            view.frame = [self reducedFrameForView:view forKeyBoardHeight:keyboardHeight];
        }
    }
    _END;
}

-(CGRect) reducedFrameForView:(UIView *)view forKeyBoardHeight:(CGFloat)keyboardHeight{
    
    _START;
    CGRect frame = view.frame;
    //if(LOGS_ON) NSLog(@"tage of view = %d", view.tag);
    CGPoint point = [view convertPoint:view.frame.origin toView:nil];
    CGFloat areaHeight = point.y + view.frame.size.height;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    CGFloat heightToReduce = areaHeight - (screenHeight - keyboardHeight);
    
    //if(LOGS_ON) NSLog(@"actual point (%f, %f)\n window point (%f, %f) \n area height = %f\n screen height = %f\n to reduce = %f\n keyboard height = %f", view.frame.origin.x, view.frame.origin.y, point.x, point.y, areaHeight, screenHeight, heightToReduce, keyboardHeight);
    
    if (heightToReduce >= 0 && view.tag != -1) {
        
        _height           =  heightToReduce + 5;
        _tag              =  view.tag;
        view.tag          =  -1;
        frame.size.height -= _height;
    }
    _END;
    return frame;
}

-(CGRect) increasedFrameForView:(UIView *)view{
    
    CGRect frame = view.frame;
    if (_height > 0) {
        
        frame.size.height += _height;
        view.tag          =  _tag;
    }
    return frame;
}

-(void) keyboardDown: (NSNotification *) notification{
    
    BOOL shouldChangeFrame = NO;
    UIView *view = nil;
    if ([_kbDelegate respondsToSelector:@selector(keyboardBecomeInvisible)]) {
        
        [_kbDelegate keyboardBecomeInvisible];
    }
    if ([_kbDelegate respondsToSelector:@selector(shouldAdjustViewOnKeyboardUpAndDown)]) {
        
        shouldChangeFrame = [_kbDelegate shouldAdjustViewOnKeyboardUpAndDown];
    }
    
    if (shouldChangeFrame) {
        
        if ([_kbDelegate respondsToSelector:@selector(viewToAdjustHeight)]) {
            
            view = [_kbDelegate viewToAdjustHeight];
        }
        
        if (view != nil) {
            
            view.frame = [self increasedFrameForView:view];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
