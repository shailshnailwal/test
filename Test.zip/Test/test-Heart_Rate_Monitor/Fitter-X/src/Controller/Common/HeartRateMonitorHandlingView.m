//
//  HeartRateMonitorHandlingView.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 29/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "HeartRateMonitorHandlingView.h"

@implementation HeartRateMonitorHandlingView

@synthesize delegate = _delegate;

-(IBAction) deviceDataFetched:(UIButton *)button{
    
    _START;
    if ([_delegate respondsToSelector:@selector(heartRateMonitorCurrentHeartRateFetch)]) {
        
        [_delegate heartRateMonitorCurrentHeartRateFetch];
    }
    _END;
    
}
-(IBAction) deviceConnected:(UIButton *)button{
    
    _START;
    if ([_delegate respondsToSelector:@selector(heartRateMonitorDeviceConnected)]) {
        
        [_delegate heartRateMonitorDeviceConnected];
    }
    _END;
    
}
-(IBAction) deviceConnectionFailed:(UIButton *)button{
    
    _START;
    if ([_delegate respondsToSelector:@selector(heartRateMonitorDeviceConnectionFailed)]) {
        
        [_delegate heartRateMonitorDeviceConnectionFailed];
    }
    _END;
}

@end
