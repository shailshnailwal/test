//
//  KeyboardHandlingVC.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 24/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "KeyboardHandlingVC.h"

@implementation KeyboardHandlingVC

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

-(void)viewDidLoad{
    
    //// set delegate for keyboard event ////
    ((AppNavigator *)self.navigationController).kbDelegate = self;
    _resizableView.contentSize = _resizableView.frame.size;
}

#pragma mark- Kayboard Methods
-(void)keyboardIsVisible{
    
    _START;
    _END;
}

-(void)keyboardBecomeInvisible{
    
    _START;
    _END;
}

-(BOOL) shouldAdjustViewOnKeyboardUpAndDown{
    
    _START;
    _END;
    return YES;
}

-(UIView *)viewToAdjustHeight{
    
    _START;
    _END;
    return _resizableView;
}
@end
