//
//  HeartRateMonitorHandlingView.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 29/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HeartRateMonitorDelegate <NSObject>
    @optional
        -(void) heartRateMonitorCurrentHeartRateFetch;
        -(void) heartRateMonitorDeviceConnected;
        -(void) heartRateMonitorDeviceConnectionFailed;
@end

@interface HeartRateMonitorHandlingView : UIView{
    
    @private
    CGFloat _heartRate;
    id<HeartRateMonitorDelegate> _delegate;
}

@property(nonatomic, strong) id<HeartRateMonitorDelegate> delegate;

-(IBAction) deviceDataFetched:(UIButton *)button;
-(IBAction) deviceConnected:(UIButton *)button;
-(IBAction) deviceConnectionFailed:(UIButton *)button;
@end
