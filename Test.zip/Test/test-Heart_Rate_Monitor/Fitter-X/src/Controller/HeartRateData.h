//
//  DeviceData.h
//  TestBlueHR
//
//  Created by Shailsh Naiwal on 11/03/14.
//
//

#import <Foundation/Foundation.h>
#import <WFConnector/WFConnector.h>

@protocol HeartRateDataProtocol <NSObject>

@optional
-(void) deviceDataStringFroHeartRate:(NSString *)hrString;

@end

@interface HeartRateData : NSObject<WFSensorConnectionDelegate>{
    
    WFHardwareConnector* hardwareConnector;
	WFSensorConnection* _sensorConnection;
	WFSensorType_t sensorType;
    USHORT applicableNetworks;
    
    NSString *_computedHR;
    NSString *_connectionState;
    
    id<HeartRateDataProtocol> _delegate;
}

@property (retain, nonatomic) WFSensorConnection* sensorConnection;
@property (readonly, nonatomic) WFHeartrateConnection* heartrateConnection;
@property (nonatomic, strong) NSString *computedHR;

@property (nonatomic, strong) id<HeartRateDataProtocol> delegate;

//******************************

- (void)setDefaults;
- (void)removeObservers;

- (void)startConnection;

+ (NSString*)formatUUIDString:(NSString*)uuid;
+ (NSString*)signalStrengthFromConnection:(WFSensorConnection*)conn;
+ (NSString*)stringFromSensorType:(WFSensorType_t)sensorType;
@end
