//
//  LoginVC.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 02/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserOperation.h"
#import "KeyboardHandlingVC.h"
#import "CustomCapitalButton.h"
//#import "CountDownView.h"
//#import "AlgorithmExecutor.h"

@interface LoginVC : KeyboardHandlingVC<UserOperationDelegate, UITextFieldDelegate, UIAlertViewDelegate>{
    
    __weak IBOutlet UITextField *_usernameTF;
    __weak IBOutlet UITextField *_passwordTF;
    IBOutlet UIView *_shadowView;
    IBOutlet UIToolbar *_accessoryToolbar;
    IBOutlet UIView *_recoveryView;
    __weak IBOutlet CustomBoldTextField *_recoveryEmailTF;
    __weak IBOutlet CustomCapitalButton *_sendPasswordBtn;
    __weak IBOutlet CustomCapitalButton *_cancelRecoveryBtn;
    UserOperation               *_userOperator;
    NSArray *_textFieldList;
    UITextField *_activeTF;
    
    //******* for checking *********//
    __weak IBOutlet UILabel *check;
//    AlgorithmExecutor *_executer;
//    CountDownView *_countDownView;
    
    BOOL _isDoubleClick;
    BOOL _isSingleClick;
    BOOL _clickResolved;
    NSDate *_firstClickTime;
    NSDate *_secondClickTime;
    
    UIAlertView *_recoveryAlert;
}

//// to initiate login request ////
- (IBAction)login:(id)sender;

//// to initiate registration process ////
- (IBAction)registerUser:(id)sender;

//// this function will help to recover user account ////
- (IBAction)recoverAccount:(id)sender;
- (IBAction)sendPassword:(id)sender;
- (IBAction)cancelRecovery:(id)sender;

//// this function will end editing on login form ////
- (IBAction)doneEditing:(id)sender;

//// this function will move the curser between username and password textfield ////
- (IBAction)moveToNext:(id)sender;
@end
