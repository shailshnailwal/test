//
//  CustomOtherLabel.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 22/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "CustomOtherLabel.h"

@implementation CustomOtherLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithCoder:(NSCoder *)aDecoder{
    
    _START;
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        self.font = APPLICATION_IMPACT_FONT(self);
        //if(LOGS_ON) NSLog(@"font given = %@", self.font);
    }
    _END;
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
