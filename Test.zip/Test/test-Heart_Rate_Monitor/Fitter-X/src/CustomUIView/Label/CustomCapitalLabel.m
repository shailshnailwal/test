//
//  CustomLabel.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 10/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "CustomCapitalLabel.h"

@implementation CustomCapitalLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        self.font = APPLICATION_ZIAN_FONT(self);
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
