//
//  CustomOtherButton.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 29/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "CustomOtherButton.h"

@implementation CustomOtherButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        self.titleLabel.font = APPLICATION_IMPACT_FONT(self.titleLabel);
    }
    return self;
}

@end
