//
//  CustomCapitalButton.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 29/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCapitalButton : UIButton

@end
