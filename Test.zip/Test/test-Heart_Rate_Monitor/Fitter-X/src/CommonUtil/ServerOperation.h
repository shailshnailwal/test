//
//  ServerOperation.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 13/02/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ServerOperationDelegate <NSObject>

-(void) serverOperationCompletedWithInfo:(NSDictionary *)info;
-(void) serverOperationFailed;
@end

@interface ServerOperation : NSObject{
    
    SEL _failSelector;
    SEL _successSelector;
    
    NSDictionary *_serverPerameters;
    NSString     *_serverLocation;
    NSString     *_serverIndexPage;
    
    AFHTTPRequestOperation *_operation;
    
    id<ServerOperationDelegate> _delegate;
}

@property(assign, nonatomic) SEL failSelector;
@property(assign, nonatomic) SEL successSelector;
@property(strong, nonatomic) id<ServerOperationDelegate> delegate;
@end
