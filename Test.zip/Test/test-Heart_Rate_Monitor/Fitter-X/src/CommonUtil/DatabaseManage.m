//
//  ManageDatabase.m
//  Shanghai WOW!
//
//  Created by Shailsh Naiwal on 22/03/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "DatabaseManage.h"

@implementation DatabaseManage

@synthesize databaseAvailability = _databaseAvailability;

-(id) init{
    
    _START;
    self = [super init];
    if (self) {
        _databaseAvailability   =   YES;
    }
    return self;
}

/**
 This function checks wether the application database is present or not.
 if not present, create it
 */
+(BOOL)createDatabaseIfNotExist{
    
    _START;
    BOOL databaseCreated = NO;
    NSFileManager   *fileManager            =   [NSFileManager defaultManager];
    //********* all directories in document directories ***********//
    NSArray         *allPaths               =   NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                                                    NSUserDomainMask, YES);
    NSString        *databaseDirectory      =   [allPaths objectAtIndex:0]; // main directory
    NSString        *databaseResounce       =   [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:
                                                                                                        DATABASE_NAME];
    //if(LOGS_ON) NSLog(@"database path = %@", [databaseDirectory stringByAppendingPathComponent:DATABASE_NAME]);
    
    if (![fileManager fileExistsAtPath:[databaseDirectory stringByAppendingPathComponent:DATABASE_NAME]]) {
        
        //if(LOGS_ON) NSLog(@"database not exist");
        // if database not exist, create database from bundel //
        databaseCreated = [fileManager copyItemAtPath:databaseResounce
                                               toPath:[databaseDirectory
                                                       stringByAppendingPathComponent:DATABASE_NAME]
                                                error:nil];
        
    }
    else{
        
        databaseCreated = YES;
    }
    //if(LOGS_ON) NSLog(@"database is created %d",databaseCreated);
    _END;
    return databaseCreated;
}

@end
