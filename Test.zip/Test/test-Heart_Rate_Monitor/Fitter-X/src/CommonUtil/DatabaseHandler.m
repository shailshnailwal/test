//
//  DatabaseClass.m
//  Shanghai WOW!
//
//  Created by Shailsh Naiwal on 22/03/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "DatabaseHandler.h"

@interface NSObject()

- (id) init;

@end

@implementation DatabaseHandler

@synthesize isConnected = _isConnected;

static DatabaseHandler *sharedObject = nil;

/**
 initialize database path
 */
-(id) init{
    
    _START;
    self    =   [super init];
    if (self) {
        // find database path //
        NSString    *documentDirectoryPath  = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                                                   NSUserDomainMask,
                                                                                   YES)
                                               objectAtIndex:0];
        _databasePath   =   [[NSString alloc] initWithString:[documentDirectoryPath stringByAppendingPathComponent:
                                                                                                    DATABASE_NAME]];
    }
    _END;
    return self;
}

/**
 create a shared object if shared object is nil
 if object is already present in application, return the same object
 */
+(DatabaseHandler *)getDatabaseSharedObject{
    
    _START;
    @synchronized(self){
        
        if(sharedObject == nil){
            
            sharedObject = [[DatabaseHandler alloc] init];
        }
    }
    _END;
    return sharedObject;
}

/**
 * this funciton will on foreign key constraints
 */
-(BOOL)onForeignKey{
    
    _START;
    BOOL foreignKeyOn = NO;
    if ([self startConnection]) {
        
        NSString *foreignKeyOnQuery = @"PRAGMA foreign_keys = on";
        const char *executableQuery = [foreignKeyOnQuery UTF8String];
        sqlite3_stmt    *statement;
        if ([self startConnection]) {
            
            sqlite3_prepare_v2(_dataBaseOperator, executableQuery, -1, &statement, NULL);
            foreignKeyOn    =   (sqlite3_step(statement) == SQLITE_DONE);
            sqlite3_finalize(statement);
        }
        [self closeConnection];
    }
    _END;
    return foreignKeyOn;
}

/**
 * this function will start the database connection
 */
-(BOOL) startConnection{
    
    _START;
    
    if (!_isConnected) {
        
        const char *databbasePath   = [_databasePath UTF8String];
        _isConnected                = (sqlite3_open(databbasePath, &_dataBaseOperator) == SQLITE_OK);
        //if(LOGS_ON) NSLog(@"is connected = %d",_isConnected);
    }
    _END;
    return _isConnected;
}


//// end connection ///////
-(void) closeConnection{
    
    _START;
    if (_isConnected) {
        sqlite3_close(_dataBaseOperator);
        _isConnected = NO;
    }
    _END;
}

////////////// creat table //////////////////////
-(BOOL) createTableWithQuery: (NSString *)createTableQuery{
    
    _START;
    BOOL isTableCreated  =   NO;
    if (_isConnected) {
        
        //if(LOGS_ON) NSLog(@"Connection started");
        const char      *query      =   [createTableQuery UTF8String];
        ////// creating table in database /////////////
        isTableCreated              =   (sqlite3_exec(_dataBaseOperator, query, nil, nil, nil) == SQLITE_OK);
        //if(LOGS_ON) NSLog(@"Table is created = %d",isTableCreated);
    }
//    [self closeConnection];
    _END;
    return isTableCreated;
}

/**
 * count totla record in table
 */
-(NSInteger) totalRecordsInTable:(NSString *)tableName{
    
    NSInteger totalRecords = 0;
    NSString *rowCountQuery = [NSString stringWithFormat:@"SELECT COUNT(*) FROM %@",tableName];
    NSString *result = [self getDataForAggrigateFunctionQuery:rowCountQuery];
    if (result && ![result isEqualToString:@""]) {
        
        totalRecords = result.integerValue;
    }
    return totalRecords;
}

///////////// insert query ///////////////////////////////////
-(BOOL) insertWithQuery: (NSString *)insertIntoTableQuery{
    
    _START;
    BOOL   dataInserted = NO;
    if (_isConnected) {
    
        //if(LOGS_ON) NSLog(@"INSERT =%@",insertIntoTableQuery);
        sqlite3_stmt    *statement = nil;
        const char      *insertQuery    =   [insertIntoTableQuery UTF8String];
        //if(LOGS_ON) NSLog(@"insert query is :%s",insertQuery);
        int result1 = sqlite3_prepare_v2(_dataBaseOperator, insertQuery, -1, &statement, NULL);
        
        //if(LOGS_ON) NSLog(@"start insertion1=%d",result1);
        int result;
        if ((result = sqlite3_step(statement)) == SQLITE_DONE) {
            
            dataInserted    =   YES;
        }
        else{
            
            //if(LOGS_ON) NSLog(@"not inserted");
        }
        //if(LOGS_ON) NSLog(@"start insertion=%d",result);
        //if(LOGS_ON) NSLog(@"query = %@",statement);
        sqlite3_finalize(statement);
        //if(LOGS_ON) NSLog(@"Connectin is closing");
//        [self closeConnection];
    }
    else{

        //if(LOGS_ON) NSLog(@"no connection available");
    }
    _END;
    return dataInserted;
}

//// get collumn list ////
-(NSArray *)getTableColumnListForTable: (NSString *)table{
    
    _START;
    NSMutableArray *columnList = nil;
    if (_isConnected) {
        
        sqlite3_stmt *sqlStatement;
        columnList = [[NSMutableArray alloc] init];
        const char *sql = [[NSString stringWithFormat:@"pragma table_info('%s')",[table UTF8String]] UTF8String];
        if(sqlite3_prepare(_dataBaseOperator, sql, -1, &sqlStatement, NULL) != SQLITE_OK)
        {
            //if(LOGS_ON) NSLog(@"Problem with prepare statement tableInfo %@",[NSString stringWithUTF8String:(const char *)sqlite3_errmsg(_dataBaseOperator)]);
            
        }
        while (sqlite3_step(sqlStatement)==SQLITE_ROW){
            
            [columnList addObject:[NSString stringWithUTF8String:(char*)sqlite3_column_text(sqlStatement, 1)]];
            
        }
    }
    return columnList;
}

/**
 This function gets select query and table
 and returns array of dictionary
 keys of dictionary will be column names
 */
-(NSArray *)getDataWithQuery: (NSString *)selectQuery withTableName: (NSString *)tableName{
    
    _START;
    //if(LOGS_ON) NSLog(@"hello shailsh -%@-", selectQuery);
    NSMutableArray *tableData = [[NSMutableArray alloc] init]; //// array for table rows
    NSArray *columnNames = [self getTableColumnListForTable:tableName];
    
    if (!_isConnected) {
        // if connection can not be established return function
        //if(LOGS_ON) NSLog(@"bad connection");
        return nil;
    }
    
    sqlite3_stmt *statement = NULL;
    const char   *selectStatement = [selectQuery UTF8String];
    BOOL validQuery = (sqlite3_prepare_v2(_dataBaseOperator, selectStatement, -1, &statement, NULL) == SQLITE_OK);
    //if(LOGS_ON) NSLog(@"statement = %s",selectStatement);
    if(!validQuery){
       //  if statement is not valid, return function
        //if(LOGS_ON) NSLog(@"invalid statement");
        return nil;
    }
    
    int colNumber = sqlite3_column_count(statement);
    //if(LOGS_ON) NSLog(@"total record found %d", colNumber);
    while (sqlite3_step(statement) == SQLITE_ROW) {
        
        @autoreleasepool {
            
            //// dictionary for one row ////
            NSMutableDictionary *row = [[NSMutableDictionary alloc] init];
            for (int i = 0; i < colNumber; i++) {
                
                const char * temp = (const char *)sqlite3_column_text(statement, i);
                
                if (temp == NULL) {
                    
                    continue;
                }
                
                NSString *cellValue = [NSString stringWithUTF8String: temp];
                
                //// creating row with dictionary ////
                if (cellValue) {
                    
                    [row setObject:cellValue forKey:[columnNames objectAtIndex:i]];
                }
                else{
                    
                    [row setObject:nil forKey:[columnNames objectAtIndex:i]];
                }
            }
            
            [tableData addObject:row];
        }
    }
    //if(LOGS_ON) NSLog(@"table data 1 %@ %d",tableData,[tableData count]);
    
    sqlite3_finalize(statement);
//    [self closeConnection];
    _END;
    return tableData;
}

/**
 This function gets select query and return array of array
 inner array will contains all columns of one row
 */
-(NSArray *)getDataWithQuery: (NSString *)selectQuery{
    
    _START;
    //if(LOGS_ON) NSLog(@"hello shailsh -%@-", selectQuery);
    NSMutableArray *tableData = [[NSMutableArray alloc] init]; //// array for table rows
    
    if (!_isConnected) {
        // if connection can not be established return function
        //if(LOGS_ON) NSLog(@"bad connection");
        return nil;
    }
    
    sqlite3_stmt *statement = NULL;
    const char   *selectStatement = [selectQuery UTF8String];
    BOOL validQuery = (sqlite3_prepare_v2(_dataBaseOperator, selectStatement, -1, &statement, NULL) == SQLITE_OK);
    //if(LOGS_ON) NSLog(@"statement = %s",selectStatement);
    if(!validQuery){
        //  if statement is not valid, return function
        //if(LOGS_ON) NSLog(@"invalid statement");
        return nil;
    }
    
    int colNumber = sqlite3_column_count(statement);
    //if(LOGS_ON) NSLog(@"total record found %d", colNumber);
    while (sqlite3_step(statement) == SQLITE_ROW) {
        
        @autoreleasepool {
            
            //// dictionary for one row ////
            NSMutableDictionary *row = [[NSMutableDictionary alloc] init];
            for (int i = 0; i < colNumber; i++) {
                
                const char * temp = (const char *)sqlite3_column_text(statement, i);
                //if(LOGS_ON) NSLog(@"read table coloum value = %s",temp);
                NSString *cellValue = nil;
                if (temp != NULL) { //// when NULL value found in a collom
                    
                    cellValue = [NSString stringWithUTF8String: temp];
                }
                temp = (const char *)sqlite3_column_name(statement, i);
                //if(LOGS_ON) NSLog(@"temprory string = %s",temp);
                NSString *cellName = [NSString stringWithUTF8String:temp];
                //if(LOGS_ON) NSLog(@"col name = %@", cellName);
                
                //// creating row with dictionary ////
                if (cellValue) {
                    
                    [row setObject:cellValue forKey:cellName];
                    //if(LOGS_ON) NSLog(@"cell name set for value found");
                }
                else{
                    //if(LOGS_ON) NSLog(@"cell name set for value not found");
                    [row setObject:DATA_UNAVAILABLE forKey:cellName];
                }
            }
            
            [tableData addObject:row];
        }
    }
    //if(LOGS_ON) NSLog(@"table data 1 %@ %d",tableData,[tableData count]);
    sqlite3_finalize(statement);
//    [self closeConnection];
    _END;
    return tableData;
}

/**
 This function take a query having aggrigate function and return single result in single string
 */
-(NSString *)getDataForAggrigateFunctionQuery:(NSString *)query{
    
    _START;
    //if(LOGS_ON) NSLog(@"aggrigate query -%@-", query);
    NSMutableString *result = [[NSMutableString alloc] init];
    
    if (!_isConnected) {
        // if connection can not be established return function
        //if(LOGS_ON) NSLog(@"bad connection");
        return nil;
    }
    
    sqlite3_stmt *statement = NULL;
    const char   *selectStatement = [query UTF8String];
    BOOL validQuery = (sqlite3_prepare_v2(_dataBaseOperator, selectStatement, -1, &statement, NULL) == SQLITE_OK);
    //if(LOGS_ON) NSLog(@"statement = %s",selectStatement);
    if(!validQuery){
        //  if statement is not valid, return function
        //if(LOGS_ON) NSLog(@"invalid statement");
        [result release];
        result = nil;
    }
    
    int colNumber = sqlite3_column_count(statement);
    //if(LOGS_ON) NSLog(@"total record found %d", colNumber);
    while (sqlite3_step(statement) == SQLITE_ROW) {
        
        @autoreleasepool {
            
            for (int i = 0; i < colNumber; i++) {
                
                const char * temp = (const char *)sqlite3_column_text(statement, i);
                
                if (temp == NULL) {
                    
                    continue;
                }
                
                NSString *cellValue = [NSString stringWithUTF8String: temp];
                [result setString:cellValue];
            }
        }
    }
    
    sqlite3_finalize(statement);
//    [self closeConnection];
    _END;
    return result;
}

//// delete data form database table //////////
-(BOOL)deleteDataForQuery:(NSString *)deleteQueryString{
    
    _START;
    BOOL   dataDeleted = NO;
    
    //if(LOGS_ON) NSLog(@"delete query is : %@",deleteQueryString);
    
    if (_isConnected) {
    
        sqlite3_stmt    *statement;
        const char      *deleteQuery    =   [deleteQueryString UTF8String];
        sqlite3_prepare_v2(_dataBaseOperator, deleteQuery, -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE) {
            
            dataDeleted    =   YES;
        }
        sqlite3_finalize(statement);
//        [self closeConnection];
    }
    _END;
    return dataDeleted;
}


///////// Update table data //////////////////
-(BOOL)updateTableWithQuery: (NSString *)updateQueryString{
    
    BOOL   databaseUpdated = NO;
    if (_isConnected) {
        
        sqlite3_stmt    *statement;
        const char      *updateQuery    =   [updateQueryString UTF8String];
        sqlite3_prepare_v2(_dataBaseOperator, updateQuery, -1, &statement, NULL);
        databaseUpdated    =   (sqlite3_step(statement) == SQLITE_DONE);
        sqlite3_finalize(statement);
    }
    
    //if(LOGS_ON) NSLog(@"Datbase updated %d",databaseUpdated);
//    [self closeConnection];
    _END;
    return databaseUpdated;
}
@end
