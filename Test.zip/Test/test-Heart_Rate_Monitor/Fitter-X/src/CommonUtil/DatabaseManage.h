//
//  ManageDatabase.h
//  Shanghai WOW!
//
//  Created by Shailsh Naiwal on 22/03/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface DatabaseManage : NSObject{
    
    sqlite3     *_dataBase;
    NSArray     *_parsedDataList;
    BOOL        _databaseAvailability;
}

@property(readwrite,assign) BOOL databaseAvailability;

/////////// create database if not exist //////////////
+(BOOL)createDatabaseIfNotExist;

@end
