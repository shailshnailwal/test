//
//  UniversalTaskExecuter.m
//  GetFriends
//
//  Created by Shailsh Naiwal on 23/05/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "UniversalTaskExecuter.h"
#import "Base64.h"

@implementation UniversalTaskExecuter

/**
 this function will get json string and return a dictionary after decoding json string,
 if json string is invalid, it will return nil
 */
+(NSDictionary *)jsonDictionaryFromString: (NSString *)jsonString{
    
    _START;
    NSData *jsonData               = [jsonString dataUsingEncoding:NSASCIIStringEncoding];
    NSDictionary *imageInformation = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                     options:NSJSONReadingMutableContainers
                                                                       error:nil];
    _END;
    return imageInformation;
}

/**
 * this function will create image from string.
 * string should be decoaded with Base64 decoading.
 * if string is found to be in valid for any reason, function will reutnr nil
 */
+(UIImage *)imageFromString: (NSString *)imageString{
    
    _START;
    NSData  *imageData  = [Base64  decode:imageString];
    UIImage *image      = [UIImage imageWithData:imageData];
    _END;
    return image;
}

/**
 * this function takes string one dimentional array and return a sorted array of two dimention arrar.
 * every row of this 2D array will contain names start from same alphabet
 */
+(NSArray *)twoDimentionalSortedArrayWithStringArray : (NSArray *)stringArray{
    
    int i = 0;
    
    //// sort the received array ////
    NSArray *sortedArray = [stringArray sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    
    //// getting first character to compare ////
    NSString *firstChar = [[sortedArray objectAtIndex:0] substringToIndex:1];
    NSMutableArray *towDimentionArray = [[NSMutableArray alloc] init];
    NSMutableArray *row = [[NSMutableArray alloc] init];
    
    //// creating Two Dimentional Array ////
    do {
        
        if (![firstChar caseInsensitiveCompare:[[sortedArray objectAtIndex:i] substringToIndex:1]] == 0){
            
            firstChar = [[sortedArray objectAtIndex:i] substringToIndex:1];
            [towDimentionArray addObject:row];
            if(row){ // create new row for new first character
                
                row = [[NSMutableArray alloc] init];
            }
        }
        
        [row addObject:[sortedArray objectAtIndex:i]];
        i ++;
    } while (i < [sortedArray count]);
    
    if([row count] > 0) // add last row if it is not added to two dimentional array
        [towDimentionArray addObject:row];
    
    return towDimentionArray;
}

/**
 this function takes string one dimentional array and return a sorted array of two dimention arrar.
 every row of this 2D array will contain names start from same alphabet
 */
+(NSArray *)twoDimentionalSortedArrayWithObjectArray : (NSArray *)objectArray withComparingObjectIndex: (NSInteger) index{
    
    int i = 0;
    
    //// getting first character to compare ////
    NSString *firstChar = [[[objectArray objectAtIndex:0] objectAtIndex:index] substringToIndex:1];
    NSMutableArray *towDimentionArray = [[NSMutableArray alloc] init];
    NSMutableArray *row = [[NSMutableArray alloc] init];
    
    //// creating Two Dimentional Array ////
    do {
        
        if (![firstChar caseInsensitiveCompare:[[[objectArray objectAtIndex:i] objectAtIndex:index] substringToIndex:1]] == 0){
            
            firstChar = [[[objectArray objectAtIndex:i] objectAtIndex:index] substringToIndex:1];
            [towDimentionArray addObject:row];
            if(row){ // create new row for new first character
                
                row = [[NSMutableArray alloc] init];
            }
        }
        
        [row addObject:[objectArray objectAtIndex:i]];
        i ++;
    } while (i < [objectArray count]);
    
    if([row count] > 0) // add last row if it is not added to two dimentional array
        [towDimentionArray addObject:row];
    
    return towDimentionArray;
}

/**
 this function all take a string array, add return all different first characters in strings of array
 */
+(NSArray *)arrayOfAllDiffernetFirstCharacterInStringArray: (NSArray *)stringArray{
    
    NSMutableArray *allDifferentFirstChar = [[NSMutableArray alloc] init];
    NSArray *sortedArray = [stringArray sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    if ([stringArray count] > 0) {
        
        NSString *firstChar = [[[sortedArray objectAtIndex:0] substringToIndex:1] uppercaseString];
        [allDifferentFirstChar addObject:firstChar];
        for (int i = 0; i < [sortedArray count]; i ++) {
            
            if ([firstChar caseInsensitiveCompare:[[sortedArray objectAtIndex:i] substringToIndex:1]] == 0) {
                
                continue;
            }
            
            firstChar = [[[sortedArray objectAtIndex:i] substringToIndex:1] uppercaseString];
            [allDifferentFirstChar addObject:firstChar];
        }
    }
    
    return allDifferentFirstChar;
}

/**
 this function all take a object array, add return all different first characters in strings of array
 */
+(NSArray *)arrayOfAllDiffernetFirstCharacterInObjectArray: (NSArray *)objectArray withComparingObjectIndex: (NSInteger) index{
    
    NSMutableArray *allDifferentFirstChar = [[NSMutableArray alloc] init];
    if ([objectArray count] > 0) {
        
        NSString *firstChar = [[[[objectArray objectAtIndex:0] objectAtIndex:index] substringToIndex:1] uppercaseString];
        [allDifferentFirstChar addObject:firstChar];
        for (int i = 0; i < [objectArray count]; i ++) {
            
            if ([firstChar caseInsensitiveCompare:[[[objectArray objectAtIndex:i] objectAtIndex:index] substringToIndex:1]] == 0) {
                
                continue;
            }
            
            firstChar = [[[[objectArray objectAtIndex:i] objectAtIndex:index] substringToIndex:1] uppercaseString];
            [allDifferentFirstChar addObject:firstChar];
        }
    }
    
    return allDifferentFirstChar;
}

/**
 object at index in inner must be string
 */
+(NSArray *)sortTwoDArray: (NSArray *)twoDArray withSortOrderIndex:(NSInteger)index{
    
    _START;
    NSMutableArray *sortedArray = [[NSMutableArray alloc] init];
    if (twoDArray && [twoDArray count] > 0) {
        
        [sortedArray addObject:[twoDArray objectAtIndex:0]];
        int i = 1;
        do{
            
            NSString *compareString = [[twoDArray objectAtIndex:i] objectAtIndex:index];
            int j;
            for (j = 0; j < [sortedArray count]; j ++) {
                
                NSString *compareWith = [[sortedArray objectAtIndex:j] objectAtIndex:index];
                if (!([compareString caseInsensitiveCompare:compareWith] == NSOrderedDescending)) {
                    
                    break;
                }
            }
            [sortedArray insertObject:[twoDArray objectAtIndex:i] atIndex:j];
            i ++;
        }while (i < [twoDArray count]);
    }
    _END;
    return sortedArray;
}

+(void)setBorderForView:(UIView *)view{
    
    _START;
    view.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    view.layer.borderWidth = 1.0f;
    _END;
}

+(void)applicationTextFieldNormalFont : (UITextField *) textField{
    
    _START;
    [textField setFont:[UIFont fontWithName:@"swis721 cn bt" size:textField.font.pointSize]];
    _END;
}

+(void)applicationTextFieldBoldFont : (UITextField *) textField{
    
    _START;
    [textField setFont:[UIFont fontWithName:@"Swiss721BT-BoldCondensed" size:textField.font.pointSize]];
    _END;
}

+(void)applicationTextViewNormalFont : (UITextView *) textView{
    
    _START;
    [textView setFont:[UIFont fontWithName:@"Swiss721BT-RomanCondensed" size:textView.font.pointSize]];
    _END;
}

+(void)applicationTextViewBoldFont : (UITextView *) textView{
    
    _START;
    [textView setFont:[UIFont fontWithName:@"Swiss721BT-BoldCondensed" size:textView.font.pointSize]];
    _END;
}

+(void)applicationLabelNormalFont : (UILabel *) label{
    
    _START;
    [label setFont:[UIFont fontWithName:@"Swiss721BT-RomanCondensed" size:label.font.pointSize]];
    _END;
}

+(void)applicationLabelBoldFont : (UILabel *) label{
    
    _START;
    [label setFont:[UIFont fontWithName:@"Swiss721BT-BoldCondensed" size:label.font.pointSize]];
    _END;
}

+(NSString *)stringFromFileAtURL:(NSURL *)url{
    
    NSMutableString *fileString = [[NSMutableString alloc] init];
    return fileString;
}

+(NSString *)stringFromFileAtPath: (NSString *)path{
    
    NSMutableString *fileString = [[NSMutableString alloc] init];
    return fileString;
}

/**
 * this function will return the date component object
 */
+(NSDateComponents *) dateComponentsWithDate : (NSDate *)date{
    
    _START;
    NSCalendar *gregorianCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *dateComponent = [gregorianCalendar components:NSYearCalendarUnit  |
                                                                    NSMonthCalendarUnit |
                                                                    NSDayCalendarUnit   |
                                                                    NSHourCalendarUnit  |
                                                                    NSMinuteCalendarUnit|
                                                                    NSSecondCalendarUnit|
                                                                    NSTimeZoneCalendarUnit
                                                           fromDate:date];
    _END;
    return dateComponent;
}

/**
 this funciton will create a directory with a specific name in application document directory
 */
+(BOOL) createDirectoryInApplicationDocumentsWithName:(NSString *)directoryName{
    
    _START;
    //// array of all application document directories ////
    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    //// getteing the desired directory path which is about to be created ////
    NSString *directoryPath = [[documentPaths objectAtIndex:0] stringByAppendingPathComponent:directoryName];
    //if(LOGS_ON) NSLog(@"folder path is : %@",directoryPath);
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *directoryCreationError;
    
    //// creating directory for desired path ////
    BOOL directoryCreated = [fileManager createDirectoryAtPath:directoryPath
                                   withIntermediateDirectories:NO
                                                    attributes:nil
                                                         error:&directoryCreationError];
    if (directoryCreationError) {
        
        //if(LOGS_ON) NSLog(@"directory creation error is : %@",directoryCreationError);
    }
    else{
        
        //if(LOGS_ON) NSLog(@"directory is created");
    }
    _END;
    return directoryCreated;
}

/**
 this function downloads the file from url and return the downloaded file url string
 */
+(NSString *)downloadFileFromURL: (NSURL *)url asFileName:(NSString *)fileName{
    
    _START;
    NSMutableString *fileURL        = nil;// = [[NSMutableString alloc] init];
    NSArray         *filePathList   = nil;
    NSString        *filePath       = nil;
    NSData          *fileData       = [NSData dataWithContentsOfURL:url];
    
    //// getting documant directory ////
    if (fileData) {
        
        filePathList = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    }
    
    if(filePathList && [filePathList count] > 0){
        
        NSString *path = [[filePathList objectAtIndex:0] stringByAppendingPathComponent:@"Directory Name"];
        filePath       = [path stringByAppendingPathComponent:fileName];
    }
    
    if (filePath) {
    
        //// downloading file ////
        if ([fileData writeToFile:filePath atomically:YES]) {
            
            fileURL = [[NSMutableString alloc] init];
            [fileURL setString:filePath];
        }
    }
    _END;
    return fileURL;
}

/**
 this function return the needed size for label for string
 */
+(CGSize) sizeOfLabel: (UILabel *)label forString: (NSString *)string{
    
    _START;
    //Calculate the expected size based on the font and linebreak mode of your label
    CGSize expectedLabelSize = [string sizeWithFont:label.font
                                  constrainedToSize:CGSizeMake(320, 300)
                                      lineBreakMode:label.lineBreakMode];
    _END;
    return expectedLabelSize;
}

#pragma mark- Frame Operation
+(CGRect) addHight:(CGFloat)height toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       frame.origin.y,
                       frame.size.width,
                       frame.size.height + height);
    _END;
    return frame;
}

+(CGRect) changeHightTo:(CGFloat)height toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       frame.origin.y,
                       frame.size.width,
                       height);
    _END;
    return frame;
}

+(CGRect) addWidth:(CGFloat)width toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       frame.origin.y,
                       frame.size.width + width,
                       frame.size.height);
    _END;
    return frame;
}

+(CGRect) changeWidthTo:(CGFloat)width toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       frame.origin.y,
                       width,
                       frame.size.height);
    _END;
    return frame;
}

+(CGRect) addHight:(CGFloat)height width:(CGFloat)width toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       frame.origin.y,
                       frame.size.width + width,
                       frame.size.height + height);
    _END;
    return frame;
}

+(CGRect) changeHight:(CGFloat)height width:(CGFloat)width toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       frame.origin.y,
                       width,
                       height);
    _END;
    return frame;
}

+(CGRect) moveXOrigenBy:(NSInteger)distance toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x + distance,
                       frame.origin.y,
                       frame.size.width,
                       frame.size.height);
    _END;
    return frame;
}

+(CGRect) changeXOrigenTo:(NSInteger)x toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(x,
                       frame.origin.y,
                       frame.size.width,
                       frame.size.height);
    _END;
    return frame;
}

+(CGRect) moveYOrigenBy:(NSInteger)distance toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       frame.origin.y + distance,
                       frame.size.width,
                       frame.size.height);
    _END;
    return frame;
}

+(CGRect) changeYOrigenTo:(NSInteger)y toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(frame.origin.x,
                       y,
                       frame.size.width,
                       frame.size.height);
    _END;
    return frame;
}

+(CGRect) changeXOrigenTo:(NSInteger)x yOrigenTo:(NSInteger)y toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(x,
                       y,
                       frame.size.width,
                       frame.size.height);
    _END;
    return frame;
}

+(CGRect) changeOrigenToPoint:(CGPoint)point toFrame:(CGRect)frame{
    
    _START;
    frame = CGRectMake(point.x,
                       point.y,
                       frame.size.width,
                       frame.size.height);
    _END;
    return frame;
}

+(NSDate *) dateForComingDay:(DayNumber) daynum fromDate:(NSDate *) date{
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSYearCalendarUnit | NSMonthCalendarUnit | NSWeekCalendarUnit | NSWeekdayCalendarUnit fromDate:date];
    
    NSUInteger weekdayToday = [components weekday];
    NSInteger daysToDay = (7 + daynum - weekdayToday) % 7;
    
    NSDate *nextDay = [date dateByAddingTimeInterval:60*60*24*daysToDay];
    return nextDay;
}

#pragma mark- SearchBar methods
+(void)rectangularSearchBar: (UISearchBar *)searchBar{
    
    _START;
    [[UISearchBar appearance] setSearchFieldBackgroundImage:nil
                                                   forState:UIControlStateNormal];
    UITextField *txfSearchField = [searchBar valueForKey:@"_searchField"];
    
    searchBar.tintColor = [UIColor whiteColor];
    [txfSearchField setBackgroundColor:[UIColor whiteColor]];
    [txfSearchField setBorderStyle:UITextBorderStyleRoundedRect];
    txfSearchField.layer.borderWidth    = 8.0f;
    txfSearchField.layer.cornerRadius   = 0.0f;
    txfSearchField.layer.borderColor    = [UIColor clearColor].CGColor;
    for (UIView *searchBarSubview in [searchBar subviews]) {
        
        if ([searchBarSubview conformsToProtocol:@protocol(UITextInputTraits)]) {
            
            @try {
                
                [(UITextField *)searchBarSubview setReturnKeyType:UIReturnKeyDefault];
            }
            @catch (NSException * e) {
                
                //if(LOGS_ON) NSLog(@"Excpetion is : %@\nwith exception information : %@", e.name, e.userInfo);
            }
        }
    }
    _END;
}

#pragma mark- AlertView method
+(void) showAlertWithTitle:(NSString *) title andMessage:(NSString *)message withButtonTitle:(NSString *)buttonTitle{
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:message
                                                   delegate:nil
                                          cancelButtonTitle:buttonTitle
                                          otherButtonTitles:nil];
    [alert show];
}

#pragma mark- aspect ration methods
+(CGRect)frameForImageView:(UIImageView *)imageView forImage:(UIImage *)image{
    
    CGRect frame;
    CGFloat width;
    CGFloat height;
    if (image ) {
        
        if (image.size.height > image.size.width) {
            
            width  = imageView.frame.size.height * image.size.width / image.size.height;
            height = imageView.frame.size.height;
        }
        else{
            
            width  = imageView.frame.size.width;
            height = imageView.frame.size.width * image.size.height / image.size.width;
        }
        
        frame  =   CGRectMake(imageView.frame.origin.x, imageView.frame.origin.y, width, height);
    }
    return frame;
}

#pragma mark- PDF function
/**
 * get PDF from table view
 */
+(NSData *) pdfDataFromTableView:(UITableView *)tableView {
    
    CGRect priorBounds = tableView.bounds;
    CGSize fittedSize = [tableView sizeThatFits:CGSizeMake(priorBounds.size.width, HUGE_VALF)];
    tableView.bounds = CGRectMake(0, 0, fittedSize.width, fittedSize.height);
    
    // Standard US Letter dimensions 8.5" x 11"
    CGRect pdfPageBounds = CGRectMake(0, 0, 612, 792);
    
    NSMutableData *pdfData = [[NSMutableData alloc] init];
    UIGraphicsBeginPDFContextToData(pdfData, pdfPageBounds, nil); {
        for (CGFloat pageOriginY = 0; pageOriginY < fittedSize.height; pageOriginY += pdfPageBounds.size.height) {
            
            UIGraphicsBeginPDFPageWithInfo(pdfPageBounds, nil);
            CGContextSaveGState(UIGraphicsGetCurrentContext());
            {
                
                CGContextTranslateCTM(UIGraphicsGetCurrentContext(), 0, -pageOriginY);
                [tableView.layer renderInContext:UIGraphicsGetCurrentContext()];
                
            }
            CGContextRestoreGState(UIGraphicsGetCurrentContext());
        }
    } UIGraphicsEndPDFContext();
    tableView.bounds = priorBounds;
    return pdfData;
}

/**
 * this function will join all pdf fils in a single file
 * it takes list of pdf in an array
 */
+ (BOOL)joinPDFList:(NSArray *)listOfPaths inFilePath:(NSString *)fileName{
    // File paths
    
    if (!fileName) {
        
        return false;
    }
    else if(![fileName hasSuffix:@".pdf"]){
        
        fileName = [fileName stringByAppendingString:@".pdf"];
    }
    
    //    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //    NSString *documentsDirectory = [paths objectAtIndex:0];
    //    NSString *pdfPath1 = [documentsDirectory stringByAppendingPathComponent:@"NewPDF.pdf"];
    //    NSString *pdfPath2 = [documentsDirectory stringByAppendingPathComponent:@"NewPDF1.pdf"];
    //    listOfPaths = @[pdfPath1, pdfPath2];
    
    //    //if(LOGS_ON) NSLog(@"pdf list = %@", listOfPaths);
    
    NSString *pdfPathOutput = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:fileName];
    
    CFURLRef pdfURLOutput = (  CFURLRef)CFBridgingRetain([NSURL fileURLWithPath:pdfPathOutput]);
    
    NSInteger numberOfPages = 0;
    // Create the output context
    CGContextRef writeContext = CGPDFContextCreateWithURL(pdfURLOutput, NULL, NULL);
    
    for (NSString *source in listOfPaths) {
        CFURLRef pdfURL = (  CFURLRef)CFBridgingRetain([[NSURL alloc] initFileURLWithPath:source]);
        
        //file ref
        CGPDFDocumentRef pdfRef = CGPDFDocumentCreateWithURL((CFURLRef) pdfURL);
        numberOfPages = CGPDFDocumentGetNumberOfPages(pdfRef);
        
        // Loop variables
        CGPDFPageRef page;
        CGRect mediaBox;
        
        // Read the first PDF and generate the output pages
        for (int i=1; i<=numberOfPages; i++) {
            
            page = CGPDFDocumentGetPage(pdfRef, i);
            mediaBox = CGPDFPageGetBoxRect(page, kCGPDFMediaBox);
            CGContextBeginPage(writeContext, &mediaBox);
            CGContextDrawPDFPage(writeContext, page);
            CGContextEndPage(writeContext);
        }
        
        CGPDFDocumentRelease(pdfRef);
        CFRelease(pdfURL);
    }
    CFRelease(pdfURLOutput);
    
    // Finalize the output file
    CGPDFContextClose(writeContext);
    CGContextRelease(writeContext);
    
    return (pdfPathOutput !=nil && ![pdfPathOutput isEqualToString:@""]);
}


- (void)generateCsvFile:(NSArray *)rowList {
    
    NSArray *paths      = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *directory = [paths objectAtIndex:0];
    //    NSString *directory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    NSString *path = [directory stringByAppendingPathComponent:@"CSVFile.csv"];
    
    if (![[NSFileManager defaultManager]fileExistsAtPath:path])
    {
        [[NSFileManager defaultManager]createFileAtPath:path contents:nil attributes:nil];
    }
    NSMutableString *writeString = [[NSMutableString alloc]init];
    
    for (NSDictionary *dic in rowList) {
        NSString * string = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@",[dic objectForKey:@"S_No"],[dic objectForKey:@"Date"],[dic objectForKey:@"task"],[dic objectForKey:@"discussion_hour"],[dic objectForKey:@"Learning_hour"],[dic objectForKey:@"Working_hour"],[dic objectForKey:@"Status"]];
        [writeString appendFormat:@"%@",string ];
        [writeString appendString:@"\n"];
        
        NSLog(@"wrie string is %@",writeString);
        
    }
    
    NSFileHandle *handle;
    handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle writeData:[writeString dataUsingEncoding:NSUTF8StringEncoding]];
    
}

#pragma mark- Unchecked section
//// unchecked for changing textview height with fixed width ////
+ (CGFloat)textViewHeightForAttributedText:(NSAttributedString *)text andWidth:(CGFloat)width
{
    UITextView *textView = [[UITextView alloc] init];
    [textView setAttributedText:text];
    CGSize size = [textView sizeThatFits:CGSizeMake(width, FLT_MAX)];
    return size.height;
}

//// unchecked for getting frame for text for particulat font ////
- (CGSize)text:(NSString *)text sizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size
{
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        CGRect frame = [text boundingRectWithSize:size
                                          options:(NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading)
                                       attributes:@{NSFontAttributeName:font}
                                          context:nil];
        return frame.size;
    }
    else
    {
        return [text sizeWithFont:font constrainedToSize:size];
    }
}

#pragma mark- Validation
/**
 * Email Validation
 */
+(BOOL) isValidEmail:(NSString *)emailString Strict:(BOOL)strictFilter{
    
    NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
    
    NSString *emailRegex = strictFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:emailString];
}
@end
