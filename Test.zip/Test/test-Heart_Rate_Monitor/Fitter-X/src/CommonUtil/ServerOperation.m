//
//  ServerOperation.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 13/02/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "ServerOperation.h"
#import "AFNetworking.h"

@implementation ServerOperation

@synthesize failSelector    = _failSelector;
@synthesize successSelector = _successSelector;
@synthesize delegate        = _delegate;

-(void) fun{
    
    NSMutableDictionary *param;
        
    AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:_serverLocation]];
    NSMutableURLRequest *afRequest = [httpClient multipartFormRequestWithMethod:@"POST"
                                                                           path:_serverIndexPage
                                                                     parameters:param
                                                      constructingBodyWithBlock:^(id <AFMultipartFormData>formData){}
                                      ];
    
    _operation = [[AFHTTPRequestOperation alloc] initWithRequest:afRequest];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    [_operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSString        *responseString = nil;
        NSData          *data = nil;
        NSDictionary    *info = nil;
        
        if (responseObject) {
            
            responseString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        }
        
        if (responseString) {
            
            data = [responseString dataUsingEncoding:NSStringEncodingConversionAllowLossy];
            
            if (data) {
                
                info = [NSJSONSerialization JSONObjectWithData:data
                                                       options:NSJSONReadingMutableContainers
                                                         error:nil];
            }
        }
        else{
            
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        
    }];
    [_operation start];
}

@end
