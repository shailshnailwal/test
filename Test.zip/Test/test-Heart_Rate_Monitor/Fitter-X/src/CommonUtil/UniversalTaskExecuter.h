//
//  UniversalTaskExecuter.h
//  GetFriends
//
//  Created by Shailsh Naiwal on 23/05/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

typedef NS_ENUM(NSInteger, DayNumber) {
    
    DayNumberForSunday = 1,
    DayNumberForMonday,
    DayNumberForTuesday,
    DayNumberForWednesday,
    DayNumberForThrusday,
    DayNumberForFriday,
    DayNumberForSaturday
};

@interface UniversalTaskExecuter : NSObject

//// create json dictionary from json valid json sting ////
+(NSDictionary *)jsonDictionaryFromString: (NSString *)jsonString;

//// image from valid string //
+(UIImage *)imageFromString: (NSString *)imageString;

//// this function takes string one dimentional array and return a sorted array of two dimention arrar ////
+(NSArray *)twoDimentionalSortedArrayWithStringArray : (NSArray *)stringArray;

+(NSArray *)twoDimentionalSortedArrayWithObjectArray : (NSArray *)objectArray withComparingObjectIndex: (NSInteger) index;

// this function all take a string array, add return all different first characters in strings of array //
+(NSArray *)arrayOfAllDiffernetFirstCharacterInStringArray: (NSArray *)stringArray;

+(NSArray *)arrayOfAllDiffernetFirstCharacterInObjectArray: (NSArray *)objectArray withComparingObjectIndex: (NSInteger) index;

//// This function will sort 2D array with inner array's indexed object ////
+(NSArray *)sortTwoDArray: (NSArray *)twoDArray withSortOrderIndex:(NSInteger)index;

+(void)setBorderForView:(UIView *)view;

//// this function will read the string form file and return it ////
+(NSString *)stringFromFileAtPath: (NSString *)path;

//// this function convert date in date component ////
+(NSDateComponents *) dateComponentsWithDate : (NSDate *)date;

////  this funciton will create a directory with a specific name in application document directory ////
+(BOOL) createDirectoryInApplicationDocumentsWithName:(NSString *)directoryName;

//// download file form specific url and return local file url ////
+(NSString *)downloadFileFromURL: (NSURL *)url asFileName:(NSString *)fileName;

////  this function return the needed size for label for string ////
+(CGSize) sizeOfLabel: (UILabel *)label forString: (NSString *)string;

//// set font of control ///
+(void)applicationTextFieldNormalFont : (UITextField *) textField;
+(void)applicationTextFieldBoldFont : (UITextField *) textField;
+(void)applicationTextViewNormalFont : (UITextView *) textView;
+(void)applicationTextViewBoldFont : (UITextView *) textView;
+(void)applicationLabelNormalFont : (UILabel *) label;
+(void)applicationLabelBoldFont : (UILabel *) label;

//// frame operation ////
+(CGRect) addHight:(CGFloat)height toFrame:(CGRect)frame;
+(CGRect) changeHightTo:(CGFloat)height toFrame:(CGRect)frame;
+(CGRect) addWidth:(CGFloat)width toFrame:(CGRect)frame;
+(CGRect) changeWidthTo:(CGFloat)width toFrame:(CGRect)frame;
+(CGRect) addHight:(CGFloat)height width:(CGFloat)width toFrame:(CGRect)frame;
+(CGRect) changeHight:(CGFloat)height width:(CGFloat)width toFrame:(CGRect)frame;
+(CGRect) moveXOrigenBy:(NSInteger)distance toFrame:(CGRect)frame;
+(CGRect) changeXOrigenTo:(NSInteger)x toFrame:(CGRect)frame;
+(CGRect) moveYOrigenBy:(NSInteger)distance toFrame:(CGRect)frame;
+(CGRect) changeYOrigenTo:(NSInteger)y toFrame:(CGRect)frame;
+(CGRect) changeXOrigenTo:(NSInteger)x yOrigenTo:(NSInteger)y toFrame:(CGRect)frame;
+(CGRect) changeOrigenToPoint:(CGPoint)point toFrame:(CGRect)frame;

//// Date operation ////
+(NSDate *) dateForComingDay:(DayNumber) daynum fromDate:(NSDate *) date;

//// serch bar in rectangular shape (no use for iOS 7) ////
+(void)rectangularSearchBar: (UISearchBar *)searchBar;

//// show alert with different information on it ////
+(void) showAlertWithTitle:(NSString *) title andMessage:(NSString *)message withButtonTitle:(NSString *)buttonTitle;

//// this function will set the frame of image view for an image so that image doesn't look squized ////
+(CGRect)frameForImageView:(UIImageView *)imageView forImage:(UIImage *)image;

//// PDF operation ////
+(NSData *) pdfDataFromTableView:(UITableView *)tableView;
+ (BOOL)joinPDFList:(NSArray *)listOfPaths inFilePath:(NSString *)fileName;

//// Email Validation ////
+(BOOL) isValidEmail:(NSString *)emailString Strict:(BOOL)strictFilter;

#pragma mark - unchecked section
//// unchecked for changing textview height with fixed width ////
+ (CGFloat)textViewHeightForAttributedText:(NSAttributedString *)text andWidth:(CGFloat)width;
@end
