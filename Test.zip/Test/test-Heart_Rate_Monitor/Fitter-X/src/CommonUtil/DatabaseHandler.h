//
//  DatabaseClass.h
//  Shanghai WOW!
//
//  Created by Shailsh Naiwal on 22/03/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface DatabaseHandler : NSObject{
    
    sqlite3     *_dataBaseOperator;
    NSString    *_databasePath;
    BOOL        _isConnected;
}

@property(nonatomic) BOOL isConnected;

////////////// initialize variables /////////////
//-(id) init;

//// function to create singleton object ////
+(DatabaseHandler *)getDatabaseSharedObject;

////  this funciton will on foreign key constraints ////
-(BOOL)onForeignKey;

/// start connection with database, return true is connection esteblished ///
-(BOOL) startConnection;

//// end connection ///////
-(void) closeConnection;

/// creat table, return true if table created ////////
-(BOOL) createTableWithQuery: (NSString *)createTableQuery;

//////// insert query, return true if data inserted ////////////
-(BOOL) insertWithQuery: (NSString *)insertIntoTableQuery;

//// get table data in form of array of dictionaries ////
-(NSArray *)getTableColumnListForTable: (NSString *)table;

//// get table data in form of 2D array ////
-(NSArray *)getDataWithQuery: (NSString *)selectQuery;

//////////// getting data from database //////////////////////
-(NSArray *)getDataWithQuery: (NSString *)selectQuery withTableName: (NSString *)tableName;

///////// Update table data //////////////////
-(BOOL)updateTableWithQuery: (NSString *)updateQueryString;

//// delete from table  ////
-(BOOL)deleteDataForQuery:(NSString *)deleteQueryString;

//// get result with aggrigate query ////
-(NSString *)getDataForAggrigateFunctionQuery:(NSString *)query;

//// count totla record in table ////
-(NSInteger) totalRecordsInTable:(NSString *)tableName;

@end
