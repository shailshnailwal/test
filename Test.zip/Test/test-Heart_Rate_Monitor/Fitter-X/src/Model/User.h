//
//  User.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 02/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>

#define USER_USER_ID @"user_id"
#define USER_USERNAME @"username"
#define USER_FIRST_NAME @"first_name"
#define USER_LAST_NAME @"last_name"
#define USER_PASSWORD @"password"
#define USER_GENDER @"gender"
#define USER_DATE_OF_BIRTH @"date_of_birth"
#define USER_DOB @"DOB"
#define USER_WEIGHT @"weight"
#define USER_HEIGHT_FEET @"height_feet"
#define USER_HEIGHT_INCHE @"height_inche"
#define USER_DAY @"DAY"
#define USER_MONTH @"MONTH"
#define USER_YEAR @"YEAR"
#define USER_AGE @"age"

@interface User : NSObject{
    
    NSInteger _userID;
    NSString  *_username;
    NSString  *_firstName;
    NSString  *_lastName;
    NSString  *_password;
    NSString  *_gender;
    NSString  *_dateOfBirth;
    NSDate    *_dob;
    CGFloat   _weight;
    NSInteger _heightFeet;
    NSInteger _heightInche;
    NSInteger _day;
    NSInteger _month;
    NSInteger _year;
    NSInteger _age;
    
    NSMutableDictionary *_userInfo;
}

@property(nonatomic, assign) NSInteger userID;
@property(nonatomic, strong) NSString  *username;
@property(nonatomic, strong) NSString  *firstName;
@property(nonatomic, strong) NSString  *lastName;
@property(nonatomic, strong) NSString  *password;
@property(nonatomic, strong) NSString  *gender;
@property(nonatomic, strong) NSString  *dateOfBirth;
@property(nonatomic, strong) NSDate    *dob;
@property(nonatomic, assign) CGFloat   weight;
@property(nonatomic, assign) NSInteger heightFeet;
@property(nonatomic, assign) NSInteger heightInche;
@property(nonatomic, assign) NSInteger day;
@property(nonatomic, assign) NSInteger month;
@property(nonatomic, assign) NSInteger year;
@property(nonatomic, assign) NSInteger age;

@property(nonatomic, strong) NSDictionary *userInfo;

//// to get age of user ////
- (NSInteger) getAge;
@end
