//
//  UserAccount.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "UserAccount.h"

@implementation Height

@synthesize feet   = _feet;
@synthesize inches = _inche;

@end

@implementation DateOfBirth

@synthesize day = _day;
@synthesize monthNumber = _monthNumber;
@synthesize year = _year;

@end

@implementation UserAccount

@synthesize gender = _gender;
@synthesize dob    = _dob;
@synthesize height = _height;
@synthesize weight = _weight;

@end
