//
//  Report.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 07/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "Report.h"

@implementation Report

@end
