//
//  AlgoInsert.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 28/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "AlgoInsert.h"

@implementation bf_score_formula_value

@synthesize gender          = _gender;
@synthesize comparison_type = _comparison_type;
@synthesize first_value     = _first_value;
@synthesize second_value    = _second_value;
@synthesize third_value     = _third_value;
@synthesize maximum_bf      = _maximum_bf;
@synthesize minimum_bf      = _minimum_bf;
@synthesize info            = _info;


-(void)setInfo:(NSDictionary *)info{
    
    _info = info;
    
    _gender          = [info objectForKey:@"gender"];
    _comparison_type = [info objectForKey:@"comparison_type"];
    _first_value     = [[info objectForKey:@"first_value"] floatValue];
    _second_value    = [[info objectForKey:@"second_value"] floatValue];
    _third_value     = [[info objectForKey:@"third_value"] floatValue];
    _maximum_bf      = [[info objectForKey:@"maximum_bf"] floatValue];
    _minimum_bf      = [[info objectForKey:@"minimum_bf"] floatValue];
}

-(NSString *)description{
    
    return _info.description;
}

@end

@implementation mpm_score_formula_value

@synthesize comparison_type  = _comparison_type;
@synthesize first_value      = _first_value;
@synthesize second_value     = _second_value;
@synthesize maximum_distance = _maximum_distance;
@synthesize minimum_distance = _minimum_distance;
@synthesize info             = _info;

-(void)setInfo:(NSDictionary *)info{
    
    _info = info;
    
    _comparison_type  = [info objectForKey:@"comparison_type"];
    _first_value      = [[info objectForKey:@"first_value"] floatValue];
    _second_value     = [[info objectForKey:@"second_value"] floatValue];
    _maximum_distance = [[info objectForKey:@"maximum_distance"] floatValue];
    _minimum_distance = [[info objectForKey:@"minimum_distance"] floatValue];
}

-(NSString *)description{
    
    return _info.description;
}
@end

@implementation rr_score_formula_value

@synthesize comparison_type  = _comparison_type;
@synthesize first_value      = _first_value;
@synthesize second_value     = _second_value;
@synthesize third_value      = _third_value;
@synthesize maximum_rr = _maximum_rr;
@synthesize minimum_rr = _minimum_rr;
@synthesize info             = _info;

-(void)setInfo:(NSDictionary *)info{
    
    _info = info;
    
    _comparison_type  = [info objectForKey:@"comparison_type"];
    _first_value      = [[info objectForKey:@"first_value"] floatValue];
    _second_value     = [[info objectForKey:@"second_value"] floatValue];
    _third_value      = [[info objectForKey:@"third_value"] floatValue];
    _maximum_rr       = [[info objectForKey:@"maximum_rr"] floatValue];
    _minimum_rr       = [[info objectForKey:@"minimum_rr"] floatValue];
}

-(NSString *)description{
    
    return _info.description;
}
@end
