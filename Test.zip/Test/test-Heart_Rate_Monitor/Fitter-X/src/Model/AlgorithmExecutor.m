//
//  AlgorithmExecutor.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "AlgorithmExecutor.h"
#import "User.h"

@implementation AlgorithmExecutor

@synthesize scoreBoard = _scoreBoard;
@synthesize inputInfo  = _inputInfo;

@synthesize startExcerciseTime = _startExcerciseTime;

@synthesize distance   = _distance;
@synthesize age        = _age;
@synthesize gender     = _gender;
@synthesize rr         = _rr;
@synthesize hr         = _hr;
@synthesize user       = _user;
@synthesize rhr        = _rhr;
@synthesize ehr        = _ehr;
@synthesize recoveryHR = _recoveryHR;

@synthesize showSpeed    = _showSpeed;
@synthesize showAvgSpeed = _showAvgSpeed;

- (id)init
{
    self = [super init];
    if (self) {
        _scoreBoard             = [[FitterScoreBoard alloc]     init];
        _cumulativeDistanceList = [[NSMutableArray alloc]       init];
        _cumulativeSpeedList    = [[NSMutableArray alloc]       init];
        _stRangeFrequency       = [[NSMutableDictionary alloc]  init];
        
        [_stRangeFrequency setValue:[NSNumber numberWithInteger:0] forKey:KeyActiveRecovery];
        [_stRangeFrequency setValue:[NSNumber numberWithInteger:0] forKey:KeyExtensiveEndurance];
        [_stRangeFrequency setValue:[NSNumber numberWithInteger:0] forKey:KeyIntensiveEndurance];
        [_stRangeFrequency setValue:[NSNumber numberWithInteger:0] forKey:KeySubThreshold];
        [_stRangeFrequency setValue:[NSNumber numberWithInteger:0] forKey:KeySuperThreshold];
        [_stRangeFrequency setValue:[NSNumber numberWithInteger:0] forKey:KeyAnaerobicEndurance];
        [_stRangeFrequency setValue:[NSNumber numberWithInteger:0] forKey:KeyPower];
    }
    return self;
}

#pragma mark- Parameters form outside
/**
 * set recovery heart rate and calculation of recovery rate
 */
-(void) setRecoveryHR:(CGFloat)recoveryHR{
    
    _START;
    _recoveryHR               = recoveryHR;
    _scoreBoard.hrmRecoveryHR = recoveryHR;
    
    if (_maxHeartRate < recoveryHR) {
        
        _maxHeartRate = recoveryHR;
        _scoreBoard.hrmMax = _maxHeartRate;
    }
    _END;
}

/**
 * set Resting heart rate
 */
-(void) setRhr:(CGFloat)rhr{
    
    _START;
    _rhr = rhr;
    _scoreBoard.hrmRestingRate = rhr;
    
//    _scoreBoard.hrmChangeRate      = _scoreBoard.hrmRestingRate - _scoreBoard.hrmLastRHR;
//    //if(LOGS_ON) NSLog(@"any time here = %f--- %f-----%f", _scoreBoard.hrmChangeRate, _scoreBoard.hrmRestingRate, _scoreBoard.hrmLastRHR);

    if (_maxHeartRate < rhr) {
        
        _maxHeartRate = rhr;
        _scoreBoard.hrmMax = _maxHeartRate;
    }
    
    //// set start time on exercise time ////
    _startExcerciseTime = [NSDate date];
    _END;
}

/**
 * set heart rate
 */
-(void)setHr:(CGFloat)hr{
    
    _START;
    _hr = hr;
    _scoreBoard.hrmValue = hr;
    
    if (_maxHeartRate < hr) {
        
        _maxHeartRate = hr;
        _scoreBoard.hrmMax = _maxHeartRate;
    }
    _END;
}

/**
 * set distance
 */
-(void) setDistance:(CGFloat)distance{
    
    _START;
    _distance = distance;
    _scoreBoard.dmDistance = _scoreBoard.dmDistance + distance;
    _END;
}

/**
 * showing speed
 */
-(void)setShowSpeed:(CGFloat)showSpeed{
    
    _showSpeed = showSpeed;
    _scoreBoard.dmCurrentSpeed = showSpeed;
    
    if (_scoreBoard.dmMaxSpeed < showSpeed) {
        
        _scoreBoard.dmMaxSpeed = showSpeed;
    }
}

/**
 * showing avg speed
 */
-(void)setShowAvgSpeed:(CGFloat)showAvgSpeed{
    
    _showAvgSpeed = showAvgSpeed;
    _scoreBoard.dmCurrentAvgSpeed = showAvgSpeed;
}

/**
 * set ending heart rate
 */
-(void) setEhr:(CGFloat)ehr{
    
    _START;
    _ehr = ehr;
    _scoreBoard.hrmEHR = ehr;
    
    if (_maxHeartRate < ehr) {
        
        _maxHeartRate = ehr;
        _scoreBoard.hrmMax = _maxHeartRate;
    }
    _END;
}

//-(void)setMaxFitterXScore:(CGFloat)maxFitterXScore{
//    
//    _maxFitterXScore   = maxFitterXScore;
//    _scoreBoard.fxmMax = maxFitterXScore;
//}

//-(void)setMinFitterXScore:(CGFloat)minFitterXScore{
//    
//    //if(LOGS_ON) NSLog(@"min = %f", minFitterXScore);
//    _minFitterXScore = minFitterXScore;
//    _scoreBoard.fxmMin = minFitterXScore;
//}

-(void)setLastRHRValue:(CGFloat)lastRHRValue{
    
    _lastRHRValue = lastRHRValue;
    _scoreBoard.hrmLastRHR = lastRHRValue;
    //if(LOGS_ON) NSLog(@"last rhr value = %f", lastRHRValue);
}

-(void)setInputInfo:(NSDictionary *)inputInfo{
    _inputInfo = inputInfo;
    if(_inputInfo){
        
        NSArray *valueArray;// = [_inputValues objectForKey:@"last_report"];
        NSDictionary *valueInfo;// = [valueArray objectAtIndex:0];
        NSNumber *number;// = [valueInfo objectForKey:@"rhr"];
        
        valueArray = [_inputInfo objectForKey:@"last_report"];
        if (valueArray && [valueArray isKindOfClass:[NSArray class]] && valueArray.count > 0) {
            
            valueInfo = [valueArray objectAtIndex:0];
        }
        if (valueInfo && [valueInfo isKindOfClass:[NSDictionary class]]) {
            
            number = [valueInfo objectForKey:@"rhr"];
        }
        
        if (number && [number isKindOfClass:[NSString class]]) {
            
            _scoreBoard.hrmLastRHR = number.floatValue;
        }
        
        valueArray = [_inputInfo objectForKey:@"user_limits"];
        
        
        
        if (valueArray && [valueArray isKindOfClass:[NSArray class]] && valueArray.count > 0) {
            
            valueInfo = [valueArray objectAtIndex:0];
        }
        
        if (valueInfo && [valueInfo isKindOfClass:[NSDictionary class]]) {
            
            number = [valueInfo objectForKey:@"max_fitter_x_score"];
        }
        
        
        if (number && [number isKindOfClass:[NSString class]]) {
            
            _scoreBoard.fxmMax = number.floatValue;
        }
        
        if (valueInfo && [valueInfo isKindOfClass:[NSDictionary class]]) {
            
            number = [valueInfo objectForKey:@"min_fitter_x_score"];
        }
        
        if (number &&  [number isKindOfClass:[NSString class]]) {
            
            _scoreBoard.fxmMin = number.floatValue;
        }
        //if(LOGS_ON)  NSLog(@"value array = %f", _scoreBoard.fxmMin);
    }
}


//-(void) setRr:(CGFloat)rr{
//    
//    _START;
//    _rr = rr;
//    _scoreBoard.hrmRestingRate = rr;
//    _END;
//}

/**
 * this functin will start the distance counting per minute
 */
//-(void) activateExecuter{
//    
//    if (!_cumulativeDistanceList) {
//        
//        _cumulativeDistanceList = [[NSMutableArray alloc] init];
//    }
//    
//    if (_locationManager == nil) {
//        
//        _locationManager                 = [[CLLocationManager alloc] init];
//    }
//    
//    _startExcerciseTime = [NSDate date];
//    
//    _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
//    _locationManager.distanceFilter  = kCLDistanceFilterNone;
//    _locationManager.delegate        = self;
//    [_locationManager startUpdatingLocation];
//    _lastLocation                    = _locationManager.location;
//    //if(LOGS_ON) NSLog(@"location at start = %@", _lastLocation);
//    
//    _timer = [NSTimer scheduledTimerWithTimeInterval:1
//                                              target:self
//                                            selector:@selector(makeCumulativeDistanceList)
//                                            userInfo:nil
//                                             repeats:YES];
//}

#pragma mark- Algo Execuation
/**
 * this function will execute algorithm during the excercise when recovery heart rate and ending heart rate is unknown to calculate recovery rate
 */
-(void) executeAlgorithmWithLastRecoveryRate:(BOOL)userLastValue{
    
    _START;
    _age    = _user.age;
    _gender = _user.gender;
    
    //if(LOGS_ON) NSLog(@"started execuation for gender = %@, Age = %f, rhr = %f and hr = %f and distance = %f", _gender, _age, _rhr, _hr, _distance);
    
    if (_inputInfo && [_inputInfo isKindOfClass:[NSDictionary class]]) {
        
//        NSString *distance = [NSString stringWithFormat:@"%f",_scoreBoard.dmDistance * METER_TO_MILE];
        NSString *rr       = nil;//[NSString stringWithFormat:@"%f", _scoreBoard.hrmRecoveryRate];
//        NSString *bfp      = [NSString stringWithFormat:@"%f",_scoreBoard.bfp];
        NSString *temp     = nil;
        
        //// for temporary value ////
        NSArray      *inputList = nil;
        NSArray      *list      = nil;
        NSDictionary *dic       = nil;
        
        //// if last value should be used ////
        if (userLastValue) {
            
            //NSString *lastRHR = nil;
            list = [_inputInfo objectForKey:@"last_report"];
            if (list && [list isKindOfClass:[NSArray class]] && list.count > 0) {
                
                dic  = [list objectAtIndex:0];
                temp = [dic objectForKey:@"rr"];
                //lastRHR = [dic objectForKey:@"rhr"];
            }
            
            if (temp) {
                
                _scoreBoard.hrmRecoveryRate = temp.floatValue;
            }
            
//            if (lastRHR) {
//                
//                _scoreBoard.hrmLastRHR = lastRHR.floatValue;
//            }
            
            dic  = nil;
            temp = nil;
        }
        else{
            
            //// calculation of actual recovery rate when recovery heart rate and ending heart rate is found ////
            [self calculateRRCalculatinForFormulaInfo:_inputInfo withRecoveryHeartRate:_scoreBoard.hrmRecoveryHR andEHR:_scoreBoard.hrmEHR];
        }
        
        rr = [NSString stringWithFormat:@"%f", _scoreBoard.hrmRecoveryRate];
        
        //***************** to be deleted *****************//
//        rr = @"3.9";
//        _scoreBoard.hrmRecoveryRate = 3.9;
        
        
        //// for mpm score ////
        //if(LOGS_ON) NSLog(@"mpm started");
        inputList = [_inputInfo objectForKey:@"mpm_score_formula_value"];
        
        NSMutableArray *mpmArr = [[NSMutableArray alloc] init];
        mpm_score_formula_value *mpmObj = nil;
        
        for (int i = 0; inputList && [inputList isKindOfClass:[NSArray class]] && i < inputList.count; i++) {
            
            mpmObj = [[mpm_score_formula_value alloc] init];
            mpmObj.info = [inputList objectAtIndex:i];
            [mpmArr addObject:mpmObj];
        }
        
        //if(LOGS_ON) NSLog(@"for mpm = %@", mpmArr);
        
        //if(LOGS_ON) NSLog(@"list for mpm sore formula value = %@", inputList);
        NSPredicate *pri  = [NSPredicate predicateWithFormat:@"((minimum_distance > %f AND maximum_distance == -1) OR (maximum_distance < %f AND minimum_distance == -1) OR (maximum_distance >= %f AND minimum_distance <= %f and maximum_distance != -1 AND minimum_distance != -1))", _scoreBoard.dmDistance , _scoreBoard.dmDistance, _scoreBoard.dmDistance, _scoreBoard.dmDistance];
        
        //if(LOGS_ON) NSLog(@"mpm pri = %@", pri);
        
        list = [mpmArr filteredArrayUsingPredicate:pri];
        
        //if(LOGS_ON) NSLog(@"MPM list found = %@",list);
        
        dic = nil;
        
        //if(LOGS_ON) NSLog(@"MPM Score Insert Values = %@ in big list = %@", list, inputList);
        
        if (list && [list isKindOfClass:[NSArray class]] && list.count > 0) {
            
            mpmObj = [list objectAtIndex:0];
        }
        [self calculateMPMScoreForFormulaInfo:mpmObj.info];
        dic = nil;
        //if(LOGS_ON) NSLog(@"mpm ended");
        
        //// for rhr score ////
        //if(LOGS_ON) NSLog(@"rhr started");
        
        
        list = [_inputInfo objectForKey:@"last_report"];
        if (list && [list isKindOfClass:[NSArray class]] && list.count > 0) {
            
            dic  = [list objectAtIndex:0];
            temp = [dic objectForKey:@"rhr"];
        }
        
        if (temp) {
            
            _scoreBoard.hrmLastRestingRate = temp.floatValue;
            _scoreBoard.hrmChangeRate      = _scoreBoard.hrmRestingRate - _scoreBoard.hrmLastRHR;
            //if(LOGS_ON) NSLog(@"any time here = %f--- %f-----%f", _scoreBoard.hrmChangeRate, _scoreBoard.hrmRestingRate, _scoreBoard.hrmLastRHR);
        }
        dic  = nil;
        temp = nil;
        
        
        list = [_inputInfo objectForKey:@"rhr_score_formula_value"];
        if (list && [list isKindOfClass:[NSArray class]] && list.count > 0) {
            
            dic = [list objectAtIndex:0];
        }
        [self calculateRHRScoreForFormulaInfo:dic andRHR:_scoreBoard.hrmRestingRate];
        dic = nil;
        //if(LOGS_ON) NSLog(@"rhr ended");
        
        //// for mpm score ////
        //if(LOGS_ON) NSLog(@"rr started");
        inputList = [_inputInfo objectForKey:@"rr_score_formula_value"];
        
        NSMutableArray *rrArr = [[NSMutableArray alloc] init];
        rr_score_formula_value *rrObj = nil;
        
        for (int i = 0; inputList && [inputList isKindOfClass:[NSArray class]] && i < inputList.count; i++) {
            
            rrObj = [[rr_score_formula_value alloc] init];
            rrObj.info = [inputList objectAtIndex:i];
            [rrArr addObject:rrObj];
        }
        
        //*************** to delete **************//
//        _scoreBoard.hrmRecoveryRate = 5.6;
        
        pri  = [NSPredicate predicateWithFormat:@"(minimum_rr >  %f AND  maximum_rr == -1) OR (maximum_rr <  %f AND  minimum_rr ==  -1) OR (maximum_rr >=  %f AND  minimum_rr <=  %f AND  maximum_rr != -1 AND  minimum_rr != -1)", _scoreBoard.hrmRecoveryRate, _scoreBoard.hrmRecoveryRate, _scoreBoard.hrmRecoveryRate, _scoreBoard.hrmRecoveryRate];
        //if(LOGS_ON) NSLog(@"defined predicate = %@", pri);
        list = [rrArr filteredArrayUsingPredicate:pri];
        //if(LOGS_ON) NSLog(@"list for RR score = %@", list);
        if (list && [list isKindOfClass:[NSArray class]] && list.count > 0) {
            
            rrObj = [list objectAtIndex:0];
        }
        [self calculateRRScoreForFormulaInfo:rrObj.info withRecoveryRate:_scoreBoard.hrmRecoveryRate];
        dic = nil;
        //if(LOGS_ON) NSLog(@"rr ended");
        
        //// for BMI score ////
        //if(LOGS_ON) NSLog(@"bmi started");
        inputList = [_inputInfo objectForKey:@"bmi_formula_value"];
        //if(LOGS_ON) NSLog(@"list for RR score = %@", inputList);
        if (inputList && [inputList isKindOfClass:[NSArray class]] && inputList.count > 0) {
            
            dic = [inputList objectAtIndex:0];
            //if(LOGS_ON) NSLog(@"user for calculate BMI = %@", _user.userInfo);
        }
        [self calculateBMIForFormulaInfo:dic User:_user];
        dic = nil;
        //if(LOGS_ON) NSLog(@"bmi ended");
        
        //// for bf calculation score ////
        //if(LOGS_ON) NSLog(@"bf started");
        inputList = [_inputInfo objectForKey:@"bf_calculation_formula_value"];
        //if(LOGS_ON) NSLog(@"list for bf calculation = %@", inputList);
        if (inputList && [inputList isKindOfClass:[NSArray class]] && inputList.count > 0) {
            
            dic = [inputList objectAtIndex:0];
        }
        [self calculateBFPForFormulaInfo:dic andUserGender:_user];
        dic = nil;
        //if(LOGS_ON) NSLog(@"bf ended");
        
        //// for bf score ////
        //if(LOGS_ON) NSLog(@"bfs started");
        inputList = [_inputInfo objectForKey:@"bf_score_formula_value"];
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        bf_score_formula_value *insertObject = nil;
        
        for (int i = 0; inputList && [inputList isKindOfClass:[NSArray class]] && i < inputList.count; i++) {
            
            insertObject = [[bf_score_formula_value alloc] init];
            insertObject.info = [inputList objectAtIndex:i];
            [arr addObject:insertObject];
        }
        
        pri  = [NSPredicate predicateWithFormat:@"gender = %@ and ((minimum_bf > %f and maximum_bf = -1) or (maximum_bf < %f and minimum_bf = -1) or (maximum_bf >= %f and minimum_bf <= %f and maximum_bf != -1 and minimum_bf != -1))", _gender, _scoreBoard.bfp, _scoreBoard.bfp, _scoreBoard.bfp, _scoreBoard.bfp];
        
        list = [arr filteredArrayUsingPredicate:pri];
        
        if (list && [list isKindOfClass:[NSArray class]] && list.count > 0) {
            
            insertObject = [list objectAtIndex:0];
        }
        [self calculateBFScoreForFormulaInfo:insertObject.info andUser:_user];
        dic = nil;
        //if(LOGS_ON) NSLog(@"bfs ended started");
        
        //// for st score ////
        //if(LOGS_ON) NSLog(@"st started");
        inputList = [_inputInfo objectForKey:@"st_calculation_formula_value"];
        //if(LOGS_ON) NSLog(@"input list for st score = %@", inputList);
        if (inputList && [inputList isKindOfClass:[NSArray class]] && inputList.count > 0) {
            
            [self setCumulativeAverageExerciseHeartRateWithHeartRate:_scoreBoard.hrmValue];
            [self findTypeFrequencyForHeartRate:_scoreBoard.hrmValue withFormulaInfoList:inputList];
            [self calculateSTScore];
        }
        //if(LOGS_ON) NSLog(@"st ended");
        
        //// for master calculation ////
        //if(LOGS_ON) NSLog(@"master started");
        inputList = [_inputInfo objectForKey:@"master_calculation"];
        //if(LOGS_ON) NSLog(@"for master calculation inputs = %@", inputList);
        [self calculateFitterXScoreForForFormulaInfoList:inputList];
        [self calculateFitterXRateWithFormulaInfoList:inputList];
        //if(LOGS_ON) NSLog(@"master ended");
    }
    _END;
}

/**
 * this function will call other function for continue activity ****** no use now *******
 */
//-(void) continueActivity{
//    
//    [self makeCumulativeDistanceList];
//}

/**
 * this function will stop every second cumulative distance list creation
 */
-(void) deactivateExecuter{
    
    if (_timer && [_timer isValid]) {
        
        [_timer invalidate];
        _timer = nil;
    }
    
    _lastLocation = nil;
    //if(LOGS_ON) NSLog(@"Cumulative array of speed = %@", _cumulativeDistanceList);
}

#pragma mark- Distance and MPM
/**
 * this function will calculate meter per minute score for formulaInfo
 * formulaInfo is a collection of insert values for formula
 */
-(void) calculateMPMScoreForFormulaInfo:(NSDictionary *)formulaInfo{
    
    _START;
    CGFloat  mpmScore     = 0.0;
    CGFloat  firstValue   = 0.0;
    CGFloat  secondValue  = 0.0;
    NSString *valueString = nil;
    //CGFloat  currentSpeed = 0.0;
    
    //// when total distance changes ////
//    if (_scoreBoard.dmDistance != _scoreBoard.dmLastDistance) {
    
        //// make cumulative speed list ////
        [self makeCumulativeSpeedList];
        
        //currentSpeed = (_scoreBoard.dmDistance - _scoreBoard.dmLastDistance) / TIME_FOR_ALGO_EXECUATION;
        
        //if(LOGS_ON) NSLog(@"formula insert info = %@", formulaInfo);
        //// get formula insert values ////
        if (formulaInfo) {
            
            //if(LOGS_ON) NSLog(@"it's fine");
            valueString = [formulaInfo objectForKey:@"first_value"];
            //if(LOGS_ON) NSLog(@"first value = %@", valueString);
            if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
                
                firstValue = valueString.floatValue;
            }
            
            valueString = [formulaInfo objectForKey:@"second_value"];
            //if(LOGS_ON) NSLog(@"second value = %@", valueString);
            if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
                
                secondValue = valueString.floatValue;
            }
        }
        
        if (!_scoreBoard) {
            
            _scoreBoard = [[FitterScoreBoard alloc] init];
        }
        
        if (secondValue != 0) {
            
            mpmScore = (_scoreBoard.dmAvgSpeed - firstValue) / secondValue;
        }
        else{
            
            //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nMPM Score = (%f - %f) / %f = %f", //_scoreBoard.formulaString,_scoreBoard.dmAvgSpeed, firstValue, secondValue, mpmScore];
        }
        
        //if(LOGS_ON) NSLog(@"mpmScore = (%f - %f) / %f",_scoreBoard.dmAvgSpeed, firstValue, secondValue);
        //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nMPM Score = (%f - %f) / %f = %f", //_scoreBoard.formulaString,_scoreBoard.dmAvgSpeed, firstValue, secondValue, mpmScore];
        
        _scoreBoard.dmMPMScore = mpmScore;
        
        //if(LOGS_ON) NSLog(@"mpm score = %f for first value = %f and second value = %f", mpmScore, firstValue, secondValue);
//    }
    
//    _scoreBoard.dmCurrentSpeed = currentSpeed;    
    _scoreBoard.dmLastDistance = _scoreBoard.dmDistance;
    _END;
}

/**
 * this functin will be called every second and make cumulative distance list
 */
-(void) makeCumulativeSpeedList{
    
    _START;
    NSTimeInterval minutes = 0.0;
    CGFloat        speed   = 0.0;
    
    _endExcerciseTime = [NSDate date];
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
//    if (_cumulativeDistanceList.count == 0 && _lastLocation != nil){
//        
//        _scoreBoard.dmDistance = distanceObj;
//        [_cumulativeDistanceList addObject:[NSNumber numberWithDouble:distanceObj]];
//    }
//    else if (_cumulativeDistanceList.count > 0 && _lastLocation != nil){
//        
//        lastCumulativeObj       = [_cumulativeDistanceList objectAtIndex:(_cumulativeDistanceList.count - 1)];
//        lastCumulativeDistance  = lastCumulativeObj.doubleValue;
//        _scoreBoard.dmDistance  = (distanceObj + lastCumulativeDistance);
//        
//        [_cumulativeDistanceList addObject:[NSNumber numberWithDouble:_scoreBoard.dmDistance]];
//    }
//    
//    //if(LOGS_ON) NSLog(@"Distance = %f",distanceObj);
    
    minutes = lroundf([_endExcerciseTime timeIntervalSinceDate:_startExcerciseTime]);
    minutes = minutes / 60.0;
    
    if (minutes > 0) {
        
        speed = _scoreBoard.dmDistance / minutes;
    }
    
    _scoreBoard.dmSpeed = speed / 60;
    
    if (!_cumulativeSpeedList) {
        
        _cumulativeSpeedList = [[NSMutableArray alloc] init];
    }
    
    //if(LOGS_ON) NSLog(@"speed = %f , distance = %f and time taken = %f having starting date = %@ and ending date = %@", speed, _scoreBoard.dmDistance, minutes, _startExcerciseTime, _endExcerciseTime);
    
    [_cumulativeSpeedList addObject:[NSNumber numberWithFloat:speed]];
    
    _scoreBoard.dmAvgSpeed = [self averageSpeedFromSpeedList:_cumulativeSpeedList];
    _END;
}

/**
 * this function will calculate average speed from speed list
 */
-(CGFloat) averageSpeedFromSpeedList:(NSArray *)speedList{
    
    _START;
    CGFloat   avgSpeed           = 0.0;
    NSNumber  *currentSpeedObj   = nil;
    CGFloat   speedCumulativeSum = 0.0;
    NSInteger count              = 0;
    
    if (speedList) {
        
        count = speedList.count;
    }
    
    for (int i = 0; i < count; i++) {
        
        currentSpeedObj    = [speedList objectAtIndex:i];
        speedCumulativeSum = speedCumulativeSum + currentSpeedObj.floatValue;
    }
    
    if (count > 0) {
        
        avgSpeed = speedCumulativeSum / count;
    }
    _END;
    return avgSpeed;
}

#pragma mark- Heart Rate and Heart Rate Score
/**
 * this function will calculate Resting Heart Rate Score for formulaInfo and Resting Heart Rate
 * formulaInfo contains all insert values for formula
 */
-(void) calculateRHRScoreForFormulaInfo:(NSDictionary *)formulaInfo andRHR:(CGFloat)rhr {
    
    _START;
    CGFloat rhrScore      = 0.0;
    CGFloat firstValue    = 0.0;
    CGFloat secondValue   = 0.0;
    CGFloat thirdValue    = 0.0;
    NSString *valueString = nil;
    
    //// get formula insert values ////
    if (formulaInfo) {
        
        valueString = [formulaInfo objectForKey:@"first_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            firstValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"second_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            secondValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"third_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            thirdValue = valueString.floatValue;
        }
    }
    
    rhrScore = (firstValue - rhr) * secondValue + thirdValue;
//    //if(LOGS_ON) NSLog(@"rhrScore = (%f - %f) * %f + %f", firstValue, rhr, secondValue, thirdValue);
     //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nResting Heart Rate Score = (%f - %f) * %f + %f = %f", //_scoreBoard.formulaString,firstValue, rhr, secondValue, thirdValue, rhrScore];
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    _scoreBoard.hrmRestingRateScore = rhrScore;
    
    //if(LOGS_ON) NSLog(@"rhr score after calculation = %f", _scoreBoard.hrmRestingRateScore);
    _END;
}

/**
 * this function will calculate Recovery Heart Rate Score for scoreFormulaInfo calFormulaInfo and Resting Heart Rate
 * formulaInfo contains all insert values for formula
 */
-(void) calculateRRScoreForFormulaInfo:(NSDictionary *)scoreFormulaInfo withRecoveryRate:(CGFloat)rr{
    
    _START;
    CGFloat  rrScore       = 0.0;
    CGFloat  firstValue    = 0.0;
    CGFloat  secondValue   = 0.0;
    CGFloat  thirdValue    = 0.0;
    NSString *valueString  = nil;
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    //// get formula insert values ////
    if (scoreFormulaInfo) {
        
        valueString = [scoreFormulaInfo objectForKey:@"first_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            firstValue = valueString.floatValue;
        }
        
        valueString = [scoreFormulaInfo objectForKey:@"second_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            secondValue = valueString.floatValue;
        }
        
        valueString = [scoreFormulaInfo objectForKey:@"third_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            thirdValue = valueString.floatValue;
        }
    }
    
    //// recovery rate score calculatoin ////
//    if (rr <=  6 && rr >= 3.5) {
    
        rrScore = (rr - firstValue) * secondValue + thirdValue;
//    }
    
//    //if(LOGS_ON) NSLog(@"rrScore = (%f - %f) * %f + %f",rr, firstValue, secondValue, thirdValue);
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nRecovery Rate Score = (%f - %f) * %f + %f = %f", //_scoreBoard.formulaString,rr, firstValue, secondValue, thirdValue, rrScore];
    
    _scoreBoard.hrmRecoveryRateScore = rrScore;
    //if(LOGS_ON) NSLog(@"recovery rate after calculation = %f with values = %f and %f with rr = %f", _scoreBoard.hrmRecoveryRateScore, firstValue, secondValue, rr);
}

/**
 * this function will calculate Recovery Heart Rate for formulaInfo and Recovery Heart Rate and Ending Heart Rate
 * formulaInfo contains all insert values for formula
 */
-(void) calculateRRCalculatinForFormulaInfo:(NSDictionary *)formulaInfo withRecoveryHeartRate:(CGFloat)recoveryHeartRate andEHR:(CGFloat)ehr{
    
    _START;
    CGFloat  rrCalculation = 0.0;
    CGFloat  rrInsertValue = 0.0;
    NSString *valueString  = nil;
    NSDictionary *valueDict    = nil;
    NSArray  *valueArr     = nil;
    
    //// get formula insert values ////
    //if(LOGS_ON) NSLog(@"Formula info = %@", formulaInfo);
    if (formulaInfo) {
        
        valueArr = [formulaInfo objectForKey:@"rr_formula_value"];
    }
    
    if (valueArr && [valueArr isKindOfClass:[NSArray class]] && valueArr.count > 0) {
        
        valueDict = [valueArr objectAtIndex:0];
    }
    
    if (valueDict) {
        
        valueString = [valueDict objectForKey:@"rr_value"];
        //if(LOGS_ON) NSLog(@"value = %@", valueString);
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            rrInsertValue = valueString.floatValue;
        }
    }
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    //// for recovery rate value ////
    if (rrInsertValue != 0) {
        
        rrCalculation = (ehr - recoveryHeartRate) / rrInsertValue;
        
    }
    
//    //if(LOGS_ON) NSLog(@"rrCalculation = (%f - %f) / %f", ehr,recoveryHeartRate, rrInsertValue);
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nRecovery Rate Calculation = (%f - %f) / %f = %f", //_scoreBoard.formulaString,ehr,recoveryHeartRate, rrInsertValue, rrCalculation];
    
    _scoreBoard.hrmRecoveryRate      = rrCalculation;
}

#pragma mark- Body Fate and Body Fate Score
-(void) calculateBFScoreForFormulaInfo:(NSDictionary *)formulaInfo andUser:(User *)user {
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    CGFloat bfScore        = 0.0;
    
    CGFloat  firstValue    = 0.0;
    CGFloat  secondValue   = 0.0;
    CGFloat  thirdValue    = 0.0;
    NSString *valueString  = nil;
    
    //// get formula insert values ////
    if (formulaInfo) {
        
        valueString = [formulaInfo objectForKey:@"first_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            firstValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"second_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            secondValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"third_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            thirdValue = valueString.floatValue;
        }
    }
    
    bfScore = (firstValue - _scoreBoard.bfp) / secondValue + thirdValue;
    
//    //if(LOGS_ON) NSLog(@"bfScore = (%f - %f) / %f + %f",firstValue,_scoreBoard.bfp, secondValue, thirdValue);
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nBody Fat Score = (%f - %f) / %f + %f = %f", //_scoreBoard.formulaString,firstValue,_scoreBoard.bfp, secondValue, thirdValue, bfScore];
    _scoreBoard.bfs = bfScore;
    
    //if(LOGS_ON) NSLog(@"bf score after calculation = %f for values = %f, %f, %f and BFP = %f", _scoreBoard.bfs, firstValue, secondValue, thirdValue, _scoreBoard.bfp);
}

/**
 * calculate Body Fate Percentage for user
 */
-(void) calculateBFPForFormulaInfo:(NSDictionary *)formulaInfo andUserGender:(User *)user {
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    CGFloat bmi      = _scoreBoard.bmi;
    NSInteger gender = [[user.gender uppercaseString] isEqualToString:GENDER_MALE_CHAR] ? 1 : 0;
    CGFloat bfp      = 0.0;
    
    CGFloat  firstValue    = 0.0;
    CGFloat  secondValue   = 0.0;
    CGFloat  thirdValue    = 0.0;
    CGFloat  forthValue    = 0.0;
    CGFloat  fifthValue    = 0.0;
    NSString *valueString  = nil;
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    //// get formula insert values ////
    if (formulaInfo) {
        
        valueString = [formulaInfo objectForKey:@"first_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            firstValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"second_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            secondValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"third_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            thirdValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"forth_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            forthValue = valueString.floatValue;
        }
        
        valueString = [formulaInfo objectForKey:@"fifth_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            fifthValue = valueString.floatValue;
        }
    }
    
    //if(LOGS_ON) NSLog(@"---age is = %d", user.age);
    
    if (user.age < 18) { // for child
        
        bfp = (firstValue * bmi) - (secondValue * user.age) - (thirdValue * forthValue) + fifthValue;
        
        //if(LOGS_ON) NSLog(@"Child Body Fate Percentage = %f * %f - %f * %d - %f * %d + %f",firstValue, bmi, secondValue, user.age, thirdValue, gender, forthValue);
        //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nChild Body Fat Calculation = (%f * %f) - (%f * %d) - (%f * %f) + %f = %f", //_scoreBoard.formulaString,firstValue, bmi, secondValue, user.age, thirdValue, forthValue, fifthValue, bfp];
        _scoreBoard.bfp = bfp;
    }
    else{ // for adult
        
        bfp = (firstValue * bmi) - (secondValue * user.age) - (thirdValue * forthValue) - fifthValue;
        
        //if(LOGS_ON) NSLog(@"Adult Body Fate Percentage = %f * %f + %f * %d - %f * %d + %f",firstValue, bmi, secondValue, user.age, thirdValue, gender, forthValue);
        //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nAdult Body Fat Calculation = (%f * %f) - (%f * %d) - (%f * %f) - %f = %f", //_scoreBoard.formulaString,firstValue, bmi, secondValue, user.age, thirdValue, forthValue, fifthValue, bfp];
        _scoreBoard.bfp = bfp;
    }
    
    //if(LOGS_ON) NSLog(@"BFP after calculation = %f, for values = %f, %f, %f, %f and gender = %d and age = %d", _scoreBoard.bfp, firstValue, secondValue, thirdValue, forthValue, gender, user.age);
}

/**
 * calculate BMI for user
 */
-(void) calculateBMIForFormulaInfo:(NSDictionary *)formulaInfo User:(User *)user {
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    CGFloat heightInches  = 0.0;
    CGFloat weight        = 0.0;
    CGFloat bmi           = 0.0;
    CGFloat firstValue    = 0.0;
    NSString *valueString = nil;
    
    if (formulaInfo) {
        
        valueString = [formulaInfo objectForKey:@"first_value"];
        if (valueString && ![valueString isEqualToString:EMPTY_STRING]) {
            
            firstValue = valueString.floatValue;
        }
    }
    
    if (user) {
        
        heightInches = user.heightFeet * 12 + user.heightInche;
        weight       = user.weight;
    }
    
    //// actual calculation of bmi ////
    if (heightInches > 0 && firstValue != 0) {
        
        bmi = (weight / (heightInches * heightInches)) * firstValue;
    }
    
//    //if(LOGS_ON) NSLog(@"bmi = (%f / (%f * %f)) * %f",weight, heightInches, heightInches, firstValue);
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nBMI = (%f / (%f * %f)) * %f = %f", //_scoreBoard.formulaString,weight, heightInches, heightInches, firstValue, bmi];
    
    _scoreBoard.bmi = bmi;
    //if(LOGS_ON) NSLog(@"bmi after calculation = %f for height = %f and weight = %f", _scoreBoard.bmi, heightInches, user.weight);
}

/**
 * Meter per minute score calculation
 */
//-(void) setMPMWithCoveredMeterInOneMinute:(CGFloat)distance{
//    
//    if (!_scoreBoard) {
//        
//        _scoreBoard = [[FitterScoreBoard alloc] init];
//    }
//    
//    if (!_mpmList) {
//        
//        _mpmList = [[NSMutableArray alloc] init];
//    }
//    
//    [_mpmList addObject:[NSNumber numberWithFloat:distance]];
//}

#pragma mark- Thrashold Score Calculation
/**
 * for sustainable thrashold calculation
 */
-(void) setCumulativeAverageExerciseHeartRateWithHeartRate:(CGFloat)heartRate{
    
    CGFloat  avgHeartRate     = 0.0;
    NSNumber *lastObject      = nil;
    CGFloat  lastAvgHeartRate = 0.0;
    
    if (!_caehrList) {
        
        _caehrList = [[NSMutableArray alloc] init];
    }
    
    //// if there is atleast one element in cumulative average excercise heart rate list ////
    if (_caehrList.count > 0) {
    
        lastObject       = [_caehrList objectAtIndex:(_caehrList.count - 1)];
        lastAvgHeartRate = lastObject.floatValue;
        avgHeartRate     = (_caehrList.count * lastAvgHeartRate + heartRate) / (_caehrList.count + 1);
    }
    else{
        
        avgHeartRate = heartRate;
    }
    _scoreBoard.hrmAvgExerciseHR = avgHeartRate;
    [_caehrList addObject:[NSNumber numberWithFloat:avgHeartRate]];
    //if(LOGS_ON) NSLog(@"Cumulative A E H R = %@----- %f", _caehrList, heartRate);
}

/**
 * find range frequency
 */
-(void) findTypeFrequencyForHeartRate:(CGFloat)hr withFormulaInfoList:(NSArray *)infoList{
    
    _START;
    NSString *key       = nil;
    NSDictionary *info  = nil;
    NSNumber *numberObj = nil;
    CGFloat leftValue   = 0.0;
    CGFloat rightValue  = 0.0;
    CGFloat avgExcHR    = 0.0;
    
    //********* to delete ******//
    NSString *temp;
    
    numberObj = [_caehrList lastObject];
    if (numberObj) {
        
        avgExcHR  = numberObj.floatValue;
    }
    
    //if(LOGS_ON) NSLog(@"list for find frequency type = %@ and heart rate = %f and aehr = %f", infoList, hr, avgExcHR);
    
    for (int i = 0; infoList && [infoList isKindOfClass:[NSArray class]] && infoList.count > 0 && i < infoList.count; i ++) {
        
        //if(LOGS_ON) NSLog(@"in loop");
        info = [infoList objectAtIndex:i];
        if (info && [info isKindOfClass:[NSDictionary class]]) {
            
            key = [info objectForKey:@"range_type"];
            //if(LOGS_ON) NSLog(@"to check range = %@", key);
            if ([key isEqualToString:KeyActiveRecovery]) {  //// Active recovery have only one value ////
                
                numberObj = [info objectForKey:@"second_value"];
                rightValue = numberObj.floatValue;
            }
            else{
                
                numberObj = [info objectForKey:@"first_value"];
                leftValue = numberObj.floatValue;
                numberObj = [info objectForKey:@"second_value"];
                rightValue = numberObj.floatValue;
            }
            
            //if(LOGS_ON) NSLog(@"first value = %f, and second value = %f", leftValue, rightValue);
            
            //if(LOGS_ON) NSLog(@"%f > %f * %f && %f < %f * %f", hr , leftValue , avgExcHR , hr , rightValue , avgExcHR);
            
            //// increasing frequence of range type key value for heart rate ////
            if (hr > leftValue * avgExcHR && hr < rightValue * avgExcHR) {
                
                //if(LOGS_ON) NSLog(@"%f > %f * %f && %f < %f * %f", hr, leftValue, avgExcHR, hr, rightValue, avgExcHR);
                
                ////_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nCurent Values Heart Rate = %f and Average Exercise Heart Rate = %f",//_scoreBoard.formulaString, hr, avgExcHR];
                
                if ([key isEqualToString:KeyActiveRecovery]) {
                    
                    temp = KeyActiveRecovery;
                    //if(LOGS_ON) NSLog(@"KeyActiveRecovery");
                    numberObj = [_stRangeFrequency objectForKey:key];
                    numberObj = [NSNumber numberWithFloat:numberObj.floatValue+1];
                    [_stRangeFrequency setValue:numberObj forKey:key];
                }
                else if ([key isEqualToString:KeyExtensiveEndurance]) {
                    
                    temp = KeyExtensiveEndurance;
                    //if(LOGS_ON) NSLog(@"KeyExtensiveEndurance");
                    numberObj = [_stRangeFrequency objectForKey:key];
                    numberObj = [NSNumber numberWithFloat:numberObj.floatValue+1];
                    [_stRangeFrequency setValue:numberObj forKey:key];
                }
                else if ([key isEqualToString:KeyIntensiveEndurance]) {
                    
                    temp = KeyIntensiveEndurance;
                    //if(LOGS_ON) NSLog(@"KeyIntensiveEndurance");
                    numberObj = [_stRangeFrequency objectForKey:key];
                    numberObj = [NSNumber numberWithFloat:numberObj.floatValue+1];
                    [_stRangeFrequency setValue:numberObj forKey:key];
                }
                else if ([key isEqualToString:KeySubThreshold]) {
                    
                    temp = KeySubThreshold;
                    //if(LOGS_ON) NSLog(@"KeySubThreshold");
                    numberObj = [_stRangeFrequency objectForKey:key];
                    numberObj = [NSNumber numberWithFloat:numberObj.floatValue+1];
                    [_stRangeFrequency setValue:numberObj forKey:key];
                }
                else if ([key isEqualToString:KeySuperThreshold]) {
                    
                    temp = KeySuperThreshold;
                    //if(LOGS_ON) NSLog(@"KeySuperThreshold");
                    numberObj = [_stRangeFrequency objectForKey:key];
                    numberObj = [NSNumber numberWithFloat:numberObj.floatValue+1];
                    [_stRangeFrequency setValue:numberObj forKey:key];
                }
                else if ([key isEqualToString:KeyAnaerobicEndurance]) {
                    
                    temp = KeyAnaerobicEndurance;
                    //if(LOGS_ON) NSLog(@"KeyAnaerobicEndurance");
                    numberObj = [_stRangeFrequency objectForKey:key];
                    numberObj = [NSNumber numberWithFloat:numberObj.floatValue+1];
                    [_stRangeFrequency setValue:numberObj forKey:key];
                }
                else if ([key isEqualToString:KeyPower]) {
                    
                    temp = KeyPower;
                    //if(LOGS_ON) NSLog(@"KeyPower");
                    numberObj = [_stRangeFrequency objectForKey:key];
                    numberObj = [NSNumber numberWithFloat:numberObj.floatValue+1];
                    [_stRangeFrequency setValue:numberObj forKey:key];
                }
            }
        }
    }
    
    ////_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nFound Heart Rate Under Range of = %@",//_scoreBoard.formulaString, temp];
    //if(LOGS_ON) NSLog(@"Frequency = %@", _stRangeFrequency);
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nFrequency = %@",//_scoreBoard.formulaString, _stRangeFrequency];
    
    //if(LOGS_ON) NSLog(@"strange frequency = %@", _stRangeFrequency);
    _END;
}

/**
 * this function will calculate Sustainable Thrashold Score
 */
-(void) calculateSTScore{
    
    _START;
    CGFloat activeRecoveryScore      = 0.0;
    CGFloat extensiveEnduranceScore  = 0.0;
    CGFloat intensiveEnduranceScore  = 0.0;
    CGFloat subThresholdScore        = 0.0;
    CGFloat superThresholdScore      = 0.0;
    CGFloat anaerobicEnduranceScore  = 0.0;
    CGFloat powerScore               = 0.0;
    CGFloat firstValue = 0.0;
    CGFloat secondValue = 0.0;
    
    NSArray *valueList                = [_inputInfo objectForKey:@"st_score_formula_value"];
    NSDictionary *dict = nil;
    
    NSNumber *numberObj = nil;
    //if(LOGS_ON) NSLog(@"\n");
    
//    if (valueList && [valueList isKindOfClass:[NSArray class]] && valueList.count > 0) {
//        
//        for (int i = 0; i < valueList.count; i ++) {
//            
//            dict = [valueList objectAtIndex:i];
//            if (dict) {
//                
//                numberObj = [dict objectForKey:@"first_value"];
//                if (numberObj) {
//                    
//                    firstValue = numberObj.floatValue;
//                }
//                
//                numberObj = [dict objectForKey:@"second_value"];
//                if (numberObj) {
//                    
//                    secondValue = numberObj.floatValue;
//                }
    
//                if ([[dict objectForKey:@"score_type"] isEqualToString:KeyActiveRecovery]) {
    
//                    numberObj = [_stRangeFrequency objectForKey:KeyActiveRecovery];
//                    //if(LOGS_ON) NSLog(@"value in array = %@", numberObj);
//                    if (numberObj) activeRecoveryScore = (10 * numberObj.floatValue) / 1.0;
//                    //if(LOGS_ON) NSLog(@"activeRecoveryScore = %f", activeRecoveryScore);
//                }
//                else if ([[dict objectForKey:@"score_type"] isEqualToString:KeyExtensiveEndurance]) {
    
                    numberObj = [_stRangeFrequency objectForKey:KeyExtensiveEndurance];
                    //if(LOGS_ON) NSLog(@"value in array = %@", numberObj);
                    if (numberObj) extensiveEnduranceScore = (10 * numberObj.floatValue) / (43200 * TIME_FOR_ALGO_EXECUATION);
                    //if(LOGS_ON) NSLog(@" = %f", activeRecoveryScore);
//                }
//                else if ([[dict objectForKey:@"score_type"] isEqualToString:KeyIntensiveEndurance]) {
    
                    numberObj = [_stRangeFrequency objectForKey:KeyIntensiveEndurance];
                    //if(LOGS_ON) NSLog(@"value in array = %@", numberObj);
                    if (numberObj) intensiveEnduranceScore = (10 * numberObj.floatValue ) / (28800 * TIME_FOR_ALGO_EXECUATION);
                    //if(LOGS_ON) NSLog(@"extensiveEnduranceScore = %f", extensiveEnduranceScore);
//                }
//                else if ([[dict objectForKey:@"score_type"] isEqualToString:KeySubThreshold]) {
    
                    numberObj         = [_stRangeFrequency objectForKey:KeySubThreshold];
                    //if(LOGS_ON) NSLog(@"value in array = %@", numberObj);
                    if (numberObj) subThresholdScore = (10 * numberObj.floatValue) / (10800 * TIME_FOR_ALGO_EXECUATION);
                    //if(LOGS_ON) NSLog(@"subThresholdScore = %f", subThresholdScore);
//                }
//                else if ([[dict objectForKey:@"score_type"] isEqualToString:KeySuperThreshold]) {
    
                    numberObj = [_stRangeFrequency objectForKey:KeySuperThreshold];
                    //if(LOGS_ON) NSLog(@"value in array = %@", numberObj);
                    if (numberObj) superThresholdScore = (10 * numberObj.floatValue) / (3600 * TIME_FOR_ALGO_EXECUATION);
                    //if(LOGS_ON) NSLog(@"superThresholdScore = %f", superThresholdScore);
//                }
//                else if ([[dict objectForKey:@"score_type"] isEqualToString:KeyAnaerobicEndurance]) {
    
                    numberObj = [_stRangeFrequency objectForKey:KeyAnaerobicEndurance];
                    //if(LOGS_ON) NSLog(@"value in array = %@", numberObj);
                    if (numberObj) anaerobicEnduranceScore = (10 * numberObj.floatValue) / (1200 * TIME_FOR_ALGO_EXECUATION);
                    //if(LOGS_ON) NSLog(@"anaerobicEnduranceScore = %f", anaerobicEnduranceScore);
//                }
//                else if ([[dict objectForKey:@"score_type"] isEqualToString:KeyPower]) {
    
                    numberObj = [_stRangeFrequency objectForKey:KeyPower];
                    //if(LOGS_ON) NSLog(@"value in array = %@", numberObj);
                    if (numberObj) powerScore = (10 * numberObj.floatValue) / (120 * TIME_FOR_ALGO_EXECUATION);
                    //if(LOGS_ON) NSLog(@"powerScore = %f", powerScore);
//                }
//            }
//        }
//    }
    
    if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    _scoreBoard.stScore = (0 + extensiveEnduranceScore + intensiveEnduranceScore
                           + subThresholdScore + superThresholdScore + anaerobicEnduranceScore + powerScore);
    
//    //if(LOGS_ON) NSLog(@"st score after calculation = %f for values = %f, %f, %f, %f, %f, %f, %f for value info = %@", _scoreBoard.stScore, activeRecoveryScore, extensiveEnduranceScore, intensiveEnduranceScore, subThresholdScore, superThresholdScore, anaerobicEnduranceScore, powerScore, _stRangeFrequency);
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nSustainable Threshold Score = (%f + %f + %f                                 + %f + %f + %f + %f = %f)", //_scoreBoard.formulaString,activeRecoveryScore , extensiveEnduranceScore,intensiveEnduranceScore, subThresholdScore, superThresholdScore, anaerobicEnduranceScore, powerScore, _scoreBoard.stScore];
    _END;
}

#pragma mark- Master Calculation or Fitter X Score Calculation
-(void) calculateFitterXScoreForForFormulaInfoList:(NSArray *)infoList{
    
    _START;
    NSPredicate  *pri         = nil;
    NSArray      *list        = nil;
    NSDictionary *info        = nil;
    NSString     *compareWith = nil;
    
    if (_scoreBoard.dmDistance * METER_TO_MILE >= 1) {
        
        compareWith = @"1";
    }
    else{
        
        compareWith = @"0";
    }
    
    pri  = [NSPredicate predicateWithFormat:@"(big_distance == %@)", compareWith];
    list = [infoList filteredArrayUsingPredicate:pri];
    
    if (list && list.count > 0) {
        
        info = [list objectAtIndex:0];
    }
    
    //if(LOGS_ON) NSLog(@"list after filter = %@", list);
    CGFloat rhrScorePercentage = 0.0;
    CGFloat rrScorePercentage  = 0.0;
    CGFloat bfScorePercentage  = 0.0;
    CGFloat stScorePercentage  = 0.0;
    CGFloat mpmScorePercentage = 0.0;
    CGFloat fitterXScore       = 0.0;
    
    NSNumber *numberObj        = nil;
    
    numberObj = [info objectForKey:@"rhr_score"];
    if (numberObj) rhrScorePercentage = numberObj.floatValue;
    
    numberObj = [info objectForKey:@"rr_score"];
    if (numberObj) rrScorePercentage = numberObj.floatValue;
    
    numberObj = [info objectForKey:@"bf_score"];
    if (numberObj) bfScorePercentage = numberObj.floatValue;
    
    numberObj = [info objectForKey:@"st_score"];
    if (numberObj) stScorePercentage = numberObj.floatValue;
    
    numberObj = [info objectForKey:@"mpm_score"];
    if (numberObj) mpmScorePercentage = numberObj.floatValue;
    
        if (!_scoreBoard) {
        
        _scoreBoard = [[FitterScoreBoard alloc] init];
    }
    
    fitterXScore = (_scoreBoard.hrmRestingRateScore * rhrScorePercentage + _scoreBoard.hrmRecoveryRateScore * rrScorePercentage +
                    _scoreBoard.bfs * bfScorePercentage + _scoreBoard.stScore * stScorePercentage + _scoreBoard.dmMPMScore * mpmScorePercentage) / 100;
    //if(LOGS_ON) NSLog(@"fitterXScore = (%f * %f + %f * %f + %f * %f + %f * %f + %f * %f)",_scoreBoard.hrmRestingRateScore , rhrScorePercentage , _scoreBoard.hrmRecoveryRateScore , rrScorePercentage , _scoreBoard.bfs , bfScorePercentage , _scoreBoard.stScore , stScorePercentage , _scoreBoard.dmMPMScore , mpmScorePercentage);
    
    //if(LOGS_ON) NSLog(@"on calculation = %f", _scoreBoard.hrmRecoveryRate);
    
    
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nFitterX Score = (%f * %f + %f * %f + %f * %f + %f * %f + %f * %f) / 100 = %f", //_scoreBoard.formulaString,_scoreBoard.hrmRestingRateScore , rhrScorePercentage , _scoreBoard.hrmRecoveryRateScore , rrScorePercentage , _scoreBoard.bfs , bfScorePercentage , _scoreBoard.stScore , stScorePercentage , _scoreBoard.dmMPMScore , mpmScorePercentage, fitterXScore];
    
    _scoreBoard.fxmScore = fitterXScore;
    //if(LOGS_ON) NSLog(@"final score = %f", _scoreBoard.fxmScore);
    _END;
}

-(void) calculateFitterXRateWithFormulaInfoList:(NSArray *)infoList{
    
    _START;
    
    NSPredicate  *pri         = nil;
    NSArray      *list        = nil;
    NSDictionary *info        = nil;
    NSString     *compareWith = nil;
    if (_scoreBoard.dmDistance * METER_TO_MILE >= 1) {
        
        compareWith = @"1";
    }
    else{
        
        compareWith = @"0";
    }
    
    pri  = [NSPredicate predicateWithFormat:@"(big_distance == %@)", compareWith];
    list = [infoList filteredArrayUsingPredicate:pri];
    
    if (list && list.count > 0) {
        
        info = [list objectAtIndex:0];
    }
    
    //if(LOGS_ON) NSLog(@"list after filter = %@", list);
    CGFloat stScorePercentage  = 0.0;
    CGFloat mpmScorePercentage = 0.0;
    
    NSNumber *numberObj        = nil;
    
    numberObj = [info objectForKey:@"st_score"];
    if (numberObj) stScorePercentage = numberObj.floatValue;
    
    numberObj = [info objectForKey:@"mpm_score"];
    if (numberObj) mpmScorePercentage = numberObj.floatValue;
    
    _scoreBoard.fxmRate = (_scoreBoard.stScore * stScorePercentage + _scoreBoard.dmMPMScore * mpmScorePercentage) / 100.0;
    
    //if(LOGS_ON) NSLog(@"rate calculated  = %f", _scoreBoard.fxmRate);
    
    //if(LOGS_ON) NSLog(@"fxmRate = %f * %f + %f * %f = %f",_scoreBoard.stScore, stScorePercentage, _scoreBoard.dmMPMScore, mpmScorePercentage, _scoreBoard.fxmRate);
    //_scoreBoard.formulaString = [NSString stringWithFormat:@"%@\n\nFitterX Rate = (%f * %f + %f * %f) / 100 = %f", //_scoreBoard.formulaString,_scoreBoard.stScore, stScorePercentage, _scoreBoard.dmMPMScore, mpmScorePercentage, _scoreBoard.fxmRate];
    _END;
}

#pragma mark-
//************************** code not used **************************//
/**
 * This function will return sub list from array,
 * sub array will contain elements from certain range
 */
- (NSArray *) getListFromArray:(NSArray *)list fromLowerRange:(CGFloat)lowerRange toUpparRange:(CGFloat)upparRange{
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF BETWEEN %@", @[[NSNumber numberWithFloat:lowerRange], [NSNumber numberWithFloat:upparRange]]];
    NSArray *results = [list filteredArrayUsingPredicate:predicate];
    return results;
}
//******************************************************************//

#pragma mark- Location methods
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    _START;
    //if(LOGS_ON) NSLog(@"points array is = %@", locations);
    _lastLocation = locations.lastObject;
    _END;
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    
    _START;
    [UniversalTaskExecuter showAlertWithTitle:@"GPS Problem"
                                   andMessage:[NSString stringWithFormat:@"GPS error occure : %@",error.localizedDescription]
                              withButtonTitle:@"OK"];
    _END;
}
@end