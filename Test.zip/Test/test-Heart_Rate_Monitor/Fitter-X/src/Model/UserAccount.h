//
//  UserAccount.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, MonthNumber)
{    
    MonthNumberJanuary = 1,
    MonthNumberFebruary,
    MonthNumberMarch,
    MonthNumberApril,
    MonthNumberMay,
    MonthNumberJune,
    MonthNumberJuly,
    MonthNumberAugust,
    MonthNumberSeptember,
    MonthNumberOctober,
    MonthNumberNovember,
    MonthNumberDecember
};

@interface Height : NSObject{
    
    NSInteger _feet;
    NSInteger _inche;
}
@property(nonatomic, assign) NSInteger feet;
@property(nonatomic, assign) NSInteger inches;
@end

@interface DateOfBirth : NSObject{
    
    NSInteger   _day;
    MonthNumber _monthNumber;
    NSInteger   _year;
}
@property(nonatomic, assign) MonthNumber monthNumber;
@property(nonatomic, assign) NSInteger   day;
@property(nonatomic, assign) NSInteger   year;
@end

@interface UserAccount : NSObject{

    Gender      _gender;
    DateOfBirth *_dob;
    Height      *_height;
    CGFloat     _weight;
}

@property(nonatomic, assign) Gender      gender;
@property(nonatomic, strong) DateOfBirth *dob;
@property(nonatomic, strong) Height      *height;
@property(nonatomic, assign) CGFloat     weight;

@end
