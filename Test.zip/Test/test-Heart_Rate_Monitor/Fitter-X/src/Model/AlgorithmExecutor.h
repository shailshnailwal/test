//
//  AlgorithmExecutor.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "FitterScoreBoard.h"
#import "User.h"

#define RangeTypeActiveRecovery     @"RangeTypeActiveRecovery"
#define RangeTypeExtensiveEndurance @"RangeTypeExtensiveEndurance"
#define RangeTypeIntensiveEndurance @"RangeTypeIntensiveEndurance"
#define RangeTypeSubThreshold       @"RangeTypeSubThreshold"
#define RangeTypeSuperThreshold     @"RangeTypeSuperThreshold"
#define RangeTypeAnaerobicEndurance @"RangeTypeAnaerobicEndurance"
#define RangeTypePower              @"RangeTypePower"

#define KeyActiveRecovery     @"Active Recovery"
#define KeyExtensiveEndurance @"Extensive Endurance"
#define KeyIntensiveEndurance @"Intensive Endurance"
#define KeySubThreshold       @"Sub Threshold"
#define KeySuperThreshold     @"Super Threshold"
#define KeyAnaerobicEndurance @"Anaerobic Endurance"
#define KeyPower              @"Power"

@interface AlgorithmExecutor : NSObject<CLLocationManagerDelegate>{
    
    FitterScoreBoard    *_scoreBoard;
    NSMutableArray      *_mpmList;
    NSMutableArray      *_caehrList;
    CLLocationManager   *_locationManager;
    CLLocation          *_lastLocation;
    NSTimer             *_timer;
    NSMutableArray      *_cumulativeDistanceList;
    NSMutableArray      *_cumulativeSpeedList;
    NSDate              *_startExcerciseTime;
    NSDate              *_endExcerciseTime;
    NSMutableDictionary *_stRangeFrequency;
    NSDictionary        *_inputInfo;
    
    //// input values for execute algorithm ////
    CGFloat  _distance;
    CGFloat  _showSpeed;
    CGFloat  _showAvgSpeed;
    CGFloat  _age;
    NSString *_gender;
    CGFloat  _rhr;
    CGFloat  _recoveryHR;
    CGFloat  _hr;
    CGFloat  _ehr;
    User     *_user;
    
    CGFloat  _rr;
    CGFloat  _bfp;
    
    CGFloat _maxFitterXScore;
    CGFloat _minFitterXScore;
    CGFloat _lastRHRValue;
    
    CGFloat _maxSpeed;
    CGFloat _maxHeartRate;
}

@property(nonatomic, strong) FitterScoreBoard *scoreBoard;
@property(nonatomic, strong) NSDictionary     *inputInfo;
@property(nonatomic, strong) User             *user;

@property(nonatomic, strong) NSDate   *startExcerciseTime;
@property(nonatomic, assign) CGFloat  distance;
@property(nonatomic, assign) CGFloat  showSpeed;
@property(nonatomic, assign) CGFloat  showAvgSpeed;
@property(nonatomic, assign) CGFloat  age;
@property(nonatomic, strong) NSString *gender;
@property(nonatomic, assign) CGFloat  rr;
@property(nonatomic, assign) CGFloat  hr;
@property(nonatomic, assign) CGFloat  rhr;
@property(nonatomic, assign) CGFloat  ehr;
@property(nonatomic, assign) CGFloat  recoveryHR;

@property(nonatomic, assign) CGFloat maxFitterXScore;
@property(nonatomic, assign) CGFloat minFitterXScore;
@property(nonatomic, assign) CGFloat lastRHRValue;

//// this functin will start the distance counting per minute ////
//-(void) activateExecuter;

//// this function will stop every second cumulative distance list creation ////
//-(void) deactivateExecuter;

//// this function will execute algorithm ////
-(void) executeAlgorithmWithLastRecoveryRate:(BOOL)userLastValue;

//// this function will calculate Master Calculation or Fitter X Score ////
//-(void) calculateFitterXScoreForForFormulaInfoList:(NSArray *)infoList;
@end
