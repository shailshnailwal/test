//
//  UserOperation.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 02/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"

@protocol UserOperationDelegate <NSObject>

    @optional
        -(void)userInfoAfterLoginCompletionSuccessfully: (User *)user;
        -(void)userLoginFail;
        -(void)userInfoAfterRegistrationCompletionSuccessfully: (User *)user
                                      withRegistrationResponse:(NSString *)responseString;
        -(void)userRegistrationFail;
-(void)passwordRecoverySuccessfullForUserEmail:(NSString *)email;
-(void)passwordRecoveryFailedForUserEmail:(NSString *)email;
@end

@interface UserOperation : NSObject{
    
    User *_user;
//    ASIFormDataRequest *request;
    id<UserOperationDelegate> _delegate;
}

@property(nonatomic, strong) id<UserOperationDelegate> delegate;

-(void) gerUserData;

//// for login process ////
-(void) loginUserWithUsername:(NSString *)username andPassword:(NSString *)password;

//// User registration ////
-(void)registerUserWithUserInfo:(NSDictionary *) userInfo;

//// recover password ////
-(void) sendPasswordToUserEmail:(NSString *)email;
@end
