//
//  FitterScoreBoard.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>

#define RESTING_HEART_RATE          @"rhr"
#define RESTING_HEART_RATE_SCORE    @"rhr_score"
#define RECOVERY_RATE               @"rr"
#define RECOVERY_RATE_SCORE         @"rr_score"
#define BMI                         @"bmi"
#define BODY_FAT_PERCENTAGE         @"body_fat_percentage"
#define BODY_FAT_SCORE              @"body_fat_score"
#define AVG_EXERCISE_HEART_RATE     @"avg_exercise_hr"
#define SUSTAINABLE_THRESHOLD_SCORE @"st_score"
#define AVG_METER_PER_MINUTES       @"avg_mpm"
#define METER_PER_MINUTES_SCORE     @"mpm_score"
#define FITTER_X_SCORE              @"fitter_x_score"

@interface FitterScoreBoard : NSObject{
    
    CGFloat _bmi;
    CGFloat _bfp;
    CGFloat _bfs;
    CGFloat _stScore;
    
    //// for fitter x metrics ////
    CGFloat _fxmScore;
    CGFloat _fxmRate;
    CGFloat _fxmMin;
    CGFloat _fxmMax;
    
    //// for heart rate metrix ////
    CGFloat _hrmValue;
    CGFloat _hrmAvg;
    CGFloat _hrmMax;
    CGFloat _hrmRestingRate;
    CGFloat _hrmLastRestingRate;
    CGFloat _hrmRestingRateScore;
    CGFloat _hrmChangeRate;
    CGFloat _hrmRecoveryRate;
    CGFloat _hrmRecoveryRateScore;
    CGFloat _hrmEHR;
    CGFloat _hrmRecoveryHR;
    CGFloat _hrmAvgExerciseHR;
    CGFloat _hrmLastRHR;
    
    //// for distance metrics ////
    CGFloat _dmSpeed;
    CGFloat _dmAvgSpeed;
    CGFloat _dmMaxSpeed;
    CGFloat _dmDistance;
    CGFloat _dmMPMScore;
    CGFloat _dmLastDistance;
    CGFloat _dmCurrentSpeed;
    CGFloat _dmCurrentAvgSpeed;
    
    //// for calorise / threshold metrics ////
    CGFloat _ctmCalBurned;
    CGFloat _ctmBurnRate;
    CGFloat _ctmAnaerobic;
    CGFloat _ctmAeraobic;
    
    NSMutableDictionary *_scoreInfo;
    NSString *_formulaString;
}

@property(nonatomic, assign) CGFloat bmi;
@property(nonatomic, assign) CGFloat bfp;
@property(nonatomic, assign) CGFloat bfs;
@property(nonatomic, assign) CGFloat stScore;

//// for fitter x metrics ////
@property(nonatomic, assign) CGFloat fxmScore;
@property(nonatomic, assign) CGFloat fxmRate;
@property(nonatomic, assign) CGFloat fxmMin;
@property(nonatomic, assign) CGFloat fxmMax;

//// for heart rate metrix ////
@property(nonatomic, assign) CGFloat hrmValue;
@property(nonatomic, assign) CGFloat hrmAvg;
@property(nonatomic, assign) CGFloat hrmMax;
@property(nonatomic, assign) CGFloat hrmRestingRate;
@property(nonatomic, assign) CGFloat hrmLastRestingRate;
@property(nonatomic, assign) CGFloat hrmRestingRateScore;
@property(nonatomic, assign) CGFloat hrmChangeRate;
@property(nonatomic, assign) CGFloat hrmRecoveryRate;
@property(nonatomic, assign) CGFloat hrmRecoveryRateScore;
@property(nonatomic, assign) CGFloat hrmEHR;
@property(nonatomic, assign) CGFloat hrmRecoveryHR;
@property(nonatomic, assign) CGFloat hrmAvgExerciseHR;
@property(nonatomic, assign) CGFloat hrmLastRHR;

//// for distance metrics ////
@property(nonatomic, assign) CGFloat dmSpeed;
@property(nonatomic, assign) CGFloat dmAvgSpeed;
@property(nonatomic, assign) CGFloat dmMaxSpeed;
@property(nonatomic, assign) CGFloat dmDistance;
@property(nonatomic, assign) CGFloat dmMPMScore;
@property(nonatomic, assign) CGFloat dmLastDistance;
@property(nonatomic, assign) CGFloat dmCurrentSpeed;
@property(nonatomic, assign) CGFloat dmCurrentAvgSpeed;

//// for calorise / threshold metrics ////
@property(nonatomic, assign) CGFloat ctmCalBurned;
@property(nonatomic, assign) CGFloat ctmBurnRate;
@property(nonatomic, assign) CGFloat ctmAnaerobic;
@property(nonatomic, assign) CGFloat ctmAeraobic;

//// set score info ////
@property(nonatomic, strong) NSMutableDictionary *scoreInfo;

@property(nonatomic, strong) NSString *formulaString;

@end