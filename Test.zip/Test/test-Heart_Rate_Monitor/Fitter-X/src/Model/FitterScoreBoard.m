//
//  FitterScoreBoard.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "FitterScoreBoard.h"

@implementation FitterScoreBoard

//@synthesize rhr                    = _rhr;
//@synthesize rhrScore               = _rhrScore;
//@synthesize rr                     = _rr;
//@synthesize rrScore                = _rrScore;
//@synthesize recoveryRH             = _recoveryRH;
@synthesize bmi                    = _bmi;
@synthesize bfp                    = _bfp;
@synthesize bfs                    = _bfs;
//@synthesize avgExercisingHeartRate = _avgExercisingHeartRate;
@synthesize stScore                     = _stScore;
//@synthesize avgMPM                 = _avgMPM;
//@synthesize mpmScore               = _mpmScore;
//@synthesize fitterXScore           = _fitterXScore;
//@synthesize heartRate              = _heartRate;
//@synthesize distance               = _distance;

//// for fitter x metrics ////
@synthesize fxmScore = _fxmScore;
@synthesize fxmRate  = _fxmRate;
@synthesize fxmMin   = _fxmMin;
@synthesize fxmMax   = _fxmMax;

//// for heart rate metrix ////
@synthesize hrmValue            = _hrmValue;
@synthesize hrmAvg              = _hrmAvg;
@synthesize hrmMax              = _hrmMax;
@synthesize hrmRestingRate      = _hrmRestingRate;
@synthesize hrmLastRestingRate  = _hrmLastRestingRate;
@synthesize hrmRestingRateScore = _hrmRestingRateScore;
@synthesize hrmChangeRate       = _hrmChangeRate;
@synthesize hrmRecoveryRate     = _hrmRecoveryRate;
@synthesize hrmRecoveryRateScore= _hrmRecoveryRateScore;
@synthesize hrmEHR              = _hrmEHR;
@synthesize hrmRecoveryHR       = _hrmRecoveryHR;
@synthesize hrmAvgExerciseHR    = _hrmAvgExerciseHR;
@synthesize hrmLastRHR          = _hrmLastRHR;

//// for distance metrics ////
@synthesize dmSpeed           = _dmSpeed;
@synthesize dmAvgSpeed        = _dmAvgSpeed;
@synthesize dmMaxSpeed        = _dmMaxSpeed;
@synthesize dmDistance        = _dmDistance;
@synthesize dmMPMScore        = _dmMPMScore;
@synthesize dmLastDistance    = _dmLastDistance;
@synthesize dmCurrentSpeed    = _dmCurrentSpeed;
@synthesize dmCurrentAvgSpeed = _dmCurrentAvgSpeed;

//// for calorise / threshold metrics ////
@synthesize ctmCalBurned = _ctmCalBurned;
@synthesize ctmBurnRate  = _ctmBurnRate;
@synthesize ctmAnaerobic = _ctmAnaerobic;
@synthesize ctmAeraobic  = _ctmAeraobic;

//// score info ////
@synthesize scoreInfo = _scoreInfo;

@synthesize formulaString = _formulaString;

- (id)init
{
    self = [super init];
    if (self) {
        _formulaString = @"";
    }
    return self;
}

-(void) makeScoreInfoObject{
    
    if (!_scoreInfo) {
        
        _scoreInfo = [[NSMutableDictionary alloc] init];
    }
}

-(void)setFxmScore:(CGFloat)fxmScore{
    
    _fxmScore = fxmScore;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:fxmScore] forKey:FITTER_X_SCORE];
    
}

-(void) setHrmRestingRate:(CGFloat)hrmRestingRate{
    
    _hrmRestingRate = hrmRestingRate;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:hrmRestingRate] forKey:RESTING_HEART_RATE];
}

-(void) setHrmRestingRateScore:(CGFloat)hrmRestingRateScore{
    
    _hrmRestingRateScore = hrmRestingRateScore;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:hrmRestingRateScore] forKey:RESTING_HEART_RATE_SCORE];
}

-(void) setHrmRecoveryRate:(CGFloat)hrmRecoveryRate{
    
    _hrmRecoveryRate = hrmRecoveryRate;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:hrmRecoveryRate] forKey:RECOVERY_RATE];
}

-(void) setHrmRecoveryRateScore:(CGFloat)hrmRecoveryRateScore{
    
    _hrmRecoveryRateScore = hrmRecoveryRateScore;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:hrmRecoveryRateScore] forKey:RECOVERY_RATE_SCORE];
    
}

-(void) setBmi:(CGFloat)bmi{
    
    _bmi = bmi;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:bmi] forKey:BMI];
}

-(void) setBfs:(CGFloat)bfs{
    
    _bfs = bfs;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:bfs] forKey:BODY_FAT_SCORE];
}

-(void) setBfp:(CGFloat)bfp{
    
    _bfp = bfp;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:bfp] forKey:BODY_FAT_PERCENTAGE];
}

-(void) setHrmAvgExerciseHR:(CGFloat)hrmAvgExerciseHR{
    
    _hrmAvgExerciseHR = hrmAvgExerciseHR;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:hrmAvgExerciseHR] forKey:AVG_EXERCISE_HEART_RATE];
    
}

-(void) setStScore:(CGFloat)stScore{
    
    _stScore = stScore;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:stScore] forKey:SUSTAINABLE_THRESHOLD_SCORE];
}

-(void) setDmAvgSpeed:(CGFloat)dmAvgSpeed{
    
    _dmAvgSpeed = dmAvgSpeed;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:dmAvgSpeed] forKey:AVG_METER_PER_MINUTES];
    
}

-(void) setDmMPMScore:(CGFloat)dmMPMScore{
    
    _dmMPMScore = dmMPMScore;
    [self makeScoreInfoObject];
    [_scoreInfo setValue:[NSNumber numberWithFloat:dmMPMScore] forKey:METER_PER_MINUTES_SCORE];
}
@end
