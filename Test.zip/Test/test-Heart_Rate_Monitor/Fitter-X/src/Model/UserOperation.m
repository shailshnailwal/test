//
//  UserOperation.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 02/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "UserOperation.h"
#import <CFNetwork/CFNetwork.h>

@implementation UserOperation

@synthesize delegate = _delegate;

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

-(User *) userWithServerResponse:(ASIHTTPRequest *)response{
    
    _START;
    NSArray      *serverResponse = nil;
    NSDictionary *responseInfo       = nil;
    User *user = nil;// = [[User alloc] init];
    if(SERVER_LOGS_ON) NSLog(@"server response = %@", response.responseString);
    if (response && ![response isKindOfClass:[NSNull class]] && response.responseData) {
        
        responseInfo = [NSJSONSerialization JSONObjectWithData:response.responseData
                                                       options:NSJSONReadingMutableContainers
                                                         error:nil];
        if(SERVER_LOGS_ON) NSLog(@"response info = %@", responseInfo);
        
        if (responseInfo && [responseInfo isKindOfClass:[NSDictionary class]]) {
            
            serverResponse = [responseInfo objectForKey:SERVER_USER_INFO_KEY];
        }
        else{
            
            responseInfo = nil;
        }
        
        if (serverResponse && [serverResponse isKindOfClass:[NSArray class]] && serverResponse.count > 0) {
            
            responseInfo = [serverResponse objectAtIndex:0];
        }
    }
    
    if (responseInfo &&
        ![responseInfo isKindOfClass:[NSNull class]] &&
        [responseInfo objectForKey:USER_USER_ID] &&
        ![[responseInfo objectForKey:USER_USER_ID] isEqualToString:@""]) {
        
        //if(LOGS_ON) NSLog(@"response = %@", response.responseString);
        //// create user from dictionary ////
        if (responseInfo) {
            
            user          = [[User alloc] init];
            user.userInfo = responseInfo;
        }
        
    }
    _END;
    return user;
}

-(void)gerUserData{
    
    _START;
    NSURL *hostUrl = [NSURL URLWithString:APPLICATION_URL];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:hostUrl];
    request.delegate = self;
    [request setDidFinishSelector:@selector(userDataProcessFinished:)];
    [request setDidFailSelector:@selector(userDataProcessFailed:)];
    [request startSynchronous];
    _END;
}


-(void)userDataProcessFinished:(ASIHTTPRequest *)response{
    
    //if(LOGS_ON) NSLog(@"server worked = %@", response.responseString);
}

-(void) userDataProcessFailed:(ASIHTTPRequest *)response{
    
    //if(LOGS_ON) NSLog(@"server not worked = %@", response.responseString);
}

/**
 * user login operation
 */
-(void) loginUserWithUsername:(NSString *)username andPassword:(NSString *)password{
    
    _START;
    NSURL *serverUrl = [NSURL URLWithString:APPLICATION_URL];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:serverUrl];
    request.delegate = self;
    [request setDidFinishSelector:@selector(loginProcessFinished:)];
    [request setDidFailSelector:@selector(loginProcessFail:)];
    [request setPostValue:LOGIN    forKey:REQUEST_KEY];
    [request setPostValue:username forKey:USERNAME_KEY];
    [request setPostValue:password forKey:PASSWORD_KEY];
    [request startAsynchronous];
    _END;
}

-(void) loginProcessFinished:(ASIHTTPRequest *)request{
    
    _START;
    //if(LOGS_ON) NSLog(@"response on finish = %@ --- %@", request, request.responseString);
    
    User *user = [self userWithServerResponse:request];
    //// send user information ////
    if ([_delegate respondsToSelector:@selector(userInfoAfterLoginCompletionSuccessfully:)]) {
        
        [_delegate userInfoAfterLoginCompletionSuccessfully:user];
    }
    //if(LOGS_ON) NSLog(@"response info = %@",request.responseString);
    _END;
}

-(void) loginProcessFail:(ASIHTTPRequest *)request{
    
    _START;
    //if(LOGS_ON) NSLog(@"response on fail = %@ --- %@", request, request.responseString);
    if ([_delegate respondsToSelector:@selector(userLoginFail)]) {
        
        //if(LOGS_ON) NSLog(@"delegate found");
        [_delegate userLoginFail];
    }
    _END;
}

/**
 * User registration
 */
-(void)registerUserWithUserInfo:(NSDictionary *) userInfo{
    
    _START;
    //if(LOGS_ON) NSLog(@"to register user = %@", userInfo);
    NSData *userJSON = [NSJSONSerialization dataWithJSONObject:userInfo
                                                         options:NSJSONWritingPrettyPrinted
                                                           error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:userJSON encoding:NSUTF8StringEncoding];
    NSURL *hostUrl = [NSURL URLWithString:APPLICATION_URL];
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc] initWithURL:hostUrl];
    request.delegate = self;
    [request setDidFinishSelector:@selector(userRegistrationProcessFinished:)];
    [request setDidFailSelector:@selector(userRegistrationProcessFailed:)];
    [request setPostValue:REGISTRATION forKey:REQUEST_KEY];
    [request setPostValue:jsonString   forKey:SERVER_USER_INFO_KEY];
    [request startAsynchronous];
}

-(void)userRegistrationProcessFinished:(ASIHTTPRequest *)response{
    
    _START;
    User *user = [self userWithServerResponse:response];
    NSString *responseString = nil;
    if(SERVER_LOGS_ON) NSLog(@"server worked for registration = %@", response.responseString);
    if ([_delegate respondsToSelector:@selector(userInfoAfterRegistrationCompletionSuccessfully:withRegistrationResponse:)]) {
        
        responseString = user == nil ? response.responseString : nil;
        
        [_delegate userInfoAfterRegistrationCompletionSuccessfully:user
                                          withRegistrationResponse:responseString];
    }
}

-(void) userRegistrationProcessFailed:(ASIHTTPRequest *)response{
    
    if(SERVER_LOGS_ON) NSLog(@"server not worked for registration = %@", response.responseString);
    if ([_delegate respondsToSelector:@selector(userRegistrationFail)]) {
        
        [_delegate userRegistrationFail];
    }
}

-(void) sendPasswordToUserEmail:(NSString *)email{
    
    //if(LOGS_ON) NSLog(@"sending password request");
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setValue:@"PASSWORD_RECOVER" forKey:@"OPERATION"];
    [dic setValue:email forKey:@"email"];
    AFHTTPClient *client = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:APPLICATION_LOCATION]];
    NSMutableURLRequest *request = [client multipartFormRequestWithMethod:@"POST"
                                                                     path:APPLICATION_INDEX
                                                               parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {}];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [client registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSString *responseString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        //if(LOGS_ON) NSLog(@"password shoud be sent = %@", _delegate);
        if (_delegate && [_delegate respondsToSelector:@selector(passwordRecoverySuccessfullForUserEmail:)]) {
            
            [_delegate passwordRecoverySuccessfullForUserEmail:email];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        if (_delegate && [_delegate respondsToSelector:@selector(passwordRecoveryFailedForUserEmail:)]) {
            
            [_delegate passwordRecoveryFailedForUserEmail:email];
        }
    }];
    [operation start];
}
@end
