//
//  DeviceDataFatch.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "AlgorithmExecutor.h"
#import "HeartRateData.h"

@protocol AlgorithmExecutorDelegate <NSObject>
    @optional
        -(void) algorithmExecutionIntermediateResultFound:(FitterScoreBoard *)resultInfo;
        -(void) algorithmExecutionEndedWithResultFound:(FitterScoreBoard *)resultInfo;
        -(void) algorithmExecutionFoundInputInfo:(NSDictionary *)inputInfo;
        -(void) algorithmExecutionFailToFindInputInfo;
        -(void) algorithmExecutionConnectionFail;
        -(void) algorithmExecutionConnectionEstablished;
@end

@interface DeviceOperation : NSObject<CLLocationManagerDelegate, DeviceProtocol>{
    
    @private
    AlgorithmExecutor *_algoExecuter;
    User              *_user;
    
    NSMutableArray    *_mpmList;
    CLLocationManager *_locationManager;
    CLLocation        *_currentLocation;
    CLLocation        *_lastLocation;
    CLLocation        *_newLocationFound;
    CGFloat           _currentHeartRate;
    
    NSMutableArray    *_cumulativeDistanceList;
//    NSMutableArray    *_heartRateList;
    NSMutableArray    *_cumulativeHeartRateList;
    NSTimer           *_heartRateTimer;
    NSTimer           *_distanceTimer;
    NSTimer           *_algoExecuationTimer;
    NSTimer           *_uiTimer;
    NSDate            *_startTime;
    NSDate            *_endTime;

    NSDictionary *_inputValues;
    id<AlgorithmExecutorDelegate> _delegate;
    
    HeartRateData *_heartRateOperator;
    
    BOOL _restingHRCalculated;
}

@property(nonatomic, strong) NSMutableArray *locationHistory;
@property(nonatomic, assign) NSTimeInterval lastDistanceCalculation;
@property(nonatomic, assign) CLLocation *lastRecordedLocation;
@property(nonatomic, assign) NSDate *startTimestamp;
@property(nonatomic, assign) CGFloat totalDistance;

@property(assign, nonatomic) CGFloat currentHeartRate;

@property(nonatomic, strong) id<AlgorithmExecutorDelegate> delegate;
@property(nonatomic, strong) NSDictionary *inputValues;
@property(nonatomic, strong) User *user;

///// this function will change UI ////
-(void) changeUI;

//// this function will initiate GPS and Heart Rate Data Fetch ////
-(void) startInitialDataFetch;

//// this function will start data fetch from GPS and Heart Rate Monitor frequently ////
-(void) startFrequentDeviceDataFetch;

//// this function will start data fetch from GPS and Heart Rate Monitor frequently ////
-(void) stopFrequentDeviceDataFetch;

//// this function will send request to server to get input values for algotithm ////
-(void) getInputValuesFromServerForUserInfo:(NSDictionary *)userInfo;

//// this function will set heart rate at the end of the excercise ////
-(void) setEndingHeartRate;

//// this function will set resting heart rate ////
-(void) setRestingHeartRate;

//// this function will get recovery heart rate after one minute of stopping workout ////
-(void) getRecoveryHeartRate;

//// this function will set recovery heart rate ///
-(void) setRecoveryHeartRate;

/********************************************/
-(void) connectToHardware;
@end

