//
//  DeviceDataFatch.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "DeviceOperation.h"

//#import <WFConnector/WFConnector.h>

#define kDistanceCalculationInterval 10 // the interval (seconds) at which we calculate the user's distance
#define kNumLocationHistoriesToKeep  5  // the number of locations to store in history so that we can look back at them and determine which is most accurate
#define kValidLocationHistoryDeltaInterval  3 // the maximum valid age in seconds of a location stored in the location history
#define kMinLocationsNeededToUpdateDistance 3 // the number of locations needed in history before we will even update the current distance
#define kRequiredHorizontalAccuracy         40.0f

@implementation DeviceOperation

@synthesize delegate    = _delegate;
@synthesize inputValues = _inputValues;
@synthesize user        = _user;
@synthesize currentHeartRate = _currentHeartRate;

@synthesize locationHistory = _locationHistory;

- (id)init
{
    self = [super init];
    if (self) {
        
        _algoExecuter = [[AlgorithmExecutor alloc] init];
        _inputValues  = [[NSMutableDictionary alloc] init];
        _heartRateOperator = [[HeartRateData alloc] init];
        _locationHistory = [[NSMutableArray alloc] initWithCapacity:kNumLocationHistoriesToKeep];
    }
    return self;
}

/**
 * set user for execuation
 */
-(void) setUser:(User *)user{
    
    _user = user;
    if (!_algoExecuter) {
        
        _algoExecuter      = [[AlgorithmExecutor alloc] init];
    }
    _algoExecuter.user = _user;
}

-(void)setInputValues:(NSDictionary *)inputValues{
    
    _inputValues = inputValues;
    _algoExecuter.inputInfo = inputValues;
}


/**
 * this function will start data fetch from GPS and Heart Rate Monitor frequently
 */
-(void) startFrequentDeviceDataFetch{
    
    _START;
//    _startTime = [NSDate date];
    //[self startGPSDataFetch];
    
    _distanceTimer = [NSTimer scheduledTimerWithTimeInterval:TIME_FOR_DISTANCE_CALCULATION
                                                      target:self
                                                    selector:@selector(getDistanceData)
                                                    userInfo:nil
                                                     repeats:YES];
    
//    [self startHeartRateDeviceDataFetch];
//    _heartRateTimer = [NSTimer scheduledTimerWithTimeInterval:TIME_FOR_HEART_RATE_CALCULATION
//                                                       target:self
//                                                     selector:@selector(getHeartRateData)
//                                                     userInfo:nil
//                                                      repeats:YES];
    
    _algoExecuationTimer = [NSTimer scheduledTimerWithTimeInterval:TIME_FOR_ALGO_EXECUATION
                                                            target:self
                                                          selector:@selector(startAlgorithmExecuation)
                                                          userInfo:nil
                                                           repeats:YES];
    
    _uiTimer        = [NSTimer scheduledTimerWithTimeInterval:TIME_FOR_UI_CHANGE
                                                       target:self
                                                     selector:@selector(changeUI)
                                                     userInfo:nil
                                                      repeats:YES];
    _END;
}

/**
 * this function will request algorithm execuator to execute algorithm for given values
 */
-(void) startAlgorithmExecuation{
    
    _START;
    [_algoExecuter executeAlgorithmWithLastRecoveryRate:YES];
    _END;
}

/**
 * this function will stop data fetching
 */
-(void) stopFrequentDeviceDataFetch{
    
    _START;
//    _endTime = [NSDate date];
    if (_distanceTimer && [_distanceTimer isValid]) {
        
        [_distanceTimer invalidate];
        _distanceTimer = nil;
    }
    
    if (_algoExecuationTimer && [_algoExecuationTimer isValid]) {
        
        [_algoExecuationTimer invalidate];
        _algoExecuationTimer = nil;
    }
    
    if (_heartRateTimer && [_heartRateTimer isValid]) {
        
        [_heartRateTimer invalidate];
        _heartRateTimer = nil;
    }
    
    _locationManager.delegate = nil;
    
    //// set ending heart rate for algo execuation ////
    _algoExecuter.ehr = _currentHeartRate;
    
    //// this time algotithm will execute with actual resting heart rate value ////
    [self startAlgorithmExecuation];
    
    //// to stop distance calculation until resting heart rate calculated ////
    _restingHRCalculated = NO;
    _END;
}

/**
 * this function will set heart rate at the end of the excercise
 */
-(void) setEndingHeartRate{
    
    _START;//// to remove two players ////
//    NSDateComponents *dateComponent = [UniversalTaskExecuter dateComponentsWithDate:[NSDate date]];
//    //// removing player if players are greater than 3 in numbers ////
//    NSInteger removingIndex = dateComponent.second % 90 + 80;
//    _algoExecuter.ehr = removingIndex;
    
    _algoExecuter.ehr = _currentHeartRate;
    _END;
}

/**
 * this function will set resting heart rate
 */
-(void) setRestingHeartRate{
    
    _START;
    //// to remove two players ////
//    NSDateComponents *dateComponent = [UniversalTaskExecuter dateComponentsWithDate:[NSDate date]];
//    //// removing player if players are greater than 3 in numbers ////
//    NSInteger removingIndex = dateComponent.second % 90 + 80;
//    _algoExecuter.rhr = removingIndex;
    
    _algoExecuter.rhr = _currentHeartRate;
    _restingHRCalculated = YES;
    _END;
}

/**
 * this function will do the following
 * -- set recovery heart rate
 * -- execute algorithm for last time with current recovery rate
 */
-(void) setRecoveryHeartRate{
    
    _START;
    //// to remove two players ////
//    NSDateComponents *dateComponent = [UniversalTaskExecuter dateComponentsWithDate:[NSDate date]];
//    //// removing player if players are greater than 3 in numbers ////
//    NSInteger removingIndex = dateComponent.second % 90 + 80;
//    _algoExecuter.recoveryHR = removingIndex;
    
    _algoExecuter.recoveryHR = _currentHeartRate;
    
    //// stop heart rate monitor data fetch ////
    [_heartRateOperator removeObservers];
    
    //// last time execute algorithm with current recovery rate ////
    [_algoExecuter executeAlgorithmWithLastRecoveryRate:NO];
    
    //// UI timer should be stoped after the final result appears on screen ////
    if (_uiTimer && [_uiTimer isValid]) {
        
        [_uiTimer invalidate];
        _uiTimer = nil;
    }
    
    //// stop close the connection ////
    //// startConnection do the both, starting connection and stoping connection ////
    [_heartRateOperator startConnection];
    
    //// chage ui for the last time ////
    [self changeUI];
    
    //// at this point, we will have the actual report of the user ////
    //// sending report to server to be saved ////
    [self sendReportsToServer];
    _END;
}

/**
 * this function will initiate GPS and Heart Rate Data Fetch when start work out pressed
 */
-(void) startInitialDataFetch{
    
    _START;
    _algoExecuter.startExcerciseTime = [NSDate date];
    [self startGPSDataFetch];
//    NSLog(@"startHeartRateDeviceDataFetch from startInitialDataFetch");
    
    //// praper heart rate operator to start start heart rate data fetch ////
    _heartRateOperator.delegate = self;
    [_heartRateOperator setDefaults];
    
    //// start heart rate fetching from heart rate monitor ////
    [self startHeartRateDeviceDataFetch];
    _END;
}


/**
 * this function will praper device to start sending data
 */
-(void) startHeartRateDeviceDataFetch{
    
    _START;
//    NSLog(@"TO startConnection from startHeartRateDeviceDataFetch");
    [_heartRateOperator startConnection];
    _END;
}

/**
 * this function show only be called when testing with random data, otherwise not
 */
-(void) getHeartRateData{
    
    _START;
    CGFloat heartRate = rand()%90  + 80;
    NSDateComponents *dateComponent = [UniversalTaskExecuter dateComponentsWithDate:[NSDate date]];
    //// removing player if players are greater than 3 in numbers ////
    NSInteger removingIndex = dateComponent.second % 90 + 80;
    heartRate = removingIndex;
    
    _algoExecuter.hr  = heartRate;
    _currentHeartRate = heartRate;

    _END;
}

#pragma mark- Device data method
-(void)deviceStringFroHeartRate:(NSString *)hrString{
    
    _START;
    if (hrString && ![hrString isEqualToString:EMPTY_STRING]) {
        
        _currentHeartRate = hrString.floatValue;
        _algoExecuter.hr  = _currentHeartRate;
    }
    _END;
}

-(void)deviceConnectionInitiated{
    
    _START;
    _END;
}

-(void)deviceConnectionEstablished{
    
    _START;
    NSLog(@"deviceConnectionEstablished in device operation");
//    [UniversalTaskExecuter showAlertWithTitle:@"Test to connect" andMessage:@"Connected to device" withButtonTitle:@"OK"];
    if ([_delegate respondsToSelector:@selector(algorithmExecutionConnectionEstablished)]) {
        
//        [UniversalTaskExecuter showAlertWithTitle:@"Delegate test" andMessage:@"it respones" withButtonTitle:@"OK"];
        [_delegate algorithmExecutionConnectionEstablished];
    }
    _END;
}

-(void)deviceConnectionClosing{
    
    _START;
    _END;
}

-(void)deviceConnectionClosed{
    
    _START;
    _END;
}

-(void) deviceConnectionInterrupted{
    
    _START;
    _END;
}

#pragma mark- UI Change
/**
 * this function will send request to change UI for device values
 */
-(void) changeUI{
    
    _START;
    if ([_delegate respondsToSelector:@selector(algorithmExecutionIntermediateResultFound:)]) {
        
        [_delegate algorithmExecutionIntermediateResultFound:_algoExecuter.scoreBoard];
    }
    _END;
}

#pragma mark- Distance Methods
/**
 * this functin will request for GPS data
 */
-(void) startGPSDataFetch{
    
    _START;
    //if(LOGS_ON) NSLog(@"distance calculation started");
    
    if (!_cumulativeDistanceList) {
        
        _cumulativeDistanceList = [[NSMutableArray alloc] init];
    }
    
    if (_locationManager == nil) {
        
        _locationManager                 = [[CLLocationManager alloc] init];
        _locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
        _locationManager.distanceFilter  = kCLDistanceFilterNone;
    }
    
    _locationManager.delegate = self;
    [_locationManager startMonitoringSignificantLocationChanges];
    [_locationManager startUpdatingLocation];
    
    _currentLocation = _locationManager.location;
    _END;
}

/**
 * this function get data from GPS every defined time
 */
-(void) getDistanceData{
    
    _START;
    
    if (_restingHRCalculated) {
        
//        //if(LOGS_ON) NSLog(@"get distance started");
//        _algoExecuter.showSpeed = rand()%10 + 5;
//        _algoExecuter.showAvgSpeed = rand()%10 + 4;
//        _algoExecuter.distance  = rand()%3  + 20;
        

        CLLocationDistance distanceObj = 0;
        
        if (_lastLocation && _currentLocation) { //// set distance if user moves
            
            if (_currentLocation.speed > 0) {
                
                _algoExecuter.showSpeed = _currentLocation.speed;
                _startTime = [NSDate date];
            }
            else{
                
                _endTime = [NSDate date];
                
                if ([_endTime timeIntervalSinceDate:_startTime] > 3) {
                    
                    _algoExecuter.showSpeed = 0;
                }
                else{
                    
                    _algoExecuter.showSpeed = _currentLocation.speed;
                }
            }
        }
        else{
            
            _algoExecuter.showSpeed = 0;
        }
        
        
        if (_lastLocation && _currentLocation && _currentLocation != _lastLocation) { //// set distance if user moves
            
            distanceObj   = [_currentLocation distanceFromLocation:_lastLocation];
            _lastLocation = _currentLocation;
            _algoExecuter.distance = distanceObj;
        }
 

        
    }
    
    
    
    
    
    //    NSNumber  *lastCumulativeObj;
    //    CLLocation *location = _locationManager.location;
    
 
    
     
 
    
    
//    else{
//    
//        _algoExecuter.showSpeed = 0;
//    }
    
    
    //    double lastCumulativeDistance = 0.0;
    //    _endTime = [NSDate date];
    
    //******** replace it by comment - 1 **********//
    //    distanceObj = rand()%10  + 5;
    
    //    //if(LOGS_ON) NSLog(@"distance to send for execuation = %f", distanceObj);
    
    
    //    //if(LOGS_ON) NSLog(@"distance = %f", distanceObj);
    //
    //    _algoExecuter.scoreBoard.dmSpeed    = distanceObj / TIME_FOR_DISTANCE_CALCULATION;
    //
    //    //if(LOGS_ON) NSLog(@"speed =>> %f", _algoExecuter.scoreBoard.dmSpeed);
    //
    //    if (!_algoExecuter.scoreBoard) {
    //
    //        _algoExecuter.scoreBoard = [[FitterScoreBoard alloc] init];
    //    }
    //
    //    if (!_cumulativeDistanceList) {
    //
    //        _cumulativeDistanceList = [[NSMutableArray alloc] init];
    //    }
    //
    //    if (_cumulativeDistanceList.count == 0 && _lastLocation != nil){
    //
    //        _algoExecuter.scoreBoard.dmDistance = distanceObj;
    //        [_cumulativeDistanceList addObject:[NSNumber numberWithDouble:distanceObj]];
    //    }
    //    else if (_cumulativeDistanceList.count > 0 && _lastLocation != nil){
    //
    //        lastCumulativeObj       = [_cumulativeDistanceList objectAtIndex:(_cumulativeDistanceList.count - 1)];
    //        lastCumulativeDistance  = lastCumulativeObj.doubleValue;
    //        _algoExecuter.scoreBoard.dmDistance    = (distanceObj + lastCumulativeDistance);
    //        [_cumulativeDistanceList addObject:[NSNumber numberWithDouble:_algoExecuter.scoreBoard.dmDistance]];
    //    }
    //
    //// calculate average speed ////
    //    _algoExecuter.scoreBoard.dmAvgSpeed = [self averageSpeedFromDistance:_algoExecuter.scoreBoard.dmDistance
    //                                                        betweenStartTime:_startTime
    //                                                               toEndTime:_endTime];
    //    //if(LOGS_ON) NSLog(@"average speed ==>>> %f", _algoExecuter.scoreBoard.dmAvgSpeed);
    //    _algoExecuter.scoreBoard.dmAvgSpeed = 4.000;
    //    //if(LOGS_ON) NSLog(@"Cumulative List = %@", _cumulativeDistanceList);
    

    _END;
}

/**
 * this function will calculate average speed from total distance, start time and end time
 */
//-(CGFloat) averageSpeedFromDistance:(CGFloat)distance betweenStartTime:(NSDate *)startTime toEndTime:(NSDate *)endTime{
//
//    CGFloat averageSpeed = 0.0;
//    CGFloat time = 0.0;
//    if (startTime && endTime) {
//
//        time = [_endTime timeIntervalSinceDate:_startTime];
//        //if(LOGS_ON) NSLog(@"distance = %f , time = %f", distance, time);
//    }
//    
//    if (time != 0) {
//        
//        averageSpeed = distance / time;
//    }
//    return averageSpeed;
//}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    _START;
    //if(LOGS_ON) NSLog(@"points array is = %@", locations);
    _lastLocation    = _currentLocation;
    _currentLocation = locations.lastObject;
    _END;
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    
    _START;
    [UniversalTaskExecuter showAlertWithTitle:@"GPS Problem"
                                   andMessage:[NSString stringWithFormat:@"GPS error occure : %@",error.localizedDescription]
                              withButtonTitle:@"OK"];
    _END;
}

#pragma mark- WF methods
-(void)hardwareConnector:(WFHardwareConnector *)hwConnector connectedSensor:(WFSensorConnection *)connectionInfo{
    
//    [UniversalTaskExecuter showAlertWithTitle:@"Hardware connection info" andMessage:@"connectedSensor" withButtonTitle:@"OK"];
}

-(void)hardwareConnector:(WFHardwareConnector *)hwConnector didDiscoverDevices:(NSSet *)connectionParams searchCompleted:(BOOL)bCompleted{
    
//    [UniversalTaskExecuter showAlertWithTitle:@"Hardware connection info" andMessage:@"didDiscoverDevices" withButtonTitle:@"OK"];
}

-(void)hardwareConnector:(WFHardwareConnector *)hwConnector disconnectedSensor:(WFSensorConnection *)connectionInfo{
    
//    [UniversalTaskExecuter showAlertWithTitle:@"Hardware connection info" andMessage:@"disconnectedSensor" withButtonTitle:@"OK"];
}

-(void)hardwareConnector:(WFHardwareConnector *)hwConnector hasFirmwareUpdateAvailableForConnection:(WFSensorConnection *)connectionInfo required:(BOOL)required withWahooUtilityAppURL:(NSURL *)wahooUtilityAppURL{
    
//    [UniversalTaskExecuter showAlertWithTitle:@"Hardware connection info" andMessage:@"hasFirmwareUpdateAvailableForConnection" withButtonTitle:@"OK"];
}

-(void)hardwareConnector:(WFHardwareConnector *)hwConnector stateChanged:(WFHardwareConnectorState_t)currentState{
    
//    [UniversalTaskExecuter showAlertWithTitle:@"Hardware connection info" andMessage:@"stateChanged" withButtonTitle:@"OK"];
}

-(void)hardwareConnectorHasData{
    
//    [UniversalTaskExecuter showAlertWithTitle:@"Hardware connection info" andMessage:@"hardwareConnectorHasData" withButtonTitle:@"OK"];
}

#pragma mark- Server Operation
/**
 * this function will send request to server to get input values for algotithm
 */
-(void) getInputValuesFromServerForUserInfo:(NSDictionary *)userInfo{
    
    _START;
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
     NSString *age    = nil;
     NSString *gender = nil;
    NSString *userID = nil;
    NSDictionary *info = nil;
    
    
//    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//    info = [userDefaults objectForKey:USER_DEFAULTS_KEY];
//    _algoExecuter.inputInfo = info;
    
     //if(LOGS_ON) NSLog(@"user ifromation for fetching input values %@", userInfo);
     if (userInfo) {
     
         age    = [userInfo objectForKey:@"age"];
         gender = [userInfo objectForKey:@"gender"];
         userID = [userInfo objectForKey:@"user_id"];
     }
     
     //// setting insert values request ////
     [params setValue:@"ALL_INSERT_VALUES" forKey:@"OPERATION"];
     [params setValue:gender               forKey:@"gender"];
     [params setValue:age                  forKey:@"age"];
     [params setValue:userID               forKey:@"user_id"];
     
     //if(LOGS_ON) NSLog(@"sending request for input values = %@", params);
     
     
     AFHTTPClient *httpClient       = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:APPLICATION_LOCATION]];
     NSMutableURLRequest *afRequest = [httpClient multipartFormRequestWithMethod:@"POST"
     path:APPLICATION_INDEX
     parameters:params
     constructingBodyWithBlock:^(id <AFMultipartFormData>formData){}
     ];
     
     AFHTTPRequestOperation *_operation = [[AFHTTPRequestOperation alloc] initWithRequest:afRequest];
     [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
     [_operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
     
         NSString        *responseString = nil;
         NSData          *data           = nil;
         NSDictionary    *info           = nil;
    
            if (responseObject) {
    
                responseString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            }
         
         //if(LOGS_ON) NSLog(@"string for input = response string = %@", responseString);
    
         if (responseString) {
        
             data = [responseString dataUsingEncoding:NSStringEncodingConversionAllowLossy];
        
             if (data) {
            
                 info = [NSJSONSerialization JSONObjectWithData:data
                                                        options:NSJSONReadingMutableContainers
                                                          error:nil];
                 _algoExecuter.inputInfo = info;
                 
//                 NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//                 [userDefaults setObject:info forKey:USER_DEFAULTS_KEY];
//                 [userDefaults synchronize];
                 
                 //if(LOGS_ON) NSLog(@"input into = %@", info);
            
            //******************** check here ******************//
            //[_algoExecuter executeAlgorithm];
            }
         }
    
            //// found input values for algorithm ////
            if ([_delegate respondsToSelector:@selector(algorithmExecutionFoundInputInfo:)]) {
        
                [_delegate algorithmExecutionFoundInputInfo:info];
            }
    
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
     
            //// to tell that request has been failed ////
            if ([_delegate respondsToSelector:@selector(algorithmExecutionFailToFindInputInfo)]) {
     
                [_delegate algorithmExecutionFailToFindInputInfo];
            }
     }];
     [_operation start];
    _END;
}


/**
 * This function will send user report to server
 */
-(void) sendReportsToServer{
    
    _START;
    NSMutableDictionary *param = [NSMutableDictionary dictionaryWithDictionary:_algoExecuter.scoreBoard.scoreInfo];
    [param setValue:@"SAVE_USER_REPORT" forKey:@"OPERATION"];
    [param setValue:[NSNumber numberWithInt:_user.userID] forKey:@"user_id"];
    
    //if(LOGS_ON) NSLog(@"report to send = %@", param);
    
    AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:APPLICATION_LOCATION]];
    
    NSMutableURLRequest *afRequest = [httpClient multipartFormRequestWithMethod:@"POST"
                                                                           path:APPLICATION_INDEX
                                                                     parameters:param
                                                      constructingBodyWithBlock:^(id <AFMultipartFormData>formData){}
                                      ];
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:afRequest];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSString *decodedString = nil;
        BOOL updationSuccessfull = NO;
        if (responseObject) {
            
            decodedString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        }
        
        //if(LOGS_ON) NSLog(@"report response string = %@", decodedString);
        
        if (decodedString) {
            
            updationSuccessfull = decodedString.boolValue;
        }
        
        if (updationSuccessfull) {
            
            [UniversalTaskExecuter showAlertWithTitle:@"Account Updation"
                                           andMessage:@"User account updated"
                                      withButtonTitle:@"OK"];
        }
        else{
            
            [UniversalTaskExecuter showAlertWithTitle:@"Account Updation"
                                           andMessage:@"User account updated"
                                      withButtonTitle:@"OK"];
        }
        
        [self changeUI];
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [UniversalTaskExecuter showAlertWithTitle:@"Account Updation"
                                       andMessage:@"User account did not update due to some network problem"
                                  withButtonTitle:@"OK"];
        
    }];
    [operation start];
    _END;
}
@end
