//
//  User.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 02/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import "User.h"

@implementation User

@synthesize userID      = _userID;
@synthesize username    = _username;
@synthesize firstName   = _firstName;
@synthesize lastName    = _lastName;
@synthesize password    = _password;
@synthesize gender      = _gender;
@synthesize dateOfBirth = _dateOfBirth;
@synthesize dob         = _dob;
@synthesize weight      = _weight;
@synthesize heightFeet  = _heightFeet;
@synthesize heightInche = _heightInche;
@synthesize day         = _day;
@synthesize month       = _month;
@synthesize year        = _year;
@synthesize age         = _age;

@synthesize userInfo    = _userInfo;

- (id)init
{
    self = [super init];
    if (self) {
        
        _dateOfBirth = [[NSMutableString alloc] initWithString:ZERO_DATA];
        _userInfo    = [[NSMutableDictionary alloc] init];
    }
    return self;
}

#pragma mark- Date Of Birth and Age Methods
- (NSInteger) getAge{
    
    NSInteger age = 0;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-DD"];
    
    NSDate *date = [dateFormatter dateFromString:_dateOfBirth];
    
    NSTimeInterval interval = [date timeIntervalSinceNow];
    age = interval/(60*60*24*365);
    _age = -age;
    return age;
}

-(void)setDateOfBirth:(NSString *)dateOfBirth{
    
    _START;
    NSArray *dateComponents= nil;
    //if(LOGS_ON) NSLog(@"to set date = %@", dateOfBirth);
    _dateOfBirth = dateOfBirth;
    if (dateOfBirth && ![dateOfBirth isEqualToString:@""]) {
        
        dateComponents = [dateOfBirth componentsSeparatedByString:DATE_SEPARATER];
    }
    
    //// getting date components from date of birth string ////
    if (dateComponents && dateComponents.count == 3) {
        
        _day   = [[dateComponents objectAtIndex:2] integerValue];
        _month = [[dateComponents objectAtIndex:1] integerValue];
        _year  = [[dateComponents objectAtIndex:0] integerValue];
        
        [self getAge];
    }
    
    _END;
}

-(void) setDay:(NSInteger)day{
    
    NSString        *dayString   = nil;
    NSMutableString *dateOfBirth = nil;
    
    if (day > 0) {
        
        _day = day;
        dateOfBirth = [[NSMutableString alloc] initWithString:_dateOfBirth];
        dayString = [NSString stringWithFormat:@"%d",day];
        //if(LOGS_ON) NSLog(@"day = %@",dayString);
        [dateOfBirth replaceCharactersInRange:NSMakeRange(10 - dayString.length, dayString.length)
                                    withString:dayString];
        
        _dateOfBirth = dateOfBirth;
        //if(LOGS_ON) NSLog(@" _data of birth = %@", _dateOfBirth);
        
        [self getAge];
    }
}

-(void) setMonth:(NSInteger)month{
    
    NSString        *monthString = nil;
    NSMutableString *dateOfBirth = nil;
    
    if (month > 0) {
        
        _month = month;
        dateOfBirth = [[NSMutableString alloc] initWithString:_dateOfBirth];
        monthString = [NSString stringWithFormat:@"%d",month];
        [dateOfBirth replaceCharactersInRange:NSMakeRange(7 - monthString.length, monthString.length)
                                   withString:monthString];
        _dateOfBirth = dateOfBirth;
        //if(LOGS_ON) NSLog(@" _data of birth = %@", _dateOfBirth);
        
        [self getAge];
    }
}

-(void) setYear:(NSInteger)year{
    
    NSString *yearString = nil;
    NSMutableString *dateOfBirth = nil;
    
    if (year > 0) {
        
        _year = year;
        dateOfBirth = [[NSMutableString alloc] initWithString:_dateOfBirth];
        yearString = [NSString stringWithFormat:@"%d",year];
        //if(LOGS_ON) NSLog(@"string to replace = %@", yearString);
        [dateOfBirth replaceCharactersInRange:NSMakeRange(4-yearString.length, yearString.length)
                                   withString:yearString];
        _dateOfBirth = dateOfBirth;
        //if(LOGS_ON) NSLog(@" _data of birth = %@", _dateOfBirth);
        
        [self getAge];
    }
}

#pragma mark- User information dictionary
//// to return dictionary from object data value ////
-(NSMutableDictionary *)userInfo{
    
    NSMutableDictionary *userInfo = [[NSMutableDictionary alloc] init];
    if (!_userInfo) {
        
        _userInfo = [[NSMutableDictionary alloc] init];
    }
    
    [userInfo setValue:[NSNumber numberWithInteger:_userID] forKey:USER_USER_ID];
    [userInfo setValue:_username    forKey:USER_USERNAME];
    [userInfo setValue:_firstName   forKey:USER_FIRST_NAME];
    [userInfo setValue:_lastName    forKey:USER_LAST_NAME];
    [userInfo setValue:_password    forKey:USER_PASSWORD];
    [userInfo setValue:_gender      forKey:USER_GENDER];
    [userInfo setValue:_dateOfBirth forKey:USER_DATE_OF_BIRTH];
    [userInfo setValue:_dob         forKey:USER_DOB];
    
    [userInfo setValue:[NSNumber numberWithFloat   :_weight]      forKey:USER_WEIGHT];
    [userInfo setValue:[NSNumber numberWithInteger :_heightFeet]  forKey:USER_HEIGHT_FEET];
    [userInfo setValue:[NSNumber numberWithInteger :_day]         forKey:USER_DAY];
    [userInfo setValue:[NSNumber numberWithInteger :_month]       forKey:USER_MONTH];
    [userInfo setValue:[NSNumber numberWithInteger :_year]        forKey:USER_YEAR];
    [userInfo setValue:[NSNumber numberWithInteger :_heightInche] forKey:USER_HEIGHT_INCHE];
    [userInfo setValue:[NSNumber numberWithInteger :_age]         forKey:USER_AGE];
    
    [_userInfo setDictionary:userInfo];
    return _userInfo;
}

//// set object from dictionary ////
-(void) setUserInfo:(NSMutableDictionary *)userInfo{
    
    _START;
    
    //if(LOGS_ON) NSLog(@"received object = %@", userInfo);
    
    if (userInfo) {
        
        if ([userInfo objectForKey:USER_USER_ID]) {
            
            _userID = [((NSNumber *)[userInfo objectForKey:USER_USER_ID]) integerValue];
        }
        _username  = [userInfo objectForKey:USER_USERNAME];
        _firstName = [userInfo objectForKey:USER_FIRST_NAME];
        _lastName  = [userInfo objectForKey:USER_LAST_NAME];
        _password  = [userInfo objectForKey:USER_PASSWORD];
        
        if ([userInfo objectForKey:USER_GENDER]) {
            
            _gender = [userInfo objectForKey:USER_GENDER];
        }
        
        //if(LOGS_ON) NSLog(@"date of birth is setting");
        self.dateOfBirth = [userInfo objectForKey:USER_DATE_OF_BIRTH];
        //if(LOGS_ON) NSLog(@"date of birth is set as %@", _dateOfBirth);
        _dob = [userInfo objectForKey:USER_DOB];
        
        if ([userInfo objectForKey:USER_WEIGHT]) {
            
            _weight = [((NSNumber *)[userInfo objectForKey:USER_WEIGHT]) floatValue];
        }
        
        if ([userInfo objectForKey:USER_HEIGHT_FEET]) {
            
            _heightFeet = [((NSNumber *)[userInfo objectForKey:USER_HEIGHT_FEET]) integerValue];
        }
        
        if ([userInfo objectForKey:USER_HEIGHT_INCHE]) {
            
            _heightInche = [((NSNumber *)[userInfo objectForKey:USER_HEIGHT_INCHE]) integerValue];
        }
        
        if ([userInfo objectForKey:USER_DAY]) {
            
            _day = [((NSNumber *)[userInfo objectForKey:USER_DAY]) integerValue];
        }
        
        if ([userInfo objectForKey:USER_MONTH]) {
            
            _month = [((NSNumber *)[userInfo objectForKey:USER_MONTH]) integerValue];
        }
        
        if ([userInfo objectForKey:USER_YEAR]) {
            
            _year = [((NSNumber *)[userInfo objectForKey:USER_YEAR]) integerValue];
        }
        
        if ([userInfo objectForKey:USER_AGE]) {
            
            _age = [((NSNumber *)[userInfo objectForKey:USER_AGE]) integerValue];
        }
    }
    
    //if(LOGS_ON) NSLog(@"prapered dictionary = %@", self.userInfo);
    _END;
}
@end
