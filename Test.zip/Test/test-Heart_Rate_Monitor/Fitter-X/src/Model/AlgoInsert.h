//
//  AlgoInsert.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 28/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface bf_calculation_formula_value : NSObject{
    
    CGFloat _minimum_age;
    CGFloat _maximum_age;
    NSString *_gender;
    CGFloat _first_value;
    CGFloat _second_value;
    CGFloat _third_value;
    CGFloat _forth_value;
    CGFloat _fifth_value;
    NSString *_comparison_type;
}

@end

@interface bf_score_formula_value : NSObject{
    
    NSString *_gender;
    CGFloat _first_value;
    CGFloat _second_value;
    CGFloat _third_value;
    CGFloat _minimum_bf;
    CGFloat _maximum_bf;
    NSString *_comparison_type;
    NSDictionary *_info;
}

@property(nonatomic, strong) NSString *gender;
@property(nonatomic, assign) CGFloat first_value;
@property(nonatomic, assign) CGFloat second_value;
@property(nonatomic, assign) CGFloat third_value;
@property(nonatomic, assign) CGFloat minimum_bf;
@property(nonatomic, assign) CGFloat maximum_bf;
@property(nonatomic, strong) NSString *comparison_type;
@property(nonatomic, strong) NSDictionary *info;

@end

@interface master_calculation : NSObject{
    
    CGFloat _rhr_score;
    CGFloat _rr_score;
    CGFloat _bf_score;
    CGFloat _st_score;
    CGFloat _mpm_score;
    CGFloat _big_distance;
    NSMutableDictionary *_info;
}

@property(nonatomic, assign) CGFloat rhr_score;
@property(nonatomic, assign) CGFloat rr_score;
@property(nonatomic, assign) CGFloat bf_score;
@property(nonatomic, assign) CGFloat st_score;
@property(nonatomic, assign) CGFloat mpm_score;
@property(nonatomic, assign) CGFloat big_distance;
@property(nonatomic, strong) NSMutableDictionary *info;
@end

@interface mpm_score_formula_value : NSObject{
    
    CGFloat      _first_value;
    CGFloat      _second_value;
    CGFloat      _minimum_distance;
    CGFloat      _maximum_distance;
    NSString     *_comparison_type;
    NSDictionary *_info;
}

@property(nonatomic, assign) CGFloat      first_value;
@property(nonatomic, assign) CGFloat      second_value;
@property(nonatomic, assign) CGFloat      minimum_distance;
@property(nonatomic, assign) CGFloat      maximum_distance;
@property(nonatomic, strong) NSString     *comparison_type;
@property(nonatomic, strong) NSDictionary *info;

@end

@interface rhr_score_formula_value : NSObject{
    
    NSString *_gender;
    CGFloat  _first_value;
    CGFloat  _second_value;
    CGFloat  _third_value;
    CGFloat  _minimum_age;
    CGFloat  _maximum_age;
    NSString *_comparison_type;
}

@end

@interface rr_score_formula_value : NSObject{
    
    CGFloat  _minimum_rr;
    CGFloat  _maximum_rr;
    CGFloat  _first_value;
    CGFloat  _second_value;
    CGFloat  _third_value;
    NSString *_comparison_type;
    NSDictionary *_info;
}

@property(nonatomic, assign) CGFloat      minimum_rr;
@property(nonatomic, assign) CGFloat      maximum_rr;
@property(nonatomic, assign) CGFloat      first_value;
@property(nonatomic, assign) CGFloat      second_value;
@property(nonatomic, assign) CGFloat      third_value;
@property(nonatomic, strong) NSString     *comparison_type;
@property(nonatomic, strong) NSDictionary *info;

@end

@interface bmi_formula_value : NSObject{
    
    CGFloat _first_value;
}

@end

@interface rr_formula_value : NSObject{
    
    CGFloat _rr_value;
}

@end

@interface st_calculation_formula_value : NSObject{
    
    NSString *_range_type;
    CGFloat  _first_value;
    CGFloat  _second_value;
}

@end

@interface st_score_formula_value : NSObject{
    
    NSString *_range_type;
    CGFloat  _first_value;
    CGFloat  _second_value;
}

@end

@interface AlgoInsert : NSObject{
    
    
}

@end


