//
//  Constants.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 02/01/14.
//  Copyright (c) 2014 Shailsh Naiwal. All rights reserved.
//

#ifndef Fitter_X_Constants_h
#define Fitter_X_Constants_h
//******************** Macros ***************************************//
#define _START ;//if(LOGS_ON) NSLog(@"\n Start %s",__FUNCTION__)
#define _END ;//if(LOGS_ON) NSLog(@"\n End %s",__FUNCTION__)
#define LOGS_ON YES
#define SERVER_LOGS_ON YES

//// server location ////
//#define APPLICATION_URL      @"http://localhost:8888/Fitter-X/index.php"
//#define APPLICATION_LOCATION @"http://localhost:8888/Fitter-X/"

#define APPLICATION_URL      @"http://www.chromeinfotech.com/fitterx/index.php"
#define APPLICATION_LOCATION @"http://www.chromeinfotech.com/fitterx/"
#define APPLICATION_INDEX    @"index.php"

#define DATABASE_NAME @"Fitter-X.sqlite"

#define DATA_UNAVAILABLE @"NA"
#define EMPTY_STRING     @""
#define LAST_RR          @"Last RR"

#define USER_DEFAULTS_KEY @"USER DEFAULTS KEY"

//// Device type ////
#define iPAD [UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad

//// Device orientation ////
#define IS_PORTRAIT UIDeviceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])

//// application delegate ////
#define APP_DELEGATE ((AppDelegate *)[UIApplication sharedApplication].delegate)

//// iOS version ////
#define IS_IOS_7           [[[UIDevice currentDevice].systemVersion substringToIndex:1] floatValue] >= 7.0
#define IS_LESS_THAN_IOS_7 [[[UIDevice currentDevice].systemVersion substringToIndex:1] floatValue] < 7.0
#define IS_IPhone5         ([[UIScreen mainScreen] bounds].size.height == 480.0)?FALSE:TRUE

//// device version ////
#define SYSTEM_VERSION_EQUAL_TO(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)             ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)    ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

//// server request type ////
#define POST @"POST"
#define GET  @"GET"

//// request key ////
#define REQUEST_KEY          @"OPERATION"
#define USERNAME_KEY         @"USERNAME"
#define PASSWORD_KEY         @"PASSWORD"
#define SERVER_USER_INFO_KEY @"UserInfo"

//// server request ////
#define LOGIN        @"USER_LOGIN"
#define REGISTRATION @"USER_REGISTRATION"

//// Gender char ////
#define GENDER_MALE_CHAR    @"M"
#define GENDER_FEMALE_CHAR  @"F"
#define ZERO_DATA           @"0001-01-01"
#define DATE_SEPARATER      @"-"

//// some calculation ////
#define START_YEAR          1930
#define METER_PER_SECOND_TO_MILE_PER_HOUR (60.0 * 60.0 /1609.34)
#define METER_TO_MILE (1 / 1609.34)

//// Application fonts ////
#define APPLICATION_ZIAN_FONT(obj)    [UIFont fontWithName:@"Zian"              size:obj.font.pointSize]
#define APPLICATION_IMPACT_FONT(obj)  [UIFont fontWithName:@"DINAlternate-Bold" size:obj.font.pointSize]
#define APPLICATION_NORMAL_FONT(obj)  [UIFont fontWithName:@"Verdana"           size:obj.font.pointSize]
#define APPLICATION_BOLD_FONT(obj)    [UIFont fontWithName:@"Verdana-Bold"      size:obj.font.pointSize]

//// Activity time and timeouts ////
#define TIME_OUT_CONNECTION             60.0
#define TIME_OUT_RESTING_HEART_RATE     60.0
#define TIME_OUT_RECOVERY_HEART_RATE    60.0
#define TIME_FOR_DISTANCE_CALCULATION   1.0
#define TIME_FOR_HEART_RATE_CALCULATION 1.0
#define TIME_FOR_ST_CALCULATION         1.0
#define TIME_FOR_ALGO_EXECUATION        1.0
#define TIME_FOR_UI_CHANGE              1.0


//********************************* Enums ****************************************//
//// for gender ////
typedef NS_ENUM(char, Gender) {
    
    GenderMale   = 'M',
    GenderFemale = 'F',
};

//***********************
#define WF_SENSOR_DATA_FILE                    @"sensor-data.plist"

#define WF_NOTIFICATION_DISCOVERED_SENSOR      @"WFNotificationDiscoveredSensor"
#define WF_NOTIFICATION_HW_CONNECTED           @"WFNotificationHWConnected"
#define WF_NOTIFICATION_HW_DISCONNECTED        @"WFNotificationHWDisconnected"
#define WF_NOTIFICATION_SENSOR_CONNECTED       @"WFNotificationSensorConnected"
#define WF_NOTIFICATION_SENSOR_DISCONNECTED    @"WFNotificationSensorDisconnected"
#define WF_NOTIFICATION_SENSOR_HAS_DATA        @"WFNotificationSensorHasData"


/************************ testing *************************/
#define MASTER_CALCULATION_RESPONSE @"{\"bf_calculation_formula_value\":[{\"minimum_age\":\"26\",\"maximum_age\":\"26\",\"gender\":\"m\",\"first_value\":\"2\",\"second_value\":\"8\",\"third_value\":\"9\",\"forth_value\":\"0\",\"fifth_value\":\"9\",\"comparison_type\":\"=\"}],\"bf_score_formula_value\":[{\"minimum_bf\":\"5\",\"maximum_bf\":\"-1\",\"gender\":\"M\",\"first_value\":\"1\",\"second_value\":\"2\",\"third_value\":\"3\",\"comparison_type\":\"<\"},{\"minimum_bf\":\"31\",\"maximum_bf\":\"40\",\"gender\":\"M\",\"first_value\":\"1\",\"second_value\":\"2\",\"third_value\":\"3\",\"comparison_type\":\"<>\"},{\"minimum_bf\":\"41\",\"maximum_bf\":\"50\",\"gender\":\"M\",\"first_value\":\"1\",\"second_value\":\"2\",\"third_value\":\"3\",\"comparison_type\":\"<>\"},{\"minimum_bf\":\"-1\",\"maximum_bf\":\"50\",\"gender\":\"M\",\"first_value\":\"1\",\"second_value\":\"2\",\"third_value\":\"3\",\"comparison_type\":\">\"},{\"minimum_bf\":\"22\",\"maximum_bf\":\"22\",\"gender\":\"M\",\"first_value\":\"2\",\"second_value\":\"2\",\"third_value\":\"2\",\"comparison_type\":\"=\"}],\"master_calculation\":[{\"rhr_score\":\"41\",\"rr_score\":\"34\",\"bf_score\":\"355\",\"st_score\":\"8\",\"mpm_score\":\"10\",\"big_distance\":\"0\"},{\"rhr_score\":\"2\",\"rr_score\":\"2\",\"bf_score\":\"2\",\"st_score\":\"4\",\"mpm_score\":\"45\",\"big_distance\":\"1\"}],\"mpm_score_formula_value\":[{\"minimum_distance\":\"10\",\"maximum_distance\":\"29\",\"first_value\":\"1\",\"second_value\":\"1\",\"comparison_type\":\"<>\"},{\"minimum_distance\":\"4\",\"maximum_distance\":\"9\",\"first_value\":\"12\",\"second_value\":\"21\",\"comparison_type\":\"<>\"},{\"minimum_distance\":\"32\",\"maximum_distance\":\"33\",\"first_value\":\"2\",\"second_value\":\"3\",\"comparison_type\":\"<>\"},{\"minimum_distance\":\"30\",\"maximum_distance\":\"31\",\"first_value\":\"1\",\"second_value\":\"2\",\"comparison_type\":\"<>\"}],\"rhr_score_formula_value\":[{\"minimum_age\":\"21\",\"maximum_age\":\"30\",\"gender\":\"M\",\"first_value\":\"1\",\"second_value\":\"1\",\"third_value\":\"1\",\"comparison_type\":\"<>\"}],\"rr_score_formula_value\":[{\"minimum_rr\":\"-1\",\"maximum_rr\":\"47\",\"first_value\":\"1\",\"second_value\":\"1\",\"comparison_type\":\">\"},{\"minimum_rr\":\"45\",\"maximum_rr\":\"-1\",\"first_value\":\"1\",\"second_value\":\"2\",\"comparison_type\":\"<\"},{\"minimum_rr\":\"44\",\"maximum_rr\":\"44\",\"first_value\":\"54\",\"second_value\":\"54\",\"comparison_type\":\"=\"}],\"bmi_formula_value\":[{\"first_value\":\"34\"}],\"rr_formula_value\":[{\"rr_value\":\"908\"}],\"st_calculation_formula_value\":[{\"range_type\":\"Active Recovery\",\"first_value\":\"0\",\"second_value\":\"2\"},{\"range_type\":\"Extensive Endurance\",\"first_value\":\"3\",\"second_value\":\"5\"},{\"range_type\":\"Intensive Endurance\",\"first_value\":\"7\",\"second_value\":\"10\"},{\"range_type\":\"Sub Threshold\",\"first_value\":\"6\",\"second_value\":\"9\"},{\"range_type\":\"Super Threshold\",\"first_value\":\"6\",\"second_value\":\"13\"},{\"range_type\":\"Anaerobic Endurance\",\"first_value\":\"2\",\"second_value\":\"5\"},{\"range_type\":\"Power\",\"first_value\":\"6\",\"second_value\":\"7\"}],\"st_score_formula_value\":[{\"score_type\":\"Active Recovery\",\"first_value\":\"0\",\"second_value\":\"0\"},{\"score_type\":\"Extensive Endurance\",\"first_value\":\"0\",\"second_value\":\"0\"},{\"score_type\":\"Intensive Endurance\",\"first_value\":\"0\",\"second_value\":\"10\"},{\"score_type\":\"Sub Threshold\",\"first_value\":\"70\",\"second_value\":\"0\"},{\"score_type\":\"Super Threshold\",\"first_value\":\"0\",\"second_value\":\"0\"},{\"score_type\":\"Anaerobic Endurance\",\"first_value\":\"0\",\"second_value\":\"0\"},{\"score_type\":\"Power\",\"first_value\":\"0\",\"second_value\":\"0\"}],\"last_report\":[{\"report_id\":\"6\",\"user_id\":\"2\",\"rhr\":\"87\",\"rhr_score\":\"-85\",\"rr\":\"0\",\"rr_score\":\"0\",\"bmi\":\"0.4046816\",\"body_fat_percentage\":\"-216.1906\",\"body_fat_score\":\"111.595\",\"avg_exercise_hr\":\"0\",\"st_score\":\"0\",\"avg_mpm\":\"92.3654\",\"mpm_score\":\"91.3654\",\"report_time\":\"2014-03-06 15:39:56\"},{\"report_id\":\"7\",\"user_id\":\"2\",\"rhr\":\"87\",\"rhr_score\":\"-85\",\"rr\":\"0\",\"rr_score\":\"0\",\"bmi\":\"0.4046816\",\"body_fat_percentage\":\"-216.1906\",\"body_fat_score\":\"111.595\",\"avg_exercise_hr\":\"0\",\"st_score\":\"0\",\"avg_mpm\":\"92.1735\",\"mpm_score\":\"91.1735\",\"report_time\":\"2014-03-06 15:39:56\"}]}"
#endif
