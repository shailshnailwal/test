//
//  AppDelegate.m
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (_PRIVATE_)

- (void)copyPlistToDocs;

@end

@implementation AppDelegate

#pragma mark Private Methods

//--------------------------------------------------------------------------------
- (void)copyPlistToDocs
{
	// First, test for existence - we don’t want to wipe out a user’s DB
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) lastObject];
	NSString *filePath = [documentsDirectory stringByAppendingPathComponent:WF_SENSOR_DATA_FILE];
	
	// for debugging, uncomment this line to overwrite existing copy.
	// DEBUG:  overwrite existing settings file.
	//[[NSFileManager defaultManager] removeItemAtPath:filePath error:NULL];
	
	if ( ![fileManager fileExistsAtPath:filePath] )
	{
		// The writable database does not exist, so copy the default to the appropriate location.
		NSString *templatePath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:WF_SENSOR_DATA_FILE];
		
		NSError* error;
		
		BOOL success = [fileManager copyItemAtPath:templatePath toPath:filePath error:&error];
		
		if (!success)
        {
			NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
		}
	}
}
#pragma mark--

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    //----
    [self praperDatabase];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    AppNavigator *navigator = [[AppNavigator alloc] init];
    self.window.rootViewController = navigator;
    //----
    
    //----------
    
    [self copyPlistToDocs];
    
	application.idleTimerDisabled = TRUE;

    // configure the hardware connector.
    hardwareConnector = [WFHardwareConnector sharedConnector];
    hardwareConnector.delegate = self;
	hardwareConnector.sampleRate = 0.5;  // sample rate 500 ms, or 2 Hz.
    //if(LOGS_ON) NSLog(@"hardware connector = %@", hardwareConnector);
    //
    // determine support for BTLE.
    if (hardwareConnector.hasBTLESupport)
    {
        // enable BTLE.
        [hardwareConnector enableBTLE:TRUE];
    }
    //if(LOGS_ON) NSLog(@"%@", hardwareConnector.hasBTLESupport?@"DEVICE HAS BTLE SUPPORT":@"DEVICE DOES NOT HAVE BTLE SUPPORT");
    
    // set HW Connector to call hasData only when new data is available.
    [hardwareConnector setSampleTimerDataCheck:YES];
    
    //if(LOGS_ON) NSLog(@"Launching finished");
    //----------
    [self.window makeKeyAndVisible];
    return YES;
}

/**
 * this functin will initiate local database database creation for application
 */
-(void) praperDatabase{
    
    _START;
    BOOL databaseOK = [DatabaseManage createDatabaseIfNotExist];
    if (!databaseOK) {
        
        [UniversalTaskExecuter showAlertWithTitle:@"Application Database Info"
                                       andMessage:@"Database set up failed. Please restart applicaton"
                                  withButtonTitle:@"OK"];
    }
    _END;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
#pragma mark -
#pragma mark HardwareConnectorDelegate Implementation

//--------------------------------------------------------------------------------
- (void)hardwareConnector:(WFHardwareConnector*)hwConnector connectedSensor:(WFSensorConnection*)connectionInfo
{
    _START;
    NSDictionary* userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                              connectionInfo, @"connectionInfo",
                              nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:WF_NOTIFICATION_SENSOR_CONNECTED object:nil userInfo:userInfo];
    _END;
}

//--------------------------------------------------------------------------------
- (void)hardwareConnector:(WFHardwareConnector*)hwConnector didDiscoverDevices:(NSSet*)connectionParams searchCompleted:(BOOL)bCompleted
{
    _START;
    // post the sensor type and device params to the notification.
    NSDictionary* userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                              connectionParams, @"connectionParams",
                              [NSNumber numberWithBool:bCompleted], @"searchCompleted",
                              nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:WF_NOTIFICATION_DISCOVERED_SENSOR object:nil userInfo:userInfo];
    _END;
}

//--------------------------------------------------------------------------------
- (void)hardwareConnector:(WFHardwareConnector*)hwConnector disconnectedSensor:(WFSensorConnection*)connectionInfo
{
    _START;
    [[NSNotificationCenter defaultCenter] postNotificationName:WF_NOTIFICATION_SENSOR_DISCONNECTED object:nil];
    _START;
}

//--------------------------------------------------------------------------------
- (void)hardwareConnector:(WFHardwareConnector*)hwConnector stateChanged:(WFHardwareConnectorState_t)currentState
{
    _START;
	BOOL connected = ((currentState & WF_HWCONN_STATE_ACTIVE) || (currentState & WF_HWCONN_STATE_BT40_ENABLED)) ? TRUE : FALSE;
	if (connected)
	{
        [[NSNotificationCenter defaultCenter] postNotificationName:WF_NOTIFICATION_HW_CONNECTED object:nil];
	}
	else
	{
        [[NSNotificationCenter defaultCenter] postNotificationName:WF_NOTIFICATION_HW_DISCONNECTED object:nil];
	}
    _END;
}

//--------------------------------------------------------------------------------
- (void)hardwareConnectorHasData
{
    _START;
    [[NSNotificationCenter defaultCenter] postNotificationName:WF_NOTIFICATION_SENSOR_HAS_DATA object:nil];
    _END;
}

@end
