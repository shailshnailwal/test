//
//  AppDelegate.h
//  Fitter-X
//
//  Created by Shailsh Naiwal on 30/12/13.
//  Copyright (c) 2013 Shailsh Naiwal. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import <WFConnector/WFConnector.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate, WFHardwareConnectorDelegate>{
    
    WFHardwareConnector* hardwareConnector;
}

@property (strong, nonatomic) UIWindow *window;

@end
